--
-- PostgreSQL database dump
--

-- Dumped from database version 10.5 (Debian 10.5-2.pgdg90+1)
-- Dumped by pg_dump version 10.5 (Debian 10.5-2.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: account_emailaddress; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.account_emailaddress (
    id integer NOT NULL,
    email character varying(254) NOT NULL,
    verified boolean NOT NULL,
    "primary" boolean NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.account_emailaddress OWNER TO debug;

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.account_emailaddress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailaddress_id_seq OWNER TO debug;

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.account_emailaddress_id_seq OWNED BY public.account_emailaddress.id;


--
-- Name: account_emailconfirmation; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.account_emailconfirmation (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    sent timestamp with time zone,
    key character varying(64) NOT NULL,
    email_address_id integer NOT NULL
);


ALTER TABLE public.account_emailconfirmation OWNER TO debug;

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.account_emailconfirmation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailconfirmation_id_seq OWNER TO debug;

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.account_emailconfirmation_id_seq OWNED BY public.account_emailconfirmation.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO debug;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO debug;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO debug;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO debug;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO debug;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO debug;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO debug;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO debug;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO debug;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO debug;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO debug;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO debug;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO debug;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO debug;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_site_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO debug;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_site_id_seq OWNED BY public.django_site.id;


--
-- Name: gematriacore_alphabet; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.gematriacore_alphabet (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    title character varying(200) NOT NULL,
    language_id character varying(200)
);


ALTER TABLE public.gematriacore_alphabet OWNER TO debug;

--
-- Name: gematriacore_alphabet_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.gematriacore_alphabet_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gematriacore_alphabet_id_seq OWNER TO debug;

--
-- Name: gematriacore_alphabet_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.gematriacore_alphabet_id_seq OWNED BY public.gematriacore_alphabet.id;


--
-- Name: gematriacore_gematriamethod; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.gematriacore_gematriamethod (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    title character varying(200) NOT NULL,
    alphabet_id integer,
    language_id uuid
);


ALTER TABLE public.gematriacore_gematriamethod OWNER TO debug;

--
-- Name: gematriacore_gematriamethod_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.gematriacore_gematriamethod_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gematriacore_gematriamethod_id_seq OWNER TO debug;

--
-- Name: gematriacore_gematriamethod_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.gematriacore_gematriamethod_id_seq OWNED BY public.gematriacore_gematriamethod.id;


--
-- Name: gematriacore_gematriamethodletterrule; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.gematriacore_gematriamethodletterrule (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    numerical_value double precision NOT NULL,
    letter_id integer,
    gematria_method_id integer
);


ALTER TABLE public.gematriacore_gematriamethodletterrule OWNER TO debug;

--
-- Name: gematriacore_gematriamethodletterrule_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.gematriacore_gematriamethodletterrule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gematriacore_gematriamethodletterrule_id_seq OWNER TO debug;

--
-- Name: gematriacore_gematriamethodletterrule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.gematriacore_gematriamethodletterrule_id_seq OWNED BY public.gematriacore_gematriamethodletterrule.id;


--
-- Name: gematriacore_language; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.gematriacore_language (
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    title character varying(200) NOT NULL,
    uuid uuid NOT NULL
);


ALTER TABLE public.gematriacore_language OWNER TO debug;

--
-- Name: gematriacore_letter; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.gematriacore_letter (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    title character varying(200) NOT NULL,
    "character" character varying(1) NOT NULL,
    alphabet_id integer,
    letter_order integer
);


ALTER TABLE public.gematriacore_letter OWNER TO debug;

--
-- Name: gematriacore_letter_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.gematriacore_letter_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gematriacore_letter_id_seq OWNER TO debug;

--
-- Name: gematriacore_letter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.gematriacore_letter_id_seq OWNED BY public.gematriacore_letter.id;


--
-- Name: gematriacore_letter_meanings; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.gematriacore_letter_meanings (
    id integer NOT NULL,
    letter_id integer NOT NULL,
    lettermeaning_id integer NOT NULL
);


ALTER TABLE public.gematriacore_letter_meanings OWNER TO debug;

--
-- Name: gematriacore_letter_meanings_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.gematriacore_letter_meanings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gematriacore_letter_meanings_id_seq OWNER TO debug;

--
-- Name: gematriacore_letter_meanings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.gematriacore_letter_meanings_id_seq OWNED BY public.gematriacore_letter_meanings.id;


--
-- Name: gematriacore_lettermeaning; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.gematriacore_lettermeaning (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    meaning character varying(200) NOT NULL,
    is_active boolean
);


ALTER TABLE public.gematriacore_lettermeaning OWNER TO debug;

--
-- Name: gematriacore_lettermeaning_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.gematriacore_lettermeaning_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gematriacore_lettermeaning_id_seq OWNER TO debug;

--
-- Name: gematriacore_lettermeaning_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.gematriacore_lettermeaning_id_seq OWNED BY public.gematriacore_lettermeaning.id;


--
-- Name: gematriacore_letterpower; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.gematriacore_letterpower (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    power character varying(20) NOT NULL,
    is_active boolean,
    letter_id integer
);


ALTER TABLE public.gematriacore_letterpower OWNER TO debug;

--
-- Name: gematriacore_letterpower_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.gematriacore_letterpower_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gematriacore_letterpower_id_seq OWNER TO debug;

--
-- Name: gematriacore_letterpower_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.gematriacore_letterpower_id_seq OWNED BY public.gematriacore_letterpower.id;


--
-- Name: gematriacore_word; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.gematriacore_word (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    name_english character varying(200) NOT NULL,
    name_original_language character varying(200) NOT NULL,
    language_id uuid,
    characters_alpha character varying(200)
);


ALTER TABLE public.gematriacore_word OWNER TO debug;

--
-- Name: gematriacore_word_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.gematriacore_word_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gematriacore_word_id_seq OWNER TO debug;

--
-- Name: gematriacore_word_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.gematriacore_word_id_seq OWNED BY public.gematriacore_word.id;


--
-- Name: gematriacore_wordmeaning; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.gematriacore_wordmeaning (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    meaning character varying(200) NOT NULL,
    is_active boolean,
    word_id integer,
    source text
);


ALTER TABLE public.gematriacore_wordmeaning OWNER TO debug;

--
-- Name: gematriacore_wordmeaning_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.gematriacore_wordmeaning_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gematriacore_wordmeaning_id_seq OWNER TO debug;

--
-- Name: gematriacore_wordmeaning_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.gematriacore_wordmeaning_id_seq OWNED BY public.gematriacore_wordmeaning.id;


--
-- Name: gematriacore_wordvalue; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.gematriacore_wordvalue (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    value double precision,
    gematria_method_id integer,
    word_id integer
);


ALTER TABLE public.gematriacore_wordvalue OWNER TO debug;

--
-- Name: gematriacore_wordvalue_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.gematriacore_wordvalue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gematriacore_wordvalue_id_seq OWNER TO debug;

--
-- Name: gematriacore_wordvalue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.gematriacore_wordvalue_id_seq OWNED BY public.gematriacore_wordvalue.id;


--
-- Name: socialaccount_socialaccount; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.socialaccount_socialaccount (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    uid character varying(191) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    extra_data text NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialaccount OWNER TO debug;

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.socialaccount_socialaccount_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialaccount_id_seq OWNER TO debug;

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.socialaccount_socialaccount_id_seq OWNED BY public.socialaccount_socialaccount.id;


--
-- Name: socialaccount_socialapp; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.socialaccount_socialapp (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    name character varying(40) NOT NULL,
    client_id character varying(191) NOT NULL,
    secret character varying(191) NOT NULL,
    key character varying(191) NOT NULL
);


ALTER TABLE public.socialaccount_socialapp OWNER TO debug;

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.socialaccount_socialapp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialapp_id_seq OWNER TO debug;

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.socialaccount_socialapp_id_seq OWNED BY public.socialaccount_socialapp.id;


--
-- Name: socialaccount_socialapp_sites; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.socialaccount_socialapp_sites (
    id integer NOT NULL,
    socialapp_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialapp_sites OWNER TO debug;

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.socialaccount_socialapp_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialapp_sites_id_seq OWNER TO debug;

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.socialaccount_socialapp_sites_id_seq OWNED BY public.socialaccount_socialapp_sites.id;


--
-- Name: socialaccount_socialtoken; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.socialaccount_socialtoken (
    id integer NOT NULL,
    token text NOT NULL,
    token_secret text NOT NULL,
    expires_at timestamp with time zone,
    account_id integer NOT NULL,
    app_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialtoken OWNER TO debug;

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.socialaccount_socialtoken_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialtoken_id_seq OWNER TO debug;

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.socialaccount_socialtoken_id_seq OWNED BY public.socialaccount_socialtoken.id;


--
-- Name: users_user; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.users_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.users_user OWNER TO debug;

--
-- Name: users_user_groups; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.users_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.users_user_groups OWNER TO debug;

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.users_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_groups_id_seq OWNER TO debug;

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.users_user_groups_id_seq OWNED BY public.users_user_groups.id;


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO debug;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users_user.id;


--
-- Name: users_user_user_permissions; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.users_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.users_user_user_permissions OWNER TO debug;

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.users_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_user_permissions_id_seq OWNER TO debug;

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.users_user_user_permissions_id_seq OWNED BY public.users_user_user_permissions.id;


--
-- Name: account_emailaddress id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailaddress ALTER COLUMN id SET DEFAULT nextval('public.account_emailaddress_id_seq'::regclass);


--
-- Name: account_emailconfirmation id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailconfirmation ALTER COLUMN id SET DEFAULT nextval('public.account_emailconfirmation_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: django_site id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_site ALTER COLUMN id SET DEFAULT nextval('public.django_site_id_seq'::regclass);


--
-- Name: gematriacore_alphabet id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_alphabet ALTER COLUMN id SET DEFAULT nextval('public.gematriacore_alphabet_id_seq'::regclass);


--
-- Name: gematriacore_gematriamethod id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_gematriamethod ALTER COLUMN id SET DEFAULT nextval('public.gematriacore_gematriamethod_id_seq'::regclass);


--
-- Name: gematriacore_gematriamethodletterrule id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_gematriamethodletterrule ALTER COLUMN id SET DEFAULT nextval('public.gematriacore_gematriamethodletterrule_id_seq'::regclass);


--
-- Name: gematriacore_letter id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_letter ALTER COLUMN id SET DEFAULT nextval('public.gematriacore_letter_id_seq'::regclass);


--
-- Name: gematriacore_letter_meanings id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_letter_meanings ALTER COLUMN id SET DEFAULT nextval('public.gematriacore_letter_meanings_id_seq'::regclass);


--
-- Name: gematriacore_lettermeaning id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_lettermeaning ALTER COLUMN id SET DEFAULT nextval('public.gematriacore_lettermeaning_id_seq'::regclass);


--
-- Name: gematriacore_letterpower id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_letterpower ALTER COLUMN id SET DEFAULT nextval('public.gematriacore_letterpower_id_seq'::regclass);


--
-- Name: gematriacore_word id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_word ALTER COLUMN id SET DEFAULT nextval('public.gematriacore_word_id_seq'::regclass);


--
-- Name: gematriacore_wordmeaning id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_wordmeaning ALTER COLUMN id SET DEFAULT nextval('public.gematriacore_wordmeaning_id_seq'::regclass);


--
-- Name: gematriacore_wordvalue id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_wordvalue ALTER COLUMN id SET DEFAULT nextval('public.gematriacore_wordvalue_id_seq'::regclass);


--
-- Name: socialaccount_socialaccount id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialaccount ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialaccount_id_seq'::regclass);


--
-- Name: socialaccount_socialapp id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialapp_id_seq'::regclass);


--
-- Name: socialaccount_socialapp_sites id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialapp_sites_id_seq'::regclass);


--
-- Name: socialaccount_socialtoken id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialtoken ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialtoken_id_seq'::regclass);


--
-- Name: users_user id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user ALTER COLUMN id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Name: users_user_groups id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_groups ALTER COLUMN id SET DEFAULT nextval('public.users_user_groups_id_seq'::regclass);


--
-- Name: users_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.users_user_user_permissions_id_seq'::regclass);


--
-- Data for Name: account_emailaddress; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.account_emailaddress (id, email, verified, "primary", user_id) FROM stdin;
1	ndewaard@protonmail.com	f	f	1
\.


--
-- Data for Name: account_emailconfirmation; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.account_emailconfirmation (id, created, sent, key, email_address_id) FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add permission	1	add_permission
2	Can change permission	1	change_permission
3	Can delete permission	1	delete_permission
4	Can add group	2	add_group
5	Can change group	2	change_group
6	Can delete group	2	delete_group
7	Can add content type	3	add_contenttype
8	Can change content type	3	change_contenttype
9	Can delete content type	3	delete_contenttype
10	Can add session	4	add_session
11	Can change session	4	change_session
12	Can delete session	4	delete_session
13	Can add site	5	add_site
14	Can change site	5	change_site
15	Can delete site	5	delete_site
16	Can add log entry	6	add_logentry
17	Can change log entry	6	change_logentry
18	Can delete log entry	6	delete_logentry
19	Can add email address	7	add_emailaddress
20	Can change email address	7	change_emailaddress
21	Can delete email address	7	delete_emailaddress
22	Can add email confirmation	8	add_emailconfirmation
23	Can change email confirmation	8	change_emailconfirmation
24	Can delete email confirmation	8	delete_emailconfirmation
25	Can add social account	9	add_socialaccount
26	Can change social account	9	change_socialaccount
27	Can delete social account	9	delete_socialaccount
28	Can add social application	10	add_socialapp
29	Can change social application	10	change_socialapp
30	Can delete social application	10	delete_socialapp
31	Can add social application token	11	add_socialtoken
32	Can change social application token	11	change_socialtoken
33	Can delete social application token	11	delete_socialtoken
34	Can add user	12	add_user
35	Can change user	12	change_user
36	Can delete user	12	delete_user
37	Can add letter power	13	add_letterpower
38	Can change letter power	13	change_letterpower
39	Can delete letter power	13	delete_letterpower
40	Can add letter	14	add_letter
41	Can change letter	14	change_letter
42	Can delete letter	14	delete_letter
43	Can add alphabet	15	add_alphabet
44	Can change alphabet	15	change_alphabet
45	Can delete alphabet	15	delete_alphabet
46	Can add language	16	add_language
47	Can change language	16	change_language
48	Can delete language	16	delete_language
49	Can add dictionary	17	add_dictionary
50	Can change dictionary	17	change_dictionary
51	Can delete dictionary	17	delete_dictionary
52	Can add word	18	add_word
53	Can change word	18	change_word
54	Can delete word	18	delete_word
55	Can add gematria method letter rule	19	add_gematriamethodletterrule
56	Can change gematria method letter rule	19	change_gematriamethodletterrule
57	Can delete gematria method letter rule	19	delete_gematriamethodletterrule
58	Can add word meaning	20	add_wordmeaning
59	Can change word meaning	20	change_wordmeaning
60	Can delete word meaning	20	delete_wordmeaning
61	Can add gematria method	21	add_gematriamethod
62	Can change gematria method	21	change_gematriamethod
63	Can delete gematria method	21	delete_gematriamethod
64	Can add letter meaning	22	add_lettermeaning
65	Can change letter meaning	22	change_lettermeaning
66	Can delete letter meaning	22	delete_lettermeaning
67	Can add word spelling	23	add_wordspelling
68	Can change word spelling	23	change_wordspelling
69	Can delete word spelling	23	delete_wordspelling
70	Can add word value	24	add_wordvalue
71	Can change word value	24	change_wordvalue
72	Can delete word value	24	delete_wordvalue
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2019-03-21 17:51:50.833081+00	1	Language object (1)	1	[{"added": {}}]	16	1
2	2019-03-21 17:52:11.27218+00	1	Alphabet object (1)	1	[{"added": {}}]	15	1
3	2019-03-21 18:05:59.559828+00	1	LetterPower object (1)	1	[{"added": {}}]	13	1
4	2019-03-21 18:06:12.096743+00	1	LetterMeaning object (1)	1	[{"added": {}}]	22	1
5	2019-03-21 18:12:13.145404+00	5	Aleph - Lang: gematriacore.Alphabet.None	1	[{"added": {}}]	14	1
6	2019-03-21 18:12:32.116893+00	5	Aleph - Lang: gematriacore.Alphabet.None	2	[]	14	1
7	2019-03-21 18:24:49.074799+00	5	Aleph: א -- Lang: gematriacore.Alphabet.None	2	[]	14	1
8	2019-03-21 18:26:48.898693+00	5	Aleph: א -- Lang: Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["alphabet"]}}]	14	1
9	2019-03-21 18:30:06.566821+00	6	Beth: ב Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
10	2019-03-21 18:30:47.304239+00	2	G - Active: True	1	[{"added": {}}]	13	1
11	2019-03-21 18:30:55.732495+00	3	Gh - Active: False	1	[{"added": {}}]	13	1
12	2019-03-21 18:31:10.359584+00	2	Camel - Active: True	1	[{"added": {}}]	22	1
13	2019-03-21 18:31:31.935649+00	7	Gimel: ג Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
14	2019-03-21 18:31:43.25549+00	4	B - Active: True	1	[{"added": {}}]	13	1
15	2019-03-21 18:31:49.469379+00	5	V - Active: False	1	[{"added": {}}]	13	1
16	2019-03-21 18:31:56.514613+00	3	House - Active: True	1	[{"added": {}}]	22	1
17	2019-03-21 18:31:58.8682+00	6	Beth: ב Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["powers", "meanings"]}}]	14	1
18	2019-03-21 18:34:20.485227+00	6	D - Active: True	1	[{"added": {}}]	13	1
19	2019-03-21 18:34:28.007566+00	7	Dh - Active: False	1	[{"added": {}}]	13	1
20	2019-03-21 18:34:39.625446+00	4	Door - Active: True	1	[{"added": {}}]	22	1
21	2019-03-21 18:34:47.799536+00	8	Daleth: ד Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
22	2019-03-21 18:35:15.390872+00	8	H - Active: True	1	[{"added": {}}]	13	1
23	2019-03-21 18:35:26.943095+00	5	Window - Active: True	1	[{"added": {}}]	22	1
24	2019-03-21 18:35:34.517853+00	9	He: ה Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
25	2019-03-21 18:40:33.153887+00	1	GematriaMethod object (1)	1	[{"added": {}}]	21	1
26	2019-03-21 18:54:23.895588+00	9	O - Active: True	1	[{"added": {}}]	13	1
27	2019-03-21 18:54:29.364969+00	10	U - Active: False	1	[{"added": {}}]	13	1
28	2019-03-21 18:54:35.161454+00	11	V - Active: False	1	[{"added": {}}]	13	1
29	2019-03-21 18:54:40.355318+00	12	W - Active: False	1	[{"added": {}}]	13	1
30	2019-03-21 18:54:50.552895+00	6	Pin - Active: True	1	[{"added": {}}]	22	1
31	2019-03-21 18:55:14.414762+00	7	Nail - Active: False	1	[{"added": {}}]	22	1
32	2019-03-21 18:55:22.627749+00	10	Vau: <span class="u-language--hebrew">ו</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
33	2019-03-21 18:56:32.906299+00	13	Z - Active: True	1	[{"added": {}}]	13	1
34	2019-03-21 18:56:43.76061+00	8	Sword - Active: True	1	[{"added": {}}]	22	1
35	2019-03-21 18:56:53.046942+00	9	Armour - Active: False	1	[{"added": {}}]	22	1
36	2019-03-21 18:56:59.742558+00	11	Zayin: <span class="u-language--hebrew">ז</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
37	2019-03-21 19:00:02.276085+00	14	Ch - Active: True	1	[{"added": {}}]	13	1
38	2019-03-21 19:00:14.969201+00	10	Fence - Active: True	1	[{"added": {}}]	22	1
39	2019-03-21 19:00:25.406555+00	11	Enclosure - Active: False	1	[{"added": {}}]	22	1
40	2019-03-21 19:00:30.121431+00	12	Chet: <span class="u-language--hebrew">ח</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
41	2019-03-21 19:00:58.548649+00	15	T - Active: True	1	[{"added": {}}]	13	1
42	2019-03-21 19:01:10.029453+00	12	Snake - Active: True	1	[{"added": {}}]	22	1
43	2019-03-21 19:01:14.043345+00	13	Teth: <span class="u-language--hebrew">ט</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
44	2019-03-21 19:01:27.24978+00	16	I - Active: True	1	[{"added": {}}]	13	1
45	2019-03-21 19:01:53.324182+00	17	Y - Active: False	1	[{"added": {}}]	13	1
46	2019-03-21 19:02:02.629109+00	13	Hand - Active: True	1	[{"added": {}}]	22	1
47	2019-03-21 19:02:10.656206+00	14	Palm - Active: True	1	[{"added": {}}]	22	1
48	2019-03-21 19:02:31.362797+00	14	Yod: <span class="u-language--hebrew">י</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
49	2019-03-21 19:03:13.771771+00	18	K - Active: True	1	[{"added": {}}]	13	1
50	2019-03-21 19:03:20.629334+00	19	Kh - Active: False	1	[{"added": {}}]	13	1
51	2019-03-21 19:03:28.730377+00	15	Fist - Active: True	1	[{"added": {}}]	22	1
52	2019-03-21 19:03:40.254509+00	15	Kaph: <span class="u-language--hebrew">כ</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
53	2019-03-21 19:04:12.433964+00	16	Kaph - Final: <span class="u-language--hebrew">ך</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
54	2019-03-21 19:04:34.273794+00	20	L - Active: True	1	[{"added": {}}]	13	1
55	2019-03-21 19:04:59.659055+00	16	Ox Goad - Active: True	1	[{"added": {}}]	22	1
56	2019-03-21 19:05:03.545548+00	17	Lamed: <span class="u-language--hebrew">ל</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
57	2019-03-21 19:05:30.361028+00	21	M - Active: True	1	[{"added": {}}]	13	1
58	2019-03-21 19:05:42.136228+00	17	Water - Active: True	1	[{"added": {}}]	22	1
59	2019-03-21 19:05:46.385174+00	18	Mem: <span class="u-language--hebrew">מ</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
60	2019-03-21 19:06:19.783779+00	19	Mem - Final: <span class="u-language--hebrew">ם</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
61	2019-03-21 19:06:44.032942+00	22	N - Active: True	1	[{"added": {}}]	13	1
62	2019-03-21 19:07:06.613012+00	18	Fish - Active: False	1	[{"added": {}}]	22	1
63	2019-03-21 19:07:09.933235+00	20	Nun: <span class="u-language--hebrew">נ</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
64	2019-03-21 19:07:40.670638+00	21	Nun - Final: <span class="u-language--hebrew">ן</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
65	2019-03-21 19:08:09.896446+00	23	S - Active: True	1	[{"added": {}}]	13	1
66	2019-03-21 19:08:24.380269+00	19	Prop - Active: True	1	[{"added": {}}]	22	1
67	2019-03-21 19:08:35.231007+00	22	Samekh: <span class="u-language--hebrew">ס</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
68	2019-03-21 19:09:04.36724+00	24	Aa - Active: False	1	[{"added": {}}]	13	1
69	2019-03-21 19:09:13.421352+00	20	Eye - Active: True	1	[{"added": {}}]	22	1
70	2019-03-21 19:09:16.626504+00	23	Ayin: <span class="u-language--hebrew">ע</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
71	2019-03-21 19:09:38.95587+00	25	P - Active: True	1	[{"added": {}}]	13	1
72	2019-03-21 19:09:43.940298+00	26	Ph - Active: True	1	[{"added": {}}]	13	1
73	2019-03-21 19:10:08.662123+00	21	Mouth - Active: True	1	[{"added": {}}]	22	1
74	2019-03-21 19:10:13.654434+00	24	Peh: <span class="u-language--hebrew">פ</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
75	2019-03-21 19:10:45.584848+00	25	Peh - Final: <span class="u-language--hebrew">ף</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
76	2019-03-21 19:11:11.591289+00	27	Tz - Active: True	1	[{"added": {}}]	13	1
77	2019-03-21 19:11:26.116474+00	22	Fishhook - Active: True	1	[{"added": {}}]	22	1
78	2019-03-21 19:11:33.729344+00	26	Tzaddi: <span class="u-language--hebrew">צ</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
79	2019-03-21 19:12:09.573596+00	27	Tzaddi - Final: <span class="u-language--hebrew">ץ</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
80	2019-03-21 19:12:31.527523+00	28	Q - Active: True	1	[{"added": {}}]	13	1
81	2019-03-21 19:12:41.844439+00	23	Ear - Active: True	1	[{"added": {}}]	22	1
82	2019-03-21 19:12:49.115823+00	24	Back of Head - Active: False	1	[{"added": {}}]	22	1
83	2019-03-21 19:12:53.140732+00	28	Qoph: <span class="u-language--hebrew">ק</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
84	2019-03-21 19:13:09.333704+00	29	R - Active: True	1	[{"added": {}}]	13	1
85	2019-03-21 19:13:16.01832+00	25	Head - Active: True	1	[{"added": {}}]	22	1
86	2019-03-21 19:13:22.574283+00	26	Face - Active: True	1	[{"added": {}}]	22	1
87	2019-03-21 19:13:46.809062+00	29	Resh: <span class="u-language--hebrew">ר</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
88	2019-03-21 19:14:06.794523+00	30	Sh - Active: False	1	[{"added": {}}]	13	1
89	2019-03-21 19:14:21.697218+00	27	Tooth - Active: True	1	[{"added": {}}]	22	1
90	2019-03-21 19:14:27.297228+00	30	Shin: <span class="u-language--hebrew">ש</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
91	2019-03-21 19:14:52.612806+00	31	Th - Active: False	1	[{"added": {}}]	13	1
92	2019-03-21 19:15:02.574036+00	28	Cross - Active: True	1	[{"added": {}}]	22	1
93	2019-03-21 19:15:07.175745+00	31	Tau: <span class="u-language--hebrew">ת</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
94	2019-03-21 20:27:40.007339+00	1	Dictionary object (1)	1	[{"added": {}}]	17	1
95	2019-03-23 15:52:17.348869+00	28	Cross - Active: True	2	[{"changed": {"fields": ["letter"]}}]	22	1
96	2019-03-23 15:53:07.151835+00	27	Tooth - Active: True	2	[{"changed": {"fields": ["letter"]}}]	22	1
97	2019-03-23 16:16:23.05009+00	31	Th - Active: False	2	[{"changed": {"fields": ["letter"]}}]	13	1
98	2019-03-23 16:17:07.587326+00	31	Th - Active: False	3		13	1
99	2019-03-23 16:17:07.599385+00	30	Sh - Active: False	3		13	1
100	2019-03-23 16:17:07.621554+00	29	R - Active: True	3		13	1
101	2019-03-23 16:17:07.633099+00	28	Q - Active: True	3		13	1
102	2019-03-23 16:17:07.660916+00	27	Tz - Active: True	3		13	1
103	2019-03-23 16:17:07.685463+00	26	Ph - Active: True	3		13	1
104	2019-03-23 16:17:07.707616+00	25	P - Active: True	3		13	1
105	2019-03-23 16:17:07.729556+00	24	Aa - Active: False	3		13	1
106	2019-03-23 16:17:07.75065+00	23	S - Active: True	3		13	1
107	2019-03-23 16:17:07.771316+00	22	N - Active: True	3		13	1
108	2019-03-23 16:17:07.79304+00	21	M - Active: True	3		13	1
109	2019-03-23 16:17:07.810612+00	20	L - Active: True	3		13	1
110	2019-03-23 16:17:07.826534+00	19	Kh - Active: False	3		13	1
111	2019-03-23 16:17:07.844618+00	18	K - Active: True	3		13	1
112	2019-03-23 16:17:07.865055+00	17	Y - Active: False	3		13	1
113	2019-03-23 16:17:07.883972+00	16	I - Active: True	3		13	1
114	2019-03-23 16:17:07.902843+00	15	T - Active: True	3		13	1
115	2019-03-23 16:17:07.927457+00	14	Ch - Active: True	3		13	1
116	2019-03-23 16:17:07.94576+00	13	Z - Active: True	3		13	1
117	2019-03-23 16:17:07.962599+00	12	W - Active: False	3		13	1
118	2019-03-23 16:17:07.977333+00	11	V - Active: False	3		13	1
119	2019-03-23 16:17:07.994871+00	10	U - Active: False	3		13	1
120	2019-03-23 16:17:08.009873+00	9	O - Active: True	3		13	1
121	2019-03-23 16:17:08.025756+00	8	H - Active: True	3		13	1
122	2019-03-23 16:17:08.040516+00	7	Dh - Active: False	3		13	1
123	2019-03-23 16:17:08.055558+00	6	D - Active: True	3		13	1
124	2019-03-23 16:17:08.067647+00	5	V - Active: False	3		13	1
125	2019-03-23 16:17:08.082951+00	4	B - Active: True	3		13	1
126	2019-03-23 16:17:08.098497+00	3	Gh - Active: False	3		13	1
127	2019-03-23 16:17:08.114686+00	2	G - Active: True	3		13	1
128	2019-03-23 16:17:08.129043+00	1	A - Active: True	3		13	1
129	2019-03-23 16:17:46.654627+00	31	Tau: ת Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "T - Active: True"}}, {"added": {"name": "letter power", "object": "Th - Active: False"}}]	14	1
130	2019-03-23 16:19:56.549149+00	30	Shin: ש Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "S - Shin: \\u05e9 Hebrew - Lang: Hebrew Active: True"}}, {"added": {"name": "letter power", "object": "Sh - Shin: \\u05e9 Hebrew - Lang: Hebrew Active: False"}}]	14	1
131	2019-03-23 16:20:30.901355+00	29	Resh: ר Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "R - Resh: \\u05e8 Hebrew - Lang: Hebrew Active: True"}}]	14	1
132	2019-03-23 16:22:28.494457+00	28	Qoph: ק Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "Q - Qoph: \\u05e7 Hebrew - Lang: Hebrew Active: True"}}]	14	1
133	2019-03-23 16:23:07.498045+00	27	Tzaddi - Final: ץ Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "Tz - Tzaddi - Final: \\u05e5 Hebrew - Lang: Hebrew Active: True"}}]	14	1
134	2019-03-23 16:23:29.06357+00	26	Tzaddi: צ Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "Tz - Tzaddi: \\u05e6 Hebrew - Lang: Hebrew Active: True"}}]	14	1
135	2019-03-23 16:24:07.809032+00	25	Peh - Final: ף Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "P - Peh - Final: \\u05e3 Hebrew - Lang: Hebrew Active: True"}}, {"added": {"name": "letter power", "object": "Ph - Peh - Final: \\u05e3 Hebrew - Lang: Hebrew Active: False"}}]	14	1
136	2019-03-23 16:24:29.408444+00	24	Peh: פ Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "P - Peh: \\u05e4 Hebrew - Lang: Hebrew Active: True"}}, {"added": {"name": "letter power", "object": "Ph - Peh: \\u05e4 Hebrew - Lang: Hebrew Active: False"}}]	14	1
137	2019-03-23 16:24:48.814089+00	23	Ayin: ע Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "Aa - Ayin: \\u05e2 Hebrew - Lang: Hebrew Active: True"}}, {"added": {"name": "letter power", "object": "O - Ayin: \\u05e2 Hebrew - Lang: Hebrew Active: False"}}]	14	1
138	2019-03-23 16:25:10.896024+00	22	Samekh: ס Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "S - Samekh: \\u05e1 Hebrew - Lang: Hebrew Active: True"}}]	14	1
199	2019-12-05 22:59:51.225034+00	23e380bf-5382-4d95-8376-face75b0579b	Greek	1	[{"added": {}}]	16	1
139	2019-03-23 16:25:29.742684+00	21	Nun - Final: ן Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "N - Nun - Final: \\u05df Hebrew - Lang: Hebrew Active: True"}}]	14	1
140	2019-03-23 16:25:45.401112+00	20	Nun: נ Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "N - Nun: \\u05e0 Hebrew - Lang: Hebrew Active: True"}}]	14	1
141	2019-03-23 16:26:43.414177+00	1	GematriaMethodLetterRule object (1)	1	[{"added": {}}]	19	1
142	2019-03-23 16:31:36.604409+00	1	Simple	2	[{"added": {"name": "gematria method letter rule", "object": "Aleph: \\u05d0 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Beth: \\u05d1 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Gimel: \\u05d2 Hebrew - Lang: Hebrew - Method: Simple"}}]	21	1
143	2019-03-23 16:33:18.531599+00	1	Simple	2	[]	21	1
144	2019-03-23 16:37:31.725314+00	1	Simple	2	[{"added": {"name": "gematria method letter rule", "object": "Daleth: \\u05d3 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "He: \\u05d4 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Vau: \\u05d5 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Zayin: \\u05d6 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Chet: \\u05d7 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Teth: \\u05d8 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Yod: \\u05d9 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Kaph: \\u05db Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Kaph - Final: \\u05da Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Lamed: \\u05dc Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Mem: \\u05de Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Mem - Final: \\u05dd Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Nun: \\u05e0 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Nun - Final: \\u05df Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Samekh: \\u05e1 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Ayin: \\u05e2 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Peh: \\u05e4 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Peh - Final: \\u05e3 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Tzaddi: \\u05e6 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Tzaddi - Final: \\u05e5 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Qoph: \\u05e7 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Resh: \\u05e8 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Shin: \\u05e9 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Tau: \\u05ea Hebrew - Lang: Hebrew - Method: Simple"}}]	21	1
145	2019-03-23 16:39:56.737529+00	5	Aleph: א Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["letter_order"]}}]	14	1
146	2019-03-23 16:40:10.276211+00	6	Beth: ב Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["letter_order"]}}]	14	1
147	2019-03-23 16:40:45.066491+00	6	Beth: ב Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "B - Beth: \\u05d1 Hebrew - Lang: Hebrew Active: True"}}, {"added": {"name": "letter power", "object": "V - Beth: \\u05d1 Hebrew - Lang: Hebrew Active: False"}}]	14	1
148	2019-03-23 16:42:56.794762+00	2	Regular	1	[{"added": {}}]	21	1
149	2019-03-23 16:49:54.438797+00	2	Regular	2	[{"added": {"name": "gematria method letter rule", "object": "Aleph: \\u05d0 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Beth: \\u05d1 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Gimel: \\u05d2 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Daleth: \\u05d3 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "He: \\u05d4 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Vau: \\u05d5 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Zayin: \\u05d6 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Chet: \\u05d7 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Teth: \\u05d8 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Yod: \\u05d9 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Kaph: \\u05db Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Kaph - Final: \\u05da Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Lamed: \\u05dc Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Mem: \\u05de Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Mem - Final: \\u05dd Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Nun: \\u05e0 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Nun - Final: \\u05df Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Samekh: \\u05e1 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Ayin: \\u05e2 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Peh: \\u05e4 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Peh - Final: \\u05e3 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Tzaddi: \\u05e6 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Tzaddi - Final: \\u05e5 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Qoph: \\u05e7 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Resh: \\u05e8 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Shin: \\u05e9 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Tau: \\u05ea Hebrew - Lang: Hebrew - Method: Regular"}}]	21	1
150	2019-03-23 16:55:45.85891+00	1	Word object (1)	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "WordMeaning object (1)"}}]	18	1
151	2019-03-30 19:43:32.057107+00	2	Jehovah - יהוה	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "WordMeaning object (2)"}}]	18	1
152	2019-03-30 20:07:54.407092+00	2	Jehovah - יהוה	2	[{"added": {"name": "word spelling", "object": "WordSpelling object (1)"}}, {"added": {"name": "word spelling", "object": "WordSpelling object (2)"}}, {"added": {"name": "word spelling", "object": "WordSpelling object (3)"}}, {"added": {"name": "word spelling", "object": "WordSpelling object (4)"}}]	18	1
153	2019-03-30 22:00:39.77382+00	2	Jehovah - יהוה	2	[]	18	1
154	2019-12-02 16:01:45.051548+00	2	English	1	[{"added": {}}]	16	1
155	2019-12-02 16:02:02.212206+00	1	Hebrew - Lang: Hebrew	2	[]	15	1
156	2019-12-02 16:02:34.195395+00	2	English - Lang: English	1	[{"added": {}}]	15	1
157	2019-12-02 16:51:28.319641+00	2	English - Lang: English	2	[{"changed": {"fields": ["characters"]}}]	15	1
158	2019-12-02 17:08:52.872584+00	5	Aleph: א Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}]	14	1
159	2019-12-02 17:30:21.812764+00	1	Jehovah - יהוה - 26.0 : Simple	1	[{"added": {}}]	24	1
160	2019-12-02 17:31:11.209238+00	1	Kether - כתר	2	[{"changed": {"fields": ["language"]}}]	18	1
161	2019-12-02 17:31:17.836619+00	2	Jehovah - יהוה	2	[{"changed": {"fields": ["language"]}}]	18	1
162	2019-12-02 17:35:07.07687+00	1	Kether - כתר : Hebrew	2	[]	18	1
163	2019-12-02 17:49:54.122767+00	1	Kether - כתר : Hebrew	2	[]	18	1
164	2019-12-02 17:54:32.937899+00	1	Kether - כתר : Hebrew	2	[]	18	1
165	2019-12-02 17:55:33.057764+00	1	Kether - כתרכ : Hebrew	2	[{"changed": {"fields": ["name_original_language"]}}]	18	1
166	2019-12-02 17:58:12.178956+00	5	Kether - כתרכ : Hebrew - 640.0 : Regular	3		24	1
167	2019-12-02 17:58:12.208929+00	4	Kether - כתרכ : Hebrew - 640.0 : Simple	3		24	1
168	2019-12-02 17:58:12.265563+00	3	Kether - כתרכ : Hebrew - 620.0 : Regular	3		24	1
169	2019-12-02 17:58:12.334944+00	2	Kether - כתרכ : Hebrew - 620.0 : Simple	3		24	1
170	2019-12-02 18:05:57.831564+00	1	Kether - כתר : Hebrew	2	[{"changed": {"fields": ["name_original_language"]}}]	18	1
171	2019-12-02 18:06:27.096611+00	15	Kether - כתר : Hebrew - 620.0 : Regular	3		24	1
172	2019-12-02 18:06:27.130798+00	14	Kether - כתר : Hebrew - 420.0 : Regular	3		24	1
173	2019-12-02 18:06:27.158082+00	13	Kether - כתר : Hebrew - 20.0 : Regular	3		24	1
174	2019-12-02 18:06:27.197255+00	12	Kether - כתר : Hebrew - 620.0 : Simple	3		24	1
175	2019-12-02 18:06:27.224918+00	11	Kether - כתר : Hebrew - 420.0 : Simple	3		24	1
176	2019-12-02 18:06:27.306112+00	10	Kether - כתר : Hebrew - 20.0 : Simple	3		24	1
177	2019-12-02 18:06:35.865413+00	1	Kether - כתר : Hebrew	2	[]	18	1
178	2019-12-02 18:07:13.410475+00	21	Kether - כתר : Hebrew - 620.0 : Regular	3		24	1
179	2019-12-02 18:07:13.441333+00	20	Kether - כתר : Hebrew - 420.0 : Regular	3		24	1
180	2019-12-02 18:07:13.467648+00	19	Kether - כתר : Hebrew - 20.0 : Regular	3		24	1
181	2019-12-02 18:07:13.493108+00	18	Kether - כתר : Hebrew - 620.0 : Simple	3		24	1
182	2019-12-02 18:07:13.537845+00	17	Kether - כתר : Hebrew - 420.0 : Simple	3		24	1
183	2019-12-02 18:07:13.612392+00	16	Kether - כתר : Hebrew - 20.0 : Simple	3		24	1
184	2019-12-02 18:07:21.832884+00	1	Kether - כתר : Hebrew	2	[]	18	1
185	2019-12-02 18:09:40.052467+00	1	Kether - כתר : Hebrew	2	[]	18	1
186	2019-12-02 18:13:55.546758+00	3	Greek	1	[{"added": {}}]	16	1
187	2019-12-02 18:14:02.725637+00	4	English	1	[{"added": {}}]	16	1
188	2019-12-05 22:02:17.011985+00	0ac22e10-dbf8-44ec-acce-ab9b20225cf6	Hebrew	1	[{"added": {}}]	16	1
189	2019-12-05 22:08:36.836078+00	3	Jah - יה : Hebrew	2	[{"changed": {"fields": ["language"]}}]	18	1
190	2019-12-05 22:08:51.035037+00	2	Jehovah - יהוה : Hebrew	2	[{"changed": {"fields": ["language"]}}]	18	1
191	2019-12-05 22:09:02.346788+00	1	Kether - כתר : Hebrew	2	[{"changed": {"fields": ["language"]}}]	18	1
192	2019-12-05 22:09:20.300478+00	1	Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["language"]}}]	15	1
193	2019-12-05 22:09:28.32459+00	2	English - Lang: Hebrew	2	[{"changed": {"fields": ["language"]}}]	15	1
194	2019-12-05 22:09:46.025884+00	5	Hebrew	3		16	1
195	2019-12-05 22:10:04.844378+00	4	English	3		16	1
196	2019-12-05 22:10:04.867255+00	3	Greek	3		16	1
197	2019-12-05 22:10:04.888671+00	2	English	3		16	1
198	2019-12-05 22:59:45.348179+00	a45331a5-3beb-4562-8234-4f25199a4b76	English	1	[{"added": {}}]	16	1
200	2019-12-06 23:20:45.077637+00	6	Mayim - מיים : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Mayim - \\u05de\\u05d9\\u05d9\\u05dd : Hebrew - Water"}}]	18	1
201	2019-12-06 23:21:52.471115+00	6	Mayim - מיים : Hebrew	2	[]	18	1
202	2019-12-06 23:22:21.761478+00	7	Ruach - רוח : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Ruach - \\u05e8\\u05d5\\u05d7 : Hebrew - Life Breath"}}, {"added": {"name": "word meaning", "object": "Ruach - \\u05e8\\u05d5\\u05d7 : Hebrew - Air"}}]	18	1
203	2019-12-06 23:38:24.178749+00	7	Ruach - רוח : Hebrew	2	[]	18	1
204	2019-12-06 23:39:25.442098+00	8	Chokmah - חכמה : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Chokmah - \\u05d7\\u05db\\u05de\\u05d4 : Hebrew - Wisdom"}}]	18	1
205	2019-12-06 23:40:36.763218+00	9	Kachmah - כחמה : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Kachmah - \\u05db\\u05d7\\u05de\\u05d4 : Hebrew - Power of What"}}, {"added": {"name": "word meaning", "object": "Kachmah - \\u05db\\u05d7\\u05de\\u05d4 : Hebrew - Hot"}}, {"added": {"name": "word meaning", "object": "Kachmah - \\u05db\\u05d7\\u05de\\u05d4 : Hebrew - Warm"}}]	18	1
206	2019-12-06 23:42:00.18379+00	2	Jehovah - יהוה : Hebrew	2	[{"changed": {"fields": ["language"]}}]	18	1
207	2019-12-06 23:42:14.950336+00	3	Jah - יה : Hebrew	2	[{"changed": {"fields": ["language"]}}]	18	1
208	2019-12-06 23:42:37.050014+00	1	Kether - כתר : Hebrew	2	[{"changed": {"fields": ["language"]}}]	18	1
209	2019-12-06 23:44:33.017857+00	9	Kachmah - כחמה : Hebrew	2	[]	18	1
210	2019-12-06 23:50:02.317327+00	6	Mayim - מיים : Hebrew	2	[]	18	1
211	2019-12-06 23:51:57.916868+00	8	Chokmah - חכמה : Hebrew	2	[]	18	1
212	2019-12-06 23:52:08.661229+00	7	Ruach - רוח : Hebrew	2	[]	18	1
213	2019-12-06 23:52:10.213306+00	9	Kachmah - כחמה : Hebrew	2	[]	18	1
214	2019-12-07 01:36:23.350718+00	10	galah - גלה : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "galah - \\u05d2\\u05dc\\u05d4 : Hebrew - To lay bare"}}, {"added": {"name": "word meaning", "object": "galah - \\u05d2\\u05dc\\u05d4 : Hebrew - to denude"}}, {"added": {"name": "word meaning", "object": "galah - \\u05d2\\u05dc\\u05d4 : Hebrew - to strip of concealment"}}, {"added": {"name": "word meaning", "object": "galah - \\u05d2\\u05dc\\u05d4 : Hebrew - Find Out"}}]	18	1
215	2019-12-07 01:42:44.419114+00	12	galah sodo - גלה סודו : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "galah sodo - \\u05d2\\u05dc\\u05d4 \\u05e1\\u05d5\\u05d3\\u05d5 : Hebrew - he revealeth his secret"}}]	18	1
216	2019-12-11 19:55:11.033859+00	13	Hod - הוד : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Hod - \\u05d4\\u05d5\\u05d3 : Hebrew - Glory"}}, {"added": {"name": "word meaning", "object": "Hod - \\u05d4\\u05d5\\u05d3 : Hebrew - splendor"}}]	18	1
217	2019-12-11 23:05:14.183752+00	14	mitsrayim - מצרים : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "mitsrayim - \\u05de\\u05e6\\u05e8\\u05d9\\u05dd : Hebrew - Egypt"}}]	18	1
218	2019-12-14 16:38:10.326878+00	15	MTzPVN ZHB IAThH - מצפון זהב יאתה : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "MTzPVN ZHB IAThH - \\u05de\\u05e6\\u05e4\\u05d5\\u05df \\u05d6\\u05d4\\u05d1 \\u05d9\\u05d0\\u05ea\\u05d4 : Hebrew - Fair weather cometh from the north"}}, {"added": {"name": "word meaning", "object": "MTzPVN ZHB IAThH - \\u05de\\u05e6\\u05e4\\u05d5\\u05df \\u05d6\\u05d4\\u05d1 \\u05d9\\u05d0\\u05ea\\u05d4 : Hebrew - Gold Conscience You"}}]	18	1
219	2019-12-14 16:40:18.235653+00	16	Esh hashamaim - אש השמים : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Esh hashamaim - \\u05d0\\u05e9 \\u05d4\\u05e9\\u05de\\u05d9\\u05dd : Hebrew - Fire of Heaven"}}, {"added": {"name": "word meaning", "object": "Esh hashamaim - \\u05d0\\u05e9 \\u05d4\\u05e9\\u05de\\u05d9\\u05dd : Hebrew - Le Feu de Ciel. The name of K16 in French"}}]	18	1
220	2019-12-15 23:43:03.776378+00	17	Zibeth - צבת : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Zibeth - \\u05e6\\u05d1\\u05ea : Hebrew - Handful"}}]	18	1
221	2019-12-15 23:44:37.249725+00	17	Zibeth - צבת : Hebrew	2	[{"added": {"name": "word meaning", "object": "Zibeth - \\u05e6\\u05d1\\u05ea : Hebrew - Pliers"}}, {"added": {"name": "word meaning", "object": "Zibeth - \\u05e6\\u05d1\\u05ea : Hebrew - Pincers"}}, {"added": {"name": "word meaning", "object": "Zibeth - \\u05e6\\u05d1\\u05ea : Hebrew - Tweezers"}}, {"added": {"name": "word meaning", "object": "Zibeth - \\u05e6\\u05d1\\u05ea : Hebrew - Tongs"}}]	18	1
222	2019-12-15 23:50:40.652142+00	18	tsore olahmim - צור עולמים : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "tsore olahmim - \\u05e6\\u05d5\\u05e8 \\u05e2\\u05d5\\u05dc\\u05de\\u05d9\\u05dd : Hebrew - Everlasting Rock"}}, {"added": {"name": "word meaning", "object": "tsore olahmim - \\u05e6\\u05d5\\u05e8 \\u05e2\\u05d5\\u05dc\\u05de\\u05d9\\u05dd : Hebrew - Create worlds"}}, {"added": {"name": "word meaning", "object": "tsore olahmim - \\u05e6\\u05d5\\u05e8 \\u05e2\\u05d5\\u05dc\\u05de\\u05d9\\u05dd : Hebrew - Everlasting Strength"}}]	18	1
223	2019-12-17 00:04:21.072128+00	19	Achad - אחד : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Achad - \\u05d0\\u05d7\\u05d3 : Hebrew - One"}}]	18	1
224	2019-12-17 00:06:08.577633+00	20	Ach - אח : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Ach - \\u05d0\\u05d7 : Hebrew - Brother"}}, {"added": {"name": "word meaning", "object": "Ach - \\u05d0\\u05d7 : Hebrew - Friar"}}, {"added": {"name": "word meaning", "object": "Ach - \\u05d0\\u05d7 : Hebrew - Kinsman"}}, {"added": {"name": "word meaning", "object": "Ach - \\u05d0\\u05d7 : Hebrew - Fellow"}}, {"added": {"name": "word meaning", "object": "Ach - \\u05d0\\u05d7 : Hebrew - Hearth"}}, {"added": {"name": "word meaning", "object": "Ach - \\u05d0\\u05d7 : Hebrew - Fireplace"}}]	18	1
225	2019-12-17 00:07:53.943926+00	21	Bohu - בהו : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Bohu - \\u05d1\\u05d4\\u05d5 : Hebrew - Emptiness"}}, {"added": {"name": "word meaning", "object": "Bohu - \\u05d1\\u05d4\\u05d5 : Hebrew - Chaos"}}, {"added": {"name": "word meaning", "object": "Bohu - \\u05d1\\u05d4\\u05d5 : Hebrew - Void"}}, {"added": {"name": "word meaning", "object": "Bohu - \\u05d1\\u05d4\\u05d5 : Hebrew - Confusion"}}]	18	1
226	2019-12-17 00:13:05.102058+00	26	הגהHegeh - הגה : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "\\u05d4\\u05d2\\u05d4Hegeh - \\u05d4\\u05d2\\u05d4 : Hebrew - Sound"}}, {"added": {"name": "word meaning", "object": "\\u05d4\\u05d2\\u05d4Hegeh - \\u05d4\\u05d2\\u05d4 : Hebrew - Muttering"}}, {"added": {"name": "word meaning", "object": "\\u05d4\\u05d2\\u05d4Hegeh - \\u05d4\\u05d2\\u05d4 : Hebrew - Thought"}}]	18	1
227	2019-12-17 00:13:24.695512+00	26	Hegeh - הגה : Hebrew	2	[{"changed": {"fields": ["name_english"]}}]	18	1
228	2019-12-17 00:14:09.002155+00	26	Hegeh - הגה : Hebrew	2	[{"added": {"name": "word meaning", "object": "Hegeh - \\u05d4\\u05d2\\u05d4 : Hebrew - Wheel"}}, {"added": {"name": "word meaning", "object": "Hegeh - \\u05d4\\u05d2\\u05d4 : Hebrew - Rudder"}}, {"added": {"name": "word meaning", "object": "Hegeh - \\u05d4\\u05d2\\u05d4 : Hebrew - Helm"}}, {"added": {"name": "word meaning", "object": "Hegeh - \\u05d4\\u05d2\\u05d4 : Hebrew - Steering wheel"}}]	18	1
229	2019-12-17 00:16:13.419473+00	27	Khool - חול : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Khool - \\u05d7\\u05d5\\u05dc : Hebrew - Sand"}}, {"added": {"name": "word meaning", "object": "Khool - \\u05d7\\u05d5\\u05dc : Hebrew - Related to the First Matter, alchemists often call this their Phoenix"}}]	18	1
230	2019-12-17 00:17:15.877798+00	27	Khool - חול : Hebrew	2	[{"added": {"name": "word meaning", "object": "Khool - \\u05d7\\u05d5\\u05dc : Hebrew - As a verb - to turn round, to twist, to whirl"}}]	18	1
231	2019-12-17 00:52:37.933111+00	28	Dam - דם : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Dam - \\u05d3\\u05dd : Hebrew - Blood"}}]	18	1
232	2019-12-17 01:16:35.437543+00	29	Nachash - נחש : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Nachash - \\u05e0\\u05d7\\u05e9 : Hebrew - Copper"}}, {"added": {"name": "word meaning", "object": "Nachash - \\u05e0\\u05d7\\u05e9 : Hebrew - Serpent"}}, {"added": {"name": "word meaning", "object": "Nachash - \\u05e0\\u05d7\\u05e9 : Hebrew - Snake"}}, {"added": {"name": "word meaning", "object": "Nachash - \\u05e0\\u05d7\\u05e9 : Hebrew - Sorcery"}}, {"added": {"name": "word meaning", "object": "Nachash - \\u05e0\\u05d7\\u05e9 : Hebrew - Magic"}}]	18	1
233	2019-12-17 01:17:50.620074+00	30	Messiach - משיח : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Messiach - \\u05de\\u05e9\\u05d9\\u05d7 : Hebrew - The Anointed"}}, {"added": {"name": "word meaning", "object": "Messiach - \\u05de\\u05e9\\u05d9\\u05d7 : Hebrew - Messiah"}}]	18	1
234	2019-12-17 01:19:09.511774+00	31	Messia - משי : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Messia - \\u05de\\u05e9\\u05d9 : Hebrew - Silk"}}, {"added": {"name": "word meaning", "object": "Messia - \\u05de\\u05e9\\u05d9 : Hebrew - Satin"}}]	18	1
235	2019-12-17 23:43:15.896228+00	32	malak - מלאך : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "malak - \\u05de\\u05dc\\u05d0\\u05da : Hebrew - One sent"}}, {"added": {"name": "word meaning", "object": "malak - \\u05de\\u05dc\\u05d0\\u05da : Hebrew - Angel"}}]	18	1
236	2019-12-17 23:46:33.89819+00	33	sokeh - סוכה : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "sokeh - \\u05e1\\u05d5\\u05db\\u05d4 : Hebrew - Branch"}}, {"added": {"name": "word meaning", "object": "sokeh - \\u05e1\\u05d5\\u05db\\u05d4 : Hebrew - Bough"}}, {"added": {"name": "word meaning", "object": "sokeh - \\u05e1\\u05d5\\u05db\\u05d4 : Hebrew - Succah"}}]	18	1
237	2019-12-17 23:49:40.904312+00	34	Jehovah elohino Jehovah - יהוה אלהינו יהוה : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Jehovah elohino Jehovah - \\u05d9\\u05d4\\u05d5\\u05d4 \\u05d0\\u05dc\\u05d4\\u05d9\\u05e0\\u05d5 \\u05d9\\u05d4\\u05d5\\u05d4 : Hebrew - Jehovah, our God Jehovah"}}]	18	1
238	2019-12-17 23:52:04.932899+00	35	be-Tzion - בציון : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "be-Tzion - \\u05d1\\u05e6\\u05d9\\u05d5\\u05df : Hebrew - In Zion"}}, {"added": {"name": "word meaning", "object": "be-Tzion - \\u05d1\\u05e6\\u05d9\\u05d5\\u05df : Hebrew - CENTRE of human personality, the Point Within, where man makes direct contact with the One Reality"}}]	18	1
239	2019-12-17 23:55:00.518917+00	36	Mem chaiim - מים חיים : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Mem chaiim - \\u05de\\u05d9\\u05dd \\u05d7\\u05d9\\u05d9\\u05dd : Hebrew - the fountain of living waters"}}, {"added": {"name": "word meaning", "object": "Mem chaiim - \\u05de\\u05d9\\u05dd \\u05d7\\u05d9\\u05d9\\u05dd : Hebrew - Living Water"}}, {"added": {"name": "word meaning", "object": "Mem chaiim - \\u05de\\u05d9\\u05dd \\u05d7\\u05d9\\u05d9\\u05dd : Hebrew - spring water"}}]	18	1
240	2019-12-18 00:04:19.160135+00	37	Israel - ישראל : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Israel - \\u05d9\\u05e9\\u05e8\\u05d0\\u05dc : Hebrew - Israel"}}]	18	1
241	2019-12-18 00:18:00.869087+00	38	Adam - אדם : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Adam - \\u05d0\\u05d3\\u05dd : Hebrew - spiritual blood. Adam is Aleph or Ruach with dam or blood"}}, {"added": {"name": "word meaning", "object": "Adam - \\u05d0\\u05d3\\u05dd : Hebrew - Man"}}]	18	1
242	2019-12-18 00:29:52.672772+00	39	magnesia - מאגנטיה : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "magnesia - \\u05de\\u05d0\\u05d2\\u05e0\\u05d8\\u05d9\\u05d4 : Hebrew - magnesia spelt phonetically. Magnet of Jah"}}]	18	1
243	2019-12-18 00:30:47.294709+00	39	magnesia - מאגנטיה : Hebrew	2	[]	18	1
244	2019-12-18 00:31:14.482553+00	40	Magnetia - מגנטיה : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Magnetia - \\u05de\\u05d2\\u05e0\\u05d8\\u05d9\\u05d4 : Hebrew - magnet"}}]	18	1
245	2019-12-18 16:29:04.704176+00	3	Miliui, Letters Spelled in Full	1	[{"added": {}}, {"added": {"name": "gematria method letter rule", "object": "Aleph: \\u05d0 Hebrew - Lang: Hebrew : value = 111.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Beth: \\u05d1 Hebrew - Lang: Hebrew : value = 412.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Gimel: \\u05d2 Hebrew - Lang: Hebrew : value = 73.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Daleth: \\u05d3 Hebrew - Lang: Hebrew : value = 474.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "He: \\u05d4 Hebrew - Lang: Hebrew : value = 6.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Vau: \\u05d5 Hebrew - Lang: Hebrew : value = 12.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Zayin: \\u05d6 Hebrew - Lang: Hebrew : value = 67.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Chet: \\u05d7 Hebrew - Lang: Hebrew : value = 418.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Teth: \\u05d8 Hebrew - Lang: Hebrew : value = 419.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Yod: \\u05d9 Hebrew - Lang: Hebrew : value = 20.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Kaph - Final: \\u05da Hebrew - Lang: Hebrew : value = 100.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Kaph: \\u05db Hebrew - Lang: Hebrew : value = 100.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Lamed: \\u05dc Hebrew - Lang: Hebrew : value = 74.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Mem - Final: \\u05dd Hebrew - Lang: Hebrew : value = 90.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Mem: \\u05de Hebrew - Lang: Hebrew : value = 90.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Nun - Final: \\u05df Hebrew - Lang: Hebrew : value = 106.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Nun: \\u05e0 Hebrew - Lang: Hebrew : value = 106.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Peh - Final: \\u05e3 Hebrew - Lang: Hebrew : value = 91.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Peh: \\u05e4 Hebrew - Lang: Hebrew : value = 91.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Tzaddi - Final: \\u05e5 Hebrew - Lang: Hebrew : value = 104.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Tzaddi: \\u05e6 Hebrew - Lang: Hebrew : value = 104.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Qoph: \\u05e7 Hebrew - Lang: Hebrew : value = 186.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Samekh: \\u05e1 Hebrew - Lang: Hebrew : value = 120.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Ayin: \\u05e2 Hebrew - Lang: Hebrew : value = 130.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Resh: \\u05e8 Hebrew - Lang: Hebrew : value = 510.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Shin: \\u05e9 Hebrew - Lang: Hebrew : value = 360.0 - Method: Miliui, Letters Spelled in Full"}}, {"added": {"name": "gematria method letter rule", "object": "Tau: \\u05ea Hebrew - Lang: Hebrew : value = 406.0 - Method: Miliui, Letters Spelled in Full"}}]	21	1
246	2019-12-18 16:37:01.609348+00	4	Regular Polygons Inscribed in a Circle, Number of Edges	1	[{"added": {}}, {"added": {"name": "gematria method letter rule", "object": "Aleph: \\u05d0 Hebrew - Lang: Hebrew : value = 3.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Beth: \\u05d1 Hebrew - Lang: Hebrew : value = 4.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Gimel: \\u05d2 Hebrew - Lang: Hebrew : value = 5.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Daleth: \\u05d3 Hebrew - Lang: Hebrew : value = 6.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "He: \\u05d4 Hebrew - Lang: Hebrew : value = 8.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Vau: \\u05d5 Hebrew - Lang: Hebrew : value = 9.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Zayin: \\u05d6 Hebrew - Lang: Hebrew : value = 10.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Chet: \\u05d7 Hebrew - Lang: Hebrew : value = 12.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Teth: \\u05d8 Hebrew - Lang: Hebrew : value = 15.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Yod: \\u05d9 Hebrew - Lang: Hebrew : value = 18.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Kaph - Final: \\u05da Hebrew - Lang: Hebrew : value = 20.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Kaph: \\u05db Hebrew - Lang: Hebrew : value = 20.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Lamed: \\u05dc Hebrew - Lang: Hebrew : value = 24.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Mem - Final: \\u05dd Hebrew - Lang: Hebrew : value = 30.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Mem: \\u05de Hebrew - Lang: Hebrew : value = 30.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Nun - Final: \\u05df Hebrew - Lang: Hebrew : value = 36.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Nun: \\u05e0 Hebrew - Lang: Hebrew : value = 36.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Samekh: \\u05e1 Hebrew - Lang: Hebrew : value = 40.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Ayin: \\u05e2 Hebrew - Lang: Hebrew : value = 45.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Peh - Final: \\u05e3 Hebrew - Lang: Hebrew : value = 60.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Peh: \\u05e4 Hebrew - Lang: Hebrew : value = 60.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Tzaddi - Final: \\u05e5 Hebrew - Lang: Hebrew : value = 72.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Tzaddi: \\u05e6 Hebrew - Lang: Hebrew : value = 72.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Qoph: \\u05e7 Hebrew - Lang: Hebrew : value = 90.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Resh: \\u05e8 Hebrew - Lang: Hebrew : value = 120.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Shin: \\u05e9 Hebrew - Lang: Hebrew : value = 180.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}, {"added": {"name": "gematria method letter rule", "object": "Tau: \\u05ea Hebrew - Lang: Hebrew : value = 360.0 - Method: Regular Polygons Inscribed in a Circle, Number of Edges"}}]	21	1
247	2019-12-18 23:32:06.136912+00	41	khammaw - חמה : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "khammaw - \\u05d7\\u05de\\u05d4 : Hebrew - Sun"}}, {"added": {"name": "word meaning", "object": "khammaw - \\u05d7\\u05de\\u05d4 : Hebrew - rage"}}, {"added": {"name": "word meaning", "object": "khammaw - \\u05d7\\u05de\\u05d4 : Hebrew - heat"}}]	18	1
248	2019-12-18 23:34:16.303889+00	41	khammaw - חמה : Hebrew	2	[{"changed": {"name": "word meaning", "object": "khammaw - \\u05d7\\u05de\\u05d4 : Hebrew - Sun. refers to the angle of Osiris and Horus in the pythagorean triangle, they are also solar deities", "fields": ["meaning"]}}]	18	1
249	2019-12-19 23:14:24.839652+00	42	Gimmel - גמל : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Gimmel - \\u05d2\\u05de\\u05dc : Hebrew - Camel"}}]	18	1
250	2019-12-19 23:15:27.334175+00	43	Nephesh - נפש : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Nephesh - \\u05e0\\u05e4\\u05e9 : Hebrew - vital or animal soul"}}]	18	1
251	2019-12-20 19:00:22.106819+00	44	Tzaddi - צ : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Tzaddi - \\u05e6 : Hebrew - Fish Hook"}}, {"added": {"name": "word meaning", "object": "Tzaddi - \\u05e6 : Hebrew - to think"}}, {"added": {"name": "word meaning", "object": "Tzaddi - \\u05e6 : Hebrew - to speculate"}}, {"added": {"name": "word meaning", "object": "Tzaddi - \\u05e6 : Hebrew - to fancy"}}]	18	1
252	2019-12-21 22:38:31.458195+00	45	Ischschamaim - אש ומים : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Ischschamaim - \\u05d0\\u05e9 \\u05d5\\u05de\\u05d9\\u05dd : Hebrew - Fire and Water"}}, {"added": {"name": "word meaning", "object": "Ischschamaim - \\u05d0\\u05e9 \\u05d5\\u05de\\u05d9\\u05dd : Hebrew - Sulphur and Mercury"}}]	18	1
253	2019-12-21 22:59:43.481468+00	46	dagan - דגן : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "dagan - \\u05d3\\u05d2\\u05df : Hebrew - grain"}}]	18	1
254	2019-12-21 23:01:27.881064+00	47	daleth - דלת : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "daleth - \\u05d3\\u05dc\\u05ea : Hebrew - door"}}, {"added": {"name": "word meaning", "object": "daleth - \\u05d3\\u05dc\\u05ea : Hebrew - Fourth letter of the Hebrew alphabet spelt in full"}}]	18	1
255	2019-12-21 23:03:05.840117+00	48	tal ha-shamaim - טל השמים : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "tal ha-shamaim - \\u05d8\\u05dc \\u05d4\\u05e9\\u05de\\u05d9\\u05dd : Hebrew - dew of heaven"}}]	18	1
256	2019-12-21 23:21:06.513043+00	50	eth-abika - את אביך : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "eth-abika - \\u05d0\\u05ea \\u05d0\\u05d1\\u05d9\\u05da : Hebrew - the essence of thy father"}}]	18	1
257	2019-12-21 23:23:58.711577+00	51	shemeni ha-eretz - שמני הארץ : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "shemeni ha-eretz - \\u05e9\\u05de\\u05e0\\u05d9 \\u05d4\\u05d0\\u05e8\\u05e5 : Hebrew - Oiliness of the Earth"}}, {"added": {"name": "word meaning", "object": "shemeni ha-eretz - \\u05e9\\u05de\\u05e0\\u05d9 \\u05d4\\u05d0\\u05e8\\u05e5 : Hebrew - Oils of the earth"}}]	18	1
258	2019-12-21 23:25:35.911333+00	52	shemeni ha-eretz - שמני הארץ : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "shemeni ha-eretz - \\u05e9\\u05de\\u05e0\\u05d9 \\u05d4\\u05d0\\u05e8\\u05e5 : Hebrew - Oiliness of the Earth"}}, {"added": {"name": "word meaning", "object": "shemeni ha-eretz - \\u05e9\\u05de\\u05e0\\u05d9 \\u05d4\\u05d0\\u05e8\\u05e5 : Hebrew - Oils of the earth"}}, {"added": {"name": "word meaning", "object": "shemeni ha-eretz - \\u05e9\\u05de\\u05e0\\u05d9 \\u05d4\\u05d0\\u05e8\\u05e5 : Hebrew - Same value as Genesis 1:5 \\"And God called the light Day.\\""}}]	18	1
259	2019-12-21 23:26:29.889673+00	53	tsoreth - צורת : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "tsoreth - \\u05e6\\u05d5\\u05e8\\u05ea : Hebrew - form"}}, {"added": {"name": "word meaning", "object": "tsoreth - \\u05e6\\u05d5\\u05e8\\u05ea : Hebrew - shape"}}]	18	1
260	2019-12-21 23:30:54.718761+00	54	tsoor - צור : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "tsoor - \\u05e6\\u05d5\\u05e8 : Hebrew - rock"}}, {"added": {"name": "word meaning", "object": "tsoor - \\u05e6\\u05d5\\u05e8 : Hebrew - fortress"}}, {"added": {"name": "word meaning", "object": "tsoor - \\u05e6\\u05d5\\u05e8 : Hebrew - To press, to confine, to render compact."}}]	18	1
261	2019-12-21 23:33:01.038995+00	55	shemen - שמן : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "shemen - \\u05e9\\u05de\\u05df : Hebrew - oil"}}, {"added": {"name": "word meaning", "object": "shemen - \\u05e9\\u05de\\u05df : Hebrew - fat"}}]	18	1
262	2019-12-21 23:33:16.357338+00	55	shemen - שמן : Hebrew	2	[]	18	1
263	2019-12-21 23:35:10.54891+00	56	zakar ve-nequbah - זכר ונקבה : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "zakar ve-nequbah - \\u05d6\\u05db\\u05e8 \\u05d5\\u05e0\\u05e7\\u05d1\\u05d4 : Hebrew - male and female"}}]	18	1
264	2019-12-21 23:36:55.689956+00	56	zakar ve-nequbah - זכר ונקבה : Hebrew	2	[]	18	1
265	2019-12-21 23:38:06.503654+00	57	sepharim - ספרים : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "sepharim - \\u05e1\\u05e4\\u05e8\\u05d9\\u05dd : Hebrew - letters"}}, {"added": {"name": "word meaning", "object": "sepharim - \\u05e1\\u05e4\\u05e8\\u05d9\\u05dd : Hebrew - Books"}}]	18	1
266	2019-12-21 23:39:03.386968+00	58	shamaim - שמים : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "shamaim - \\u05e9\\u05de\\u05d9\\u05dd : Hebrew - heaven"}}]	18	1
267	2020-01-13 21:08:04.444441+00	59	aur mopeleh - אור מופלא : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "aur mopeleh - \\u05d0\\u05d5\\u05e8 \\u05de\\u05d5\\u05e4\\u05dc\\u05d0 : Hebrew - Hidden Light"}}, {"added": {"name": "word meaning", "object": "aur mopeleh - \\u05d0\\u05d5\\u05e8 \\u05de\\u05d5\\u05e4\\u05dc\\u05d0 : Hebrew - Wonderful light"}}]	18	1
268	2020-01-13 21:10:07.971386+00	60	aur peshut - אור פשוט : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "aur peshut - \\u05d0\\u05d5\\u05e8 \\u05e4\\u05e9\\u05d5\\u05d8 : Hebrew - Simplest Light"}}]	18	1
269	2020-01-13 21:12:46.61436+00	61	aur pemini - אור פנימי : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "aur pemini - \\u05d0\\u05d5\\u05e8 \\u05e4\\u05e0\\u05d9\\u05de\\u05d9 : Hebrew - Inner Light"}}]	18	1
270	2020-01-13 21:18:27.79116+00	62	nequdah rashunah - נקודה ראשונה : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "nequdah rashunah - \\u05e0\\u05e7\\u05d5\\u05d3\\u05d4 \\u05e8\\u05d0\\u05e9\\u05d5\\u05e0\\u05d4 : Hebrew - Primordial Point, Kether"}}, {"added": {"name": "word meaning", "object": "nequdah rashunah - \\u05e0\\u05e7\\u05d5\\u05d3\\u05d4 \\u05e8\\u05d0\\u05e9\\u05d5\\u05e0\\u05d4 : Hebrew - First Point"}}]	18	1
271	2020-01-13 21:19:57.181822+00	62	nequdah rashunah - נקודה ראשונה : Hebrew	2	[{"changed": {"name": "word meaning", "object": "nequdah rashunah - \\u05e0\\u05e7\\u05d5\\u05d3\\u05d4 \\u05e8\\u05d0\\u05e9\\u05d5\\u05e0\\u05d4 : Hebrew - Primordial Point. Kethe also called the \\"Exsistance of Exsistences\\", \\"Concealed of the Concealed.", "fields": ["meaning"]}}]	18	1
272	2020-01-13 21:20:14.811903+00	62	nequdah rashunah - נקודה ראשונה : Hebrew	2	[]	18	1
273	2020-01-14 00:08:56.73809+00	63	gofreeth - גפרית : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "gofreeth - \\u05d2\\u05e4\\u05e8\\u05d9\\u05ea : Hebrew - Sulpher"}}]	18	1
274	2020-01-14 00:10:54.428916+00	64	melakh - מלח : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "melakh - \\u05de\\u05dc\\u05d7 : Hebrew - Salt"}}]	18	1
275	2020-01-14 00:13:08.052701+00	65	Enoch - חנך : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Enoch - \\u05d7\\u05e0\\u05da : Hebrew - walked with God"}}, {"added": {"name": "word meaning", "object": "Enoch - \\u05d7\\u05e0\\u05da : Hebrew - Educator"}}]	18	1
276	2020-01-14 00:13:57.517518+00	66	lechem - לחם : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "lechem - \\u05dc\\u05d7\\u05dd : Hebrew - food, bread."}}]	18	1
277	2020-01-14 00:15:50.846286+00	67	Bethlechem - ביתלחם : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Bethlechem - \\u05d1\\u05d9\\u05ea\\u05dc\\u05d7\\u05dd : Hebrew - House of bread"}}]	18	1
278	2020-01-14 00:17:09.911501+00	68	mezla - מזלא : English	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "mezla - \\u05de\\u05d6\\u05dc\\u05d0 : English - to drip, to flow down in drops."}}, {"added": {"name": "word meaning", "object": "mezla - \\u05de\\u05d6\\u05dc\\u05d0 : English - good luck"}}]	18	1
279	2020-01-14 00:17:41.428492+00	68	mezla - מזלא : Hebrew	2	[{"changed": {"fields": ["language"]}}]	18	1
280	2020-01-14 00:18:46.539058+00	69	zeez - זיז : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "zeez - \\u05d6\\u05d9\\u05d6 : Hebrew - abundance"}}, {"added": {"name": "word meaning", "object": "zeez - \\u05d6\\u05d9\\u05d6 : Hebrew - ledge"}}]	18	1
281	2020-01-14 00:19:45.410801+00	70	kad - כד : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "kad - \\u05db\\u05d3 : Hebrew - a pot"}}, {"added": {"name": "word meaning", "object": "kad - \\u05db\\u05d3 : Hebrew - jug"}}, {"added": {"name": "word meaning", "object": "kad - \\u05db\\u05d3 : Hebrew - pitcher"}}]	18	1
282	2020-01-14 00:21:22.292026+00	69	zeez - זיז : Hebrew	2	[{"changed": {"name": "word meaning", "object": "zeez - \\u05d6\\u05d9\\u05d6 : Hebrew - abundance", "fields": ["source"]}}]	18	1
283	2020-01-14 00:22:22.462441+00	71	gevyah - גויה : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "gevyah - \\u05d2\\u05d5\\u05d9\\u05d4 : Hebrew - body or substance"}}, {"added": {"name": "word meaning", "object": "gevyah - \\u05d2\\u05d5\\u05d9\\u05d4 : Hebrew - corpse, stiff, cadaver"}}]	18	1
284	2020-01-14 00:23:39.815581+00	72	gevi - גוי : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "gevi - \\u05d2\\u05d5\\u05d9 : Hebrew - gentile"}}, {"added": {"name": "word meaning", "object": "gevi - \\u05d2\\u05d5\\u05d9 : Hebrew - nation"}}]	18	1
285	2020-01-14 00:24:51.890422+00	73	hadak - הדך : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "hadak - \\u05d4\\u05d3\\u05da : Hebrew - to breakdown, to overturn"}}, {"added": {"name": "word meaning", "object": "hadak - \\u05d4\\u05d3\\u05da : Hebrew - echo"}}]	18	1
286	2020-01-14 00:26:58.898669+00	74	kazab - כזב : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "kazab - \\u05db\\u05d6\\u05d1 : Hebrew - to spin, to bind together, to decieve"}}, {"added": {"name": "word meaning", "object": "kazab - \\u05db\\u05d6\\u05d1 : Hebrew - falsehood"}}]	18	1
287	2020-01-14 00:27:34.598584+00	abcfbf1f-d44a-49eb-aa22-aa1fa032e82d	Latin	1	[{"added": {}}]	16	1
288	2020-01-14 00:28:22.377045+00	3	Latin - Lang: Latin	1	[{"added": {}}]	15	1
289	2020-01-14 00:29:16.514209+00	75	magia - magia : Latin	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "magia - magia : Latin - magic"}}]	18	1
290	2020-01-14 00:32:22.935475+00	76	athanor - אתהנור : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "athanor - \\u05d0\\u05ea\\u05d4\\u05e0\\u05d5\\u05e8 : Hebrew - Essence of Fire"}}]	18	1
291	2020-01-14 00:34:25.659598+00	77	Yekhidah - יחידה : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Yekhidah - \\u05d9\\u05d7\\u05d9\\u05d3\\u05d4 : Hebrew - universal Self seated in Kether"}}, {"added": {"name": "word meaning", "object": "Yekhidah - \\u05d9\\u05d7\\u05d9\\u05d3\\u05d4 : Hebrew - unit"}}]	18	1
292	2020-01-14 00:36:05.494433+00	78	abel - הבל : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "abel - \\u05d4\\u05d1\\u05dc : Hebrew - to breathe, to evaporate"}}, {"added": {"name": "word meaning", "object": "abel - \\u05d4\\u05d1\\u05dc : Hebrew - transitoriness, emptiness, vanity"}}, {"added": {"name": "word meaning", "object": "abel - \\u05d4\\u05d1\\u05dc : Hebrew - steam"}}]	18	1
293	2020-01-14 00:37:43.366356+00	79	ow - או : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "ow - \\u05d0\\u05d5 : Hebrew - desire, will, appetite"}}, {"added": {"name": "word meaning", "object": "ow - \\u05d0\\u05d5 : Hebrew - or"}}, {"added": {"name": "word meaning", "object": "ow - \\u05d0\\u05d5 : Hebrew - either"}}]	18	1
294	2020-01-14 00:39:00.195652+00	80	ka-ehben - כאבן : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "ka-ehben - \\u05db\\u05d0\\u05d1\\u05df : Hebrew - as (or like) a stone"}}]	18	1
295	2020-01-15 18:59:01.969759+00	81	laib - לב : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "laib - \\u05dc\\u05d1 : Hebrew - the heart (in all senses, especially as the seat of knowledge, understanding and thinking ); also, midst, center"}}]	18	1
296	2020-01-15 19:03:44.624752+00	82	lebanah - לבנה : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "lebanah - \\u05dc\\u05d1\\u05e0\\u05d4 : Hebrew - Moon"}}, {"added": {"name": "word meaning", "object": "lebanah - \\u05dc\\u05d1\\u05e0\\u05d4 : Hebrew - The Hebrew word for Moon is LBNH, lebanah. Its first two letters spell laib, \\"heart\\". The second two spell BN, \\"son\\". The last two spell NH, nah, \\"ornament, beautification.\\" The first three letters sp"}}]	18	1
297	2020-01-15 19:04:59.493196+00	83	nah - נה : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "nah - \\u05e0\\u05d4 : Hebrew - ornament, beautification"}}]	18	1
298	2020-01-15 19:05:44.592425+00	84	laban - לבנ : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "laban - \\u05dc\\u05d1\\u05e0 : Hebrew - white"}}]	18	1
299	2020-01-15 19:06:55.035648+00	85	bawnaw - בנה : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "bawnaw - \\u05d1\\u05e0\\u05d4 : Hebrew - to build, to make, to erect."}}]	18	1
300	2020-01-15 19:07:32.865947+00	86	yudyudyud - ייי : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "yudyudyud - \\u05d9\\u05d9\\u05d9 : Hebrew - test"}}]	18	1
301	2020-01-15 19:07:55.379188+00	87	yudyudyud - ייי : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "yudyudyud - \\u05d9\\u05d9\\u05d9 : Hebrew - poop"}}]	18	1
302	2020-01-15 19:09:07.835022+00	87	yudyudyud - ייי : Hebrew	3		18	1
303	2020-01-15 19:09:07.87146+00	86	yudyudyud - ייי : Hebrew	3		18	1
304	2020-01-15 19:09:59.330711+00	88	ben - בנ : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "ben - \\u05d1\\u05e0 : Hebrew - son"}}]	18	1
305	2020-01-17 14:22:11.394199+00	89	Ruach Elohim - רוח אלהים : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Ruach Elohim - \\u05e8\\u05d5\\u05d7 \\u05d0\\u05dc\\u05d4\\u05d9\\u05dd : Hebrew - Life-breath of the Creative Powers"}}, {"added": {"name": "word meaning", "object": "Ruach Elohim - \\u05e8\\u05d5\\u05d7 \\u05d0\\u05dc\\u05d4\\u05d9\\u05dd : Hebrew - The Spirit of God"}}]	18	1
306	2020-01-17 14:24:10.552884+00	90	Shin - שין : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Shin - \\u05e9\\u05d9\\u05df : Hebrew - letter name for Shin. Note the Gematria here is the same as the degrees in a circle"}}]	18	1
307	2020-01-17 14:25:57.597793+00	91	Chaiah - חיה : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Chaiah - \\u05d7\\u05d9\\u05d4 : Hebrew - the life-force; synonomous with prana"}}, {"added": {"name": "word meaning", "object": "Chaiah - \\u05d7\\u05d9\\u05d4 : Hebrew - animal, beast"}}]	18	1
308	2020-01-17 14:30:02.087977+00	92	Ab - אב : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Ab - \\u05d0\\u05d1 : Hebrew - Father. One of the names for Chokmah."}}]	18	1
309	2020-01-17 14:37:54.814502+00	93	taleh - טלה : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "taleh - \\u05d8\\u05dc\\u05d4 : Hebrew - lamb or young ram"}}]	18	1
310	2020-01-17 14:39:43.31436+00	94	lahat - להט : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "lahat - \\u05dc\\u05d4\\u05d8 : Hebrew - flame, magic"}}, {"added": {"name": "word meaning", "object": "lahat - \\u05dc\\u05d4\\u05d8 : Hebrew - glow"}}]	18	1
311	2020-01-17 14:41:04.790529+00	27	Khool - חול : Hebrew	2	[{"changed": {"name": "word meaning", "object": "Khool - \\u05d7\\u05d5\\u05dc : Hebrew - Sand", "fields": ["source"]}}, {"changed": {"name": "word meaning", "object": "Khool - \\u05d7\\u05d5\\u05dc : Hebrew - As a verb - to turn round, to twist, to whirl", "fields": ["source"]}}]	18	1
312	2020-01-17 14:41:52.188732+00	94	lahat - להט : Hebrew	2	[{"added": {"name": "word meaning", "object": "lahat - \\u05dc\\u05d4\\u05d8 : Hebrew - magical fire"}}]	18	1
313	2020-01-17 14:44:20.126242+00	95	Hiram Abiff - חורם אביו : English	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Hiram Abiff - \\u05d7\\u05d5\\u05e8\\u05dd \\u05d0\\u05d1\\u05d9\\u05d5 : English - Hiram Abiff"}}]	18	1
314	2020-01-17 14:47:43.909975+00	96	ebhen masu ha-bonim - אבן מאסו הבונים : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "ebhen masu ha-bonim - \\u05d0\\u05d1\\u05df \\u05de\\u05d0\\u05e1\\u05d5 \\u05d4\\u05d1\\u05d5\\u05e0\\u05d9\\u05dd : Hebrew - the stone which the builders refused (Psalm 118:22)"}}, {"added": {"name": "word meaning", "object": "ebhen masu ha-bonim - \\u05d0\\u05d1\\u05df \\u05de\\u05d0\\u05e1\\u05d5 \\u05d4\\u05d1\\u05d5\\u05e0\\u05d9\\u05dd : Hebrew - Hiram the \\"rejected stone\\", was the son of a widow fo the Tribe Naphtali"}}]	18	1
315	2020-01-17 14:50:45.035546+00	96	ebhen masu ha-bonim - אבן מאסו הבונים : Hebrew	2	[{"changed": {"name": "word meaning", "object": "ebhen masu ha-bonim - \\u05d0\\u05d1\\u05df \\u05de\\u05d0\\u05e1\\u05d5 \\u05d4\\u05d1\\u05d5\\u05e0\\u05d9\\u05dd : Hebrew - Hiram the \\"rejected stone\\", was the son of a widow fo the Tribe Naphtali (Naphtali is Virgo)", "fields": ["meaning"]}}]	18	1
316	2020-01-17 14:55:16.632257+00	97	Esh - אש : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Esh - \\u05d0\\u05e9 : Hebrew - fire"}}]	18	1
317	2020-01-17 14:56:38.713887+00	3	Jah - יה : Hebrew	2	[{"added": {"name": "word meaning", "object": "Jah - \\u05d9\\u05d4 : Hebrew - special name given to Chokmah, which is also the \\"Root of Fire\\""}}]	18	1
318	2020-01-17 14:58:08.914146+00	98	ha-Moriah har - המוריה הר : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "ha-Moriah har - \\u05d4\\u05de\\u05d5\\u05e8\\u05d9\\u05d4 \\u05d4\\u05e8 : Hebrew - Mount Moriah"}}, {"added": {"name": "word meaning", "object": "ha-Moriah har - \\u05d4\\u05de\\u05d5\\u05e8\\u05d9\\u05d4 \\u05d4\\u05e8 : Hebrew - the hill of the Divine Vision"}}]	18	1
319	2020-01-17 14:58:48.458765+00	99	Moriah - מוריה : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Moriah - \\u05de\\u05d5\\u05e8\\u05d9\\u05d4 : Hebrew - seen of Jah"}}]	18	1
320	2020-01-17 15:00:45.245183+00	100	Aleph-Shin - אלף שין : Hebrew	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "Aleph-Shin - \\u05d0\\u05dc\\u05e3 \\u05e9\\u05d9\\u05df : Hebrew - Esh Fire in plentitude"}}]	18	1
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	auth	permission
2	auth	group
3	contenttypes	contenttype
4	sessions	session
5	sites	site
6	admin	logentry
7	account	emailaddress
8	account	emailconfirmation
9	socialaccount	socialaccount
10	socialaccount	socialapp
11	socialaccount	socialtoken
12	users	user
13	gematriacore	letterpower
14	gematriacore	letter
15	gematriacore	alphabet
16	gematriacore	language
17	gematriacore	dictionary
18	gematriacore	word
19	gematriacore	gematriamethodletterrule
20	gematriacore	wordmeaning
21	gematriacore	gematriamethod
22	gematriacore	lettermeaning
23	gematriacore	wordspelling
24	gematriacore	wordvalue
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2019-03-20 23:39:18.651439+00
2	contenttypes	0002_remove_content_type_name	2019-03-20 23:39:18.667756+00
3	auth	0001_initial	2019-03-20 23:39:18.719332+00
4	auth	0002_alter_permission_name_max_length	2019-03-20 23:39:18.729309+00
5	auth	0003_alter_user_email_max_length	2019-03-20 23:39:18.739378+00
6	auth	0004_alter_user_username_opts	2019-03-20 23:39:18.748962+00
7	auth	0005_alter_user_last_login_null	2019-03-20 23:39:18.761525+00
8	auth	0006_require_contenttypes_0002	2019-03-20 23:39:18.764844+00
9	auth	0007_alter_validators_add_error_messages	2019-03-20 23:39:18.773677+00
10	auth	0008_alter_user_username_max_length	2019-03-20 23:39:18.782597+00
11	users	0001_initial	2019-03-20 23:39:18.831614+00
12	account	0001_initial	2019-03-20 23:39:18.889948+00
13	account	0002_email_max_length	2019-03-20 23:39:18.904848+00
14	admin	0001_initial	2019-03-20 23:39:18.936453+00
15	admin	0002_logentry_remove_auto_add	2019-03-20 23:39:18.950298+00
16	auth	0009_alter_user_last_name_max_length	2019-03-20 23:39:18.966287+00
17	sessions	0001_initial	2019-03-20 23:39:18.986449+00
18	sites	0001_initial	2019-03-20 23:39:18.998625+00
19	sites	0002_alter_domain_unique	2019-03-20 23:39:19.019818+00
20	sites	0003_set_site_domain_and_name	2019-03-20 23:39:19.046829+00
21	socialaccount	0001_initial	2019-03-20 23:39:19.179389+00
22	socialaccount	0002_token_max_lengths	2019-03-20 23:39:19.218682+00
23	socialaccount	0003_extra_data_default_dict	2019-03-20 23:39:19.232314+00
34	gematriacore	0011_auto_20190330_1645	2019-03-30 16:45:29.072854+00
39	gematriacore	0001_initial	2019-12-02 16:47:42.495949+00
40	gematriacore	0002_alphabet_characters	2019-12-02 16:51:00.845499+00
41	gematriacore	0003_remove_alphabet_characters	2019-12-02 16:57:42.474222+00
42	gematriacore	0004_auto_20191202_1727	2019-12-02 17:29:44.00069+00
43	gematriacore	0005_auto_20191202_1802	2019-12-02 18:02:34.177359+00
44	gematriacore	0006_language_uuid	2019-12-05 21:38:58.228196+00
45	gematriacore	0006_auto_20191205_2159	2019-12-05 22:14:28.139038+00
46	gematriacore	0007_auto_20191205_2212	2019-12-05 22:14:28.357247+00
47	gematriacore	0002_auto_20191206_2308	2019-12-06 23:08:19.079889+00
48	gematriacore	0003_auto_20191211_1536	2019-12-11 15:36:25.328058+00
49	gematriacore	0004_auto_20191214_1738	2019-12-14 17:39:17.663056+00
50	gematriacore	0005_auto_20191214_1749	2019-12-14 17:49:39.776597+00
51	gematriacore	0006_auto_20191214_1757	2019-12-14 17:57:26.157686+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
gdpl8lan3803vwnd8l2e5alhv9gjyr3b	NjlkNGFhYzc4NjU3ODIxNzcwYmUxZjFmN2I0MjBlOTc2NGJkY2U4Njp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkNmNkOTcxZmY2MjhmMzg0ZDQwM2Q0ODU0ZGFkMWIwNWNkZWMxODk4In0=	2019-04-04 16:06:06.489595+00
dzqbh0levr02el1t6t3pxeh1tw7clfam	NjlkNGFhYzc4NjU3ODIxNzcwYmUxZjFmN2I0MjBlOTc2NGJkY2U4Njp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkNmNkOTcxZmY2MjhmMzg0ZDQwM2Q0ODU0ZGFkMWIwNWNkZWMxODk4In0=	2019-07-17 15:07:10.656567+00
dks6b2b54in13a4bm4m77zyyp5arb7z8	NjlkNGFhYzc4NjU3ODIxNzcwYmUxZjFmN2I0MjBlOTc2NGJkY2U4Njp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkNmNkOTcxZmY2MjhmMzg0ZDQwM2Q0ODU0ZGFkMWIwNWNkZWMxODk4In0=	2019-12-16 15:59:01.938623+00
dlp5me5r4m97je537l044vrgr1i6uh2p	NjlkNGFhYzc4NjU3ODIxNzcwYmUxZjFmN2I0MjBlOTc2NGJkY2U4Njp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkNmNkOTcxZmY2MjhmMzg0ZDQwM2Q0ODU0ZGFkMWIwNWNkZWMxODk4In0=	2019-12-25 15:32:11.387839+00
w6ceola01f11nsalyjf2uiqcd3tltwhg	NjlkNGFhYzc4NjU3ODIxNzcwYmUxZjFmN2I0MjBlOTc2NGJkY2U4Njp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkNmNkOTcxZmY2MjhmMzg0ZDQwM2Q0ODU0ZGFkMWIwNWNkZWMxODk4In0=	2019-12-31 00:03:26.157821+00
08pkuqfjfpc019hmebjx4k8p5xdflyqb	NjlkNGFhYzc4NjU3ODIxNzcwYmUxZjFmN2I0MjBlOTc2NGJkY2U4Njp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkNmNkOTcxZmY2MjhmMzg0ZDQwM2Q0ODU0ZGFkMWIwNWNkZWMxODk4In0=	2020-01-27 21:05:19.629791+00
c04je5bymifgc49wwa5ophpsjuml9a5y	NjlkNGFhYzc4NjU3ODIxNzcwYmUxZjFmN2I0MjBlOTc2NGJkY2U4Njp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkNmNkOTcxZmY2MjhmMzg0ZDQwM2Q0ODU0ZGFkMWIwNWNkZWMxODk4In0=	2020-01-31 14:18:17.081893+00
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_site (id, domain, name) FROM stdin;
1	hsgd.gematria.com	gematria
\.


--
-- Data for Name: gematriacore_alphabet; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.gematriacore_alphabet (id, created, modified, title, language_id) FROM stdin;
2	2019-12-02 16:02:34.172075+00	2019-12-05 22:09:28.299793+00	English	5b92dc65-9487-4487-94a5-7ae21ace7aab
1	2019-03-21 17:52:11.262087+00	2019-12-05 22:09:20.25169+00	Hebrew	5b92dc65-9487-4487-94a5-7ae21ace7aab
3	2020-01-14 00:28:22.344075+00	2020-01-14 00:28:22.344235+00	Latin	abcfbf1f-d44a-49eb-aa22-aa1fa032e82d
\.


--
-- Data for Name: gematriacore_gematriamethod; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.gematriacore_gematriamethod (id, created, modified, title, alphabet_id, language_id) FROM stdin;
1	2019-03-21 18:40:33.125467+00	2019-03-23 16:37:30.565212+00	Simple	1	5b92dc65-9487-4487-94a5-7ae21ace7aab
2	2019-03-23 16:42:56.722941+00	2019-03-23 16:49:52.205366+00	Regular	1	5b92dc65-9487-4487-94a5-7ae21ace7aab
3	2019-12-18 16:29:01.374226+00	2019-12-18 16:29:01.374477+00	Miliui, Letters Spelled in Full	1	5b92dc65-9487-4487-94a5-7ae21ace7aab
4	2019-12-18 16:36:57.464486+00	2019-12-18 16:36:57.464577+00	Regular Polygons Inscribed in a Circle, Number of Edges	1	5b92dc65-9487-4487-94a5-7ae21ace7aab
\.


--
-- Data for Name: gematriacore_gematriamethodletterrule; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.gematriacore_gematriamethodletterrule (id, created, modified, numerical_value, letter_id, gematria_method_id) FROM stdin;
1	2019-03-23 16:26:43.400589+00	2019-03-23 16:26:43.400625+00	1	5	\N
2	2019-03-23 16:31:36.481342+00	2019-03-23 16:31:36.481383+00	1	5	1
3	2019-03-23 16:31:36.49519+00	2019-03-23 16:31:36.495229+00	2	6	1
4	2019-03-23 16:31:36.506757+00	2019-03-23 16:31:36.506803+00	3	7	1
5	2019-03-23 16:37:30.581413+00	2019-03-23 16:37:30.581457+00	4	8	1
6	2019-03-23 16:37:30.593666+00	2019-03-23 16:37:30.593707+00	5	9	1
7	2019-03-23 16:37:30.607657+00	2019-03-23 16:37:30.607708+00	6	10	1
8	2019-03-23 16:37:30.623468+00	2019-03-23 16:37:30.623507+00	7	11	1
9	2019-03-23 16:37:30.637911+00	2019-03-23 16:37:30.637942+00	8	12	1
10	2019-03-23 16:37:30.653757+00	2019-03-23 16:37:30.653798+00	9	13	1
11	2019-03-23 16:37:30.67321+00	2019-03-23 16:37:30.67327+00	10	14	1
12	2019-03-23 16:37:30.692467+00	2019-03-23 16:37:30.69252+00	20	15	1
13	2019-03-23 16:37:30.71162+00	2019-03-23 16:37:30.7117+00	20	16	1
14	2019-03-23 16:37:30.730984+00	2019-03-23 16:37:30.731035+00	30	17	1
15	2019-03-23 16:37:30.742683+00	2019-03-23 16:37:30.74273+00	40	18	1
16	2019-03-23 16:37:30.757868+00	2019-03-23 16:37:30.757912+00	40	19	1
17	2019-03-23 16:37:30.77159+00	2019-03-23 16:37:30.771622+00	50	20	1
18	2019-03-23 16:37:30.786342+00	2019-03-23 16:37:30.786374+00	50	21	1
19	2019-03-23 16:37:30.798552+00	2019-03-23 16:37:30.798587+00	60	22	1
20	2019-03-23 16:37:30.81059+00	2019-03-23 16:37:30.810619+00	70	23	1
21	2019-03-23 16:37:30.825665+00	2019-03-23 16:37:30.825696+00	80	24	1
22	2019-03-23 16:37:30.839194+00	2019-03-23 16:37:30.839227+00	80	25	1
23	2019-03-23 16:37:30.853925+00	2019-03-23 16:37:30.853955+00	90	26	1
24	2019-03-23 16:37:30.867734+00	2019-03-23 16:37:30.867765+00	90	27	1
25	2019-03-23 16:37:30.880228+00	2019-03-23 16:37:30.880268+00	100	28	1
26	2019-03-23 16:37:30.902154+00	2019-03-23 16:37:30.902182+00	200	29	1
27	2019-03-23 16:37:30.915107+00	2019-03-23 16:37:30.915149+00	300	30	1
28	2019-03-23 16:37:30.927867+00	2019-03-23 16:37:30.927913+00	400	31	1
29	2019-03-23 16:49:52.223643+00	2019-03-23 16:49:52.223694+00	1	5	2
30	2019-03-23 16:49:52.243236+00	2019-03-23 16:49:52.243289+00	2	6	2
31	2019-03-23 16:49:52.260887+00	2019-03-23 16:49:52.260983+00	3	7	2
32	2019-03-23 16:49:52.273517+00	2019-03-23 16:49:52.273552+00	4	8	2
33	2019-03-23 16:49:52.289091+00	2019-03-23 16:49:52.289125+00	5	9	2
34	2019-03-23 16:49:52.306921+00	2019-03-23 16:49:52.307068+00	6	10	2
35	2019-03-23 16:49:52.327674+00	2019-03-23 16:49:52.327718+00	7	11	2
36	2019-03-23 16:49:52.34058+00	2019-03-23 16:49:52.340633+00	8	12	2
37	2019-03-23 16:49:52.364351+00	2019-03-23 16:49:52.364403+00	9	13	2
38	2019-03-23 16:49:52.393475+00	2019-03-23 16:49:52.393532+00	10	14	2
39	2019-03-23 16:49:52.424639+00	2019-03-23 16:49:52.424761+00	20	15	2
40	2019-03-23 16:49:52.467322+00	2019-03-23 16:49:52.467363+00	500	16	2
41	2019-03-23 16:49:52.510248+00	2019-03-23 16:49:52.510281+00	30	17	2
42	2019-03-23 16:49:52.545915+00	2019-03-23 16:49:52.545969+00	40	18	2
43	2019-03-23 16:49:52.587331+00	2019-03-23 16:49:52.587364+00	600	19	2
44	2019-03-23 16:49:52.611588+00	2019-03-23 16:49:52.611643+00	50	20	2
45	2019-03-23 16:49:52.637376+00	2019-03-23 16:49:52.63741+00	700	21	2
46	2019-03-23 16:49:52.649996+00	2019-03-23 16:49:52.650032+00	60	22	2
47	2019-03-23 16:49:52.6711+00	2019-03-23 16:49:52.671252+00	70	23	2
48	2019-03-23 16:49:52.689129+00	2019-03-23 16:49:52.689166+00	80	24	2
49	2019-03-23 16:49:52.706232+00	2019-03-23 16:49:52.706272+00	800	25	2
50	2019-03-23 16:49:52.726125+00	2019-03-23 16:49:52.726216+00	90	26	2
51	2019-03-23 16:49:52.749468+00	2019-03-23 16:49:52.74969+00	900	27	2
52	2019-03-23 16:49:52.779298+00	2019-03-23 16:49:52.779351+00	100	28	2
53	2019-03-23 16:49:52.808599+00	2019-03-23 16:49:52.808645+00	200	29	2
54	2019-03-23 16:49:52.831211+00	2019-03-23 16:49:52.831373+00	300	30	2
55	2019-03-23 16:49:52.860305+00	2019-03-23 16:49:52.860439+00	400	31	2
56	2019-12-18 16:29:01.453698+00	2019-12-18 16:29:01.453875+00	111	5	3
57	2019-12-18 16:29:01.525436+00	2019-12-18 16:29:01.525584+00	412	6	3
58	2019-12-18 16:29:01.578691+00	2019-12-18 16:29:01.578784+00	73	7	3
59	2019-12-18 16:29:01.626897+00	2019-12-18 16:29:01.626978+00	474	8	3
60	2019-12-18 16:29:01.667793+00	2019-12-18 16:29:01.667872+00	6	9	3
61	2019-12-18 16:29:01.69324+00	2019-12-18 16:29:01.693327+00	12	10	3
62	2019-12-18 16:29:01.716844+00	2019-12-18 16:29:01.716926+00	67	11	3
63	2019-12-18 16:29:01.739644+00	2019-12-18 16:29:01.739726+00	418	12	3
64	2019-12-18 16:29:01.763361+00	2019-12-18 16:29:01.763441+00	419	13	3
65	2019-12-18 16:29:01.787343+00	2019-12-18 16:29:01.787425+00	20	14	3
66	2019-12-18 16:29:01.810709+00	2019-12-18 16:29:01.810793+00	100	16	3
67	2019-12-18 16:29:01.834795+00	2019-12-18 16:29:01.834877+00	100	15	3
68	2019-12-18 16:29:01.86034+00	2019-12-18 16:29:01.860429+00	74	17	3
69	2019-12-18 16:29:01.884596+00	2019-12-18 16:29:01.884676+00	90	19	3
70	2019-12-18 16:29:01.908177+00	2019-12-18 16:29:01.90826+00	90	18	3
71	2019-12-18 16:29:01.931953+00	2019-12-18 16:29:01.932034+00	106	21	3
72	2019-12-18 16:29:01.955562+00	2019-12-18 16:29:01.955643+00	106	20	3
73	2019-12-18 16:29:01.9804+00	2019-12-18 16:29:01.980497+00	91	25	3
74	2019-12-18 16:29:02.004071+00	2019-12-18 16:29:02.004162+00	91	24	3
75	2019-12-18 16:29:02.028269+00	2019-12-18 16:29:02.028352+00	104	27	3
76	2019-12-18 16:29:02.051483+00	2019-12-18 16:29:02.051564+00	104	26	3
77	2019-12-18 16:29:02.078334+00	2019-12-18 16:29:02.078419+00	186	28	3
78	2019-12-18 16:29:02.101472+00	2019-12-18 16:29:02.101552+00	120	22	3
79	2019-12-18 16:29:02.127006+00	2019-12-18 16:29:02.127093+00	130	23	3
80	2019-12-18 16:29:02.151681+00	2019-12-18 16:29:02.151762+00	510	29	3
81	2019-12-18 16:29:02.176141+00	2019-12-18 16:29:02.176225+00	360	30	3
82	2019-12-18 16:29:02.200508+00	2019-12-18 16:29:02.20059+00	406	31	3
83	2019-12-18 16:36:57.504586+00	2019-12-18 16:36:57.504676+00	3	5	4
84	2019-12-18 16:36:57.544508+00	2019-12-18 16:36:57.544591+00	4	6	4
85	2019-12-18 16:36:57.571454+00	2019-12-18 16:36:57.571534+00	5	7	4
86	2019-12-18 16:36:57.653885+00	2019-12-18 16:36:57.653966+00	6	8	4
87	2019-12-18 16:36:57.715615+00	2019-12-18 16:36:57.715754+00	8	9	4
88	2019-12-18 16:36:57.762287+00	2019-12-18 16:36:57.762368+00	9	10	4
89	2019-12-18 16:36:57.795997+00	2019-12-18 16:36:57.796092+00	10	11	4
90	2019-12-18 16:36:57.82664+00	2019-12-18 16:36:57.82672+00	12	12	4
91	2019-12-18 16:36:57.856557+00	2019-12-18 16:36:57.856639+00	15	13	4
92	2019-12-18 16:36:57.887779+00	2019-12-18 16:36:57.887858+00	18	14	4
93	2019-12-18 16:36:57.919253+00	2019-12-18 16:36:57.919335+00	20	16	4
94	2019-12-18 16:36:57.943135+00	2019-12-18 16:36:57.943226+00	20	15	4
95	2019-12-18 16:36:57.968195+00	2019-12-18 16:36:57.968274+00	24	17	4
96	2019-12-18 16:36:57.995652+00	2019-12-18 16:36:57.995806+00	30	19	4
97	2019-12-18 16:36:58.020197+00	2019-12-18 16:36:58.020286+00	30	18	4
98	2019-12-18 16:36:58.045614+00	2019-12-18 16:36:58.045698+00	36	21	4
99	2019-12-18 16:36:58.068868+00	2019-12-18 16:36:58.068947+00	36	20	4
100	2019-12-18 16:36:58.101931+00	2019-12-18 16:36:58.102058+00	40	22	4
101	2019-12-18 16:36:58.13844+00	2019-12-18 16:36:58.138524+00	45	23	4
102	2019-12-18 16:36:58.168264+00	2019-12-18 16:36:58.168345+00	60	25	4
103	2019-12-18 16:36:58.202346+00	2019-12-18 16:36:58.202429+00	60	24	4
104	2019-12-18 16:36:58.22601+00	2019-12-18 16:36:58.226091+00	72	27	4
105	2019-12-18 16:36:58.249874+00	2019-12-18 16:36:58.249956+00	72	26	4
106	2019-12-18 16:36:58.273276+00	2019-12-18 16:36:58.273355+00	90	28	4
107	2019-12-18 16:36:58.296736+00	2019-12-18 16:36:58.29686+00	120	29	4
108	2019-12-18 16:36:58.324412+00	2019-12-18 16:36:58.324494+00	180	30	4
109	2019-12-18 16:36:58.352886+00	2019-12-18 16:36:58.352992+00	360	31	4
\.


--
-- Data for Name: gematriacore_language; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.gematriacore_language (created, modified, title, uuid) FROM stdin;
2019-03-21 17:51:50.821524+00	2019-03-21 17:51:50.821553+00	Hebrew	5b92dc65-9487-4487-94a5-7ae21ace7aab
2019-12-05 22:59:45.320638+00	2019-12-05 22:59:45.320724+00	English	a45331a5-3beb-4562-8234-4f25199a4b76
2019-12-05 22:59:51.204154+00	2019-12-05 22:59:51.204232+00	Greek	23e380bf-5382-4d95-8376-face75b0579b
2020-01-14 00:27:34.544202+00	2020-01-14 00:27:34.544322+00	Latin	abcfbf1f-d44a-49eb-aa22-aa1fa032e82d
\.


--
-- Data for Name: gematriacore_letter; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.gematriacore_letter (id, created, modified, title, "character", alphabet_id, letter_order) FROM stdin;
7	2019-03-21 18:31:31.79398+00	2019-03-21 18:31:31.794014+00	Gimel	ג	1	\N
8	2019-03-21 18:34:47.689882+00	2019-03-21 18:34:47.689929+00	Daleth	ד	1	\N
9	2019-03-21 18:35:34.414594+00	2019-03-21 18:35:34.414628+00	He	ה	1	\N
10	2019-03-21 18:55:22.510014+00	2019-03-21 18:55:22.510047+00	Vau	ו	1	\N
11	2019-03-21 18:56:59.648074+00	2019-03-21 18:56:59.648111+00	Zayin	ז	1	\N
12	2019-03-21 19:00:30.029979+00	2019-03-21 19:00:30.030011+00	Chet	ח	1	\N
13	2019-03-21 19:01:13.943862+00	2019-03-21 19:01:13.943899+00	Teth	ט	1	\N
14	2019-03-21 19:02:31.269593+00	2019-03-21 19:02:31.269636+00	Yod	י	1	\N
15	2019-03-21 19:03:40.16291+00	2019-03-21 19:03:40.162942+00	Kaph	כ	1	\N
16	2019-03-21 19:04:12.3309+00	2019-03-21 19:04:12.330935+00	Kaph - Final	ך	1	\N
17	2019-03-21 19:05:03.451001+00	2019-03-21 19:05:03.451065+00	Lamed	ל	1	\N
18	2019-03-21 19:05:46.274578+00	2019-03-21 19:05:46.274615+00	Mem	מ	1	\N
19	2019-03-21 19:06:19.667242+00	2019-03-21 19:06:19.667285+00	Mem - Final	ם	1	\N
31	2019-03-21 19:15:07.085408+00	2019-03-23 16:17:46.535555+00	Tau	ת	1	\N
30	2019-03-21 19:14:27.207543+00	2019-03-23 16:19:56.398384+00	Shin	ש	1	\N
29	2019-03-21 19:13:46.682933+00	2019-03-23 16:20:30.80447+00	Resh	ר	1	\N
28	2019-03-21 19:12:53.045885+00	2019-03-23 16:22:28.350586+00	Qoph	ק	1	\N
27	2019-03-21 19:12:09.482912+00	2019-03-23 16:23:07.378958+00	Tzaddi - Final	ץ	1	\N
26	2019-03-21 19:11:33.64249+00	2019-03-23 16:23:28.964154+00	Tzaddi	צ	1	\N
25	2019-03-21 19:10:45.48104+00	2019-03-23 16:24:07.712068+00	Peh - Final	ף	1	\N
24	2019-03-21 19:10:13.564421+00	2019-03-23 16:24:29.304137+00	Peh	פ	1	\N
23	2019-03-21 19:09:16.533989+00	2019-03-23 16:24:48.703295+00	Ayin	ע	1	\N
22	2019-03-21 19:08:35.136482+00	2019-03-23 16:25:10.814067+00	Samekh	ס	1	\N
21	2019-03-21 19:07:40.564035+00	2019-03-23 16:25:29.622521+00	Nun - Final	ן	1	\N
20	2019-03-21 19:07:09.805844+00	2019-03-23 16:25:45.316878+00	Nun	נ	1	\N
6	2019-03-21 18:30:06.475055+00	2019-03-23 16:40:44.924043+00	Beth	ב	1	2
5	2019-03-21 18:12:13.012575+00	2019-12-02 17:08:52.544901+00	Aleph	א	1	1
\.


--
-- Data for Name: gematriacore_letter_meanings; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.gematriacore_letter_meanings (id, letter_id, lettermeaning_id) FROM stdin;
1	31	28
2	30	27
3	29	25
4	29	26
5	28	24
6	28	23
7	27	22
8	26	22
9	25	21
10	24	21
11	23	20
12	22	19
13	21	18
14	20	18
15	6	3
16	5	1
\.


--
-- Data for Name: gematriacore_lettermeaning; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.gematriacore_lettermeaning (id, created, modified, meaning, is_active) FROM stdin;
1	2019-03-21 18:06:12.086995+00	2019-03-21 18:06:12.087027+00	Ox	t
2	2019-03-21 18:31:10.342935+00	2019-03-21 18:31:10.342979+00	Camel	t
3	2019-03-21 18:31:56.50444+00	2019-03-21 18:31:56.504472+00	House	t
4	2019-03-21 18:34:39.61591+00	2019-03-21 18:34:39.615941+00	Door	t
5	2019-03-21 18:35:26.933877+00	2019-03-21 18:35:26.933904+00	Window	t
6	2019-03-21 18:54:50.541947+00	2019-03-21 18:54:50.541977+00	Pin	t
7	2019-03-21 18:55:14.403969+00	2019-03-21 18:55:14.404001+00	Nail	f
8	2019-03-21 18:56:43.749951+00	2019-03-21 18:56:43.749981+00	Sword	t
9	2019-03-21 18:56:53.036277+00	2019-03-21 18:56:53.036311+00	Armour	f
10	2019-03-21 19:00:14.95828+00	2019-03-21 19:00:14.958313+00	Fence	t
11	2019-03-21 19:00:25.396247+00	2019-03-21 19:00:25.396275+00	Enclosure	f
12	2019-03-21 19:01:10.019384+00	2019-03-21 19:01:10.019413+00	Snake	t
13	2019-03-21 19:02:02.614405+00	2019-03-21 19:02:02.614437+00	Hand	t
14	2019-03-21 19:02:10.645723+00	2019-03-21 19:02:10.645754+00	Palm	t
15	2019-03-21 19:03:28.717966+00	2019-03-21 19:03:28.717994+00	Fist	t
16	2019-03-21 19:04:59.648484+00	2019-03-21 19:04:59.648514+00	Ox Goad	t
17	2019-03-21 19:05:42.126366+00	2019-03-21 19:05:42.126395+00	Water	t
18	2019-03-21 19:07:06.602701+00	2019-03-21 19:07:06.602732+00	Fish	f
19	2019-03-21 19:08:24.368863+00	2019-03-21 19:08:24.368891+00	Prop	t
20	2019-03-21 19:09:13.410634+00	2019-03-21 19:09:13.410665+00	Eye	t
21	2019-03-21 19:10:08.65225+00	2019-03-21 19:10:08.652278+00	Mouth	t
22	2019-03-21 19:11:26.105819+00	2019-03-21 19:11:26.10585+00	Fishhook	t
23	2019-03-21 19:12:41.834096+00	2019-03-21 19:12:41.83413+00	Ear	t
24	2019-03-21 19:12:49.103168+00	2019-03-21 19:12:49.1032+00	Back of Head	f
25	2019-03-21 19:13:16.00132+00	2019-03-21 19:13:16.001368+00	Head	t
26	2019-03-21 19:13:22.5638+00	2019-03-21 19:13:22.563829+00	Face	t
28	2019-03-21 19:15:02.564213+00	2019-03-23 15:52:17.334875+00	Cross	t
27	2019-03-21 19:14:21.685431+00	2019-03-23 15:53:07.137907+00	Tooth	t
\.


--
-- Data for Name: gematriacore_letterpower; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.gematriacore_letterpower (id, created, modified, power, is_active, letter_id) FROM stdin;
32	2019-03-23 16:17:46.608561+00	2019-03-23 16:17:46.608597+00	T	t	31
33	2019-03-23 16:17:46.623027+00	2019-03-23 16:17:46.623066+00	Th	f	31
34	2019-03-23 16:19:56.479833+00	2019-03-23 16:19:56.479876+00	S	t	30
35	2019-03-23 16:19:56.500293+00	2019-03-23 16:19:56.500411+00	Sh	f	30
36	2019-03-23 16:20:30.867815+00	2019-03-23 16:20:30.86785+00	R	t	29
37	2019-03-23 16:22:28.457098+00	2019-03-23 16:22:28.457201+00	Q	t	28
38	2019-03-23 16:23:07.456422+00	2019-03-23 16:23:07.456475+00	Tz	t	27
39	2019-03-23 16:23:29.030979+00	2019-03-23 16:23:29.031012+00	Tz	t	26
40	2019-03-23 16:24:07.764335+00	2019-03-23 16:24:07.764366+00	P	t	25
41	2019-03-23 16:24:07.77724+00	2019-03-23 16:24:07.77727+00	Ph	f	25
42	2019-03-23 16:24:29.361743+00	2019-03-23 16:24:29.361775+00	P	t	24
43	2019-03-23 16:24:29.378936+00	2019-03-23 16:24:29.379002+00	Ph	f	24
44	2019-03-23 16:24:48.76937+00	2019-03-23 16:24:48.769402+00	Aa	t	23
45	2019-03-23 16:24:48.784677+00	2019-03-23 16:24:48.784707+00	O	f	23
46	2019-03-23 16:25:10.866887+00	2019-03-23 16:25:10.86692+00	S	t	22
47	2019-03-23 16:25:29.713316+00	2019-03-23 16:25:29.713356+00	N	t	21
48	2019-03-23 16:25:45.371682+00	2019-03-23 16:25:45.371731+00	N	t	20
49	2019-03-23 16:40:45.016416+00	2019-03-23 16:40:45.016461+00	B	t	6
50	2019-03-23 16:40:45.036218+00	2019-03-23 16:40:45.036271+00	V	f	6
\.


--
-- Data for Name: gematriacore_word; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.gematriacore_word (id, created, modified, name_english, name_original_language, language_id, characters_alpha) FROM stdin;
60	2020-01-13 21:10:02.920698+00	2020-01-13 21:10:02.921062+00	aur peshut	אור פשוט	5b92dc65-9487-4487-94a5-7ae21ace7aab	אווטפרש
61	2020-01-13 21:12:41.731751+00	2020-01-13 21:12:41.731845+00	aur pemini	אור פנימי	5b92dc65-9487-4487-94a5-7ae21ace7aab	אויימנפר
2	2019-03-30 19:43:31.971015+00	2019-12-06 23:42:00.080135+00	Jehovah	יהוה	5b92dc65-9487-4487-94a5-7ae21ace7aab	ההוי
1	2019-03-23 16:55:45.775185+00	2019-12-06 23:42:36.839632+00	Kether	כתר	5b92dc65-9487-4487-94a5-7ae21ace7aab	כרת
6	2019-12-06 23:20:44.87052+00	2019-12-06 23:49:45.574916+00	Mayim	מיים	5b92dc65-9487-4487-94a5-7ae21ace7aab	ייםמ
8	2019-12-06 23:39:25.267394+00	2019-12-06 23:51:37.065281+00	Chokmah	חכמה	5b92dc65-9487-4487-94a5-7ae21ace7aab	החכמ
7	2019-12-06 23:22:21.638412+00	2019-12-06 23:51:49.725974+00	Ruach	רוח	5b92dc65-9487-4487-94a5-7ae21ace7aab	וחר
9	2019-12-06 23:40:36.393198+00	2019-12-06 23:51:57.21777+00	Kachmah	כחמה	5b92dc65-9487-4487-94a5-7ae21ace7aab	החכמ
10	2019-12-07 01:36:21.925794+00	2019-12-07 01:36:21.925896+00	galah	גלה	5b92dc65-9487-4487-94a5-7ae21ace7aab	גהל
12	2019-12-07 01:42:27.275421+00	2019-12-07 01:42:27.275519+00	galah sodo	גלה סודו	5b92dc65-9487-4487-94a5-7ae21ace7aab	גדהוולס
13	2019-12-11 19:55:03.900428+00	2019-12-11 19:55:03.900523+00	Hod	הוד	5b92dc65-9487-4487-94a5-7ae21ace7aab	דהו
14	2019-12-11 23:05:10.615099+00	2019-12-11 23:05:10.615209+00	mitsrayim	מצרים	5b92dc65-9487-4487-94a5-7ae21ace7aab	יםמצר
15	2019-12-14 16:38:07.218008+00	2019-12-14 16:38:07.218095+00	MTzPVN ZHB IAThH	מצפון זהב יאתה	5b92dc65-9487-4487-94a5-7ae21ace7aab	אבההוזימןפצת
16	2019-12-14 16:40:16.404308+00	2019-12-14 16:40:16.404463+00	Esh hashamaim	אש השמים	5b92dc65-9487-4487-94a5-7ae21ace7aab	אהיםמשש
17	2019-12-15 23:43:02.061532+00	2019-12-15 23:44:35.808541+00	Zibeth	צבת	5b92dc65-9487-4487-94a5-7ae21ace7aab	בצת
18	2019-12-15 23:50:35.926648+00	2019-12-15 23:50:35.926847+00	tsore olahmim	צור עולמים	5b92dc65-9487-4487-94a5-7ae21ace7aab	ווילםמעצר
19	2019-12-17 00:04:19.580233+00	2019-12-17 00:04:19.580327+00	Achad	אחד	5b92dc65-9487-4487-94a5-7ae21ace7aab	אדח
20	2019-12-17 00:06:07.404117+00	2019-12-17 00:06:07.404206+00	Ach	אח	5b92dc65-9487-4487-94a5-7ae21ace7aab	אח
21	2019-12-17 00:07:52.546991+00	2019-12-17 00:07:52.547074+00	Bohu	בהו	5b92dc65-9487-4487-94a5-7ae21ace7aab	בהו
77	2020-01-14 00:34:20.949459+00	2020-01-14 00:34:20.949784+00	Yekhidah	יחידה	5b92dc65-9487-4487-94a5-7ae21ace7aab	דהחיי
26	2019-12-17 00:13:02.108629+00	2019-12-17 00:14:07.384365+00	Hegeh	הגה	5b92dc65-9487-4487-94a5-7ae21ace7aab	גהה
3	2019-12-02 20:57:42.961688+00	2020-01-17 14:56:34.661346+00	Jah	יה	5b92dc65-9487-4487-94a5-7ae21ace7aab	הי
28	2019-12-17 00:52:36.912213+00	2019-12-17 00:52:36.912322+00	Dam	דם	5b92dc65-9487-4487-94a5-7ae21ace7aab	דם
29	2019-12-17 01:16:34.290159+00	2019-12-17 01:16:34.290245+00	Nachash	נחש	5b92dc65-9487-4487-94a5-7ae21ace7aab	חנש
30	2019-12-17 01:17:49.32419+00	2019-12-17 01:17:49.324274+00	Messiach	משיח	5b92dc65-9487-4487-94a5-7ae21ace7aab	חימש
31	2019-12-17 01:19:08.210188+00	2019-12-17 01:19:08.210285+00	Messia	משי	5b92dc65-9487-4487-94a5-7ae21ace7aab	ימש
32	2019-12-17 23:43:14.479342+00	2019-12-17 23:43:14.479464+00	malak	מלאך	5b92dc65-9487-4487-94a5-7ae21ace7aab	אךלמ
33	2019-12-17 23:46:32.453638+00	2019-12-17 23:46:32.454159+00	sokeh	סוכה	5b92dc65-9487-4487-94a5-7ae21ace7aab	הוכס
34	2019-12-17 23:49:37.880624+00	2019-12-17 23:49:37.880711+00	Jehovah elohino Jehovah	יהוה אלהינו יהוה	5b92dc65-9487-4487-94a5-7ae21ace7aab	אהההההוווייילנ
35	2019-12-17 23:52:03.475966+00	2019-12-17 23:52:03.476056+00	be-Tzion	בציון	5b92dc65-9487-4487-94a5-7ae21ace7aab	בויןצ
36	2019-12-17 23:54:58.714098+00	2019-12-17 23:54:58.714185+00	Mem chaiim	מים חיים	5b92dc65-9487-4487-94a5-7ae21ace7aab	חיייםםמ
37	2019-12-18 00:04:17.819845+00	2019-12-18 00:04:17.821562+00	Israel	ישראל	5b92dc65-9487-4487-94a5-7ae21ace7aab	אילרש
38	2019-12-18 00:17:59.757869+00	2019-12-18 00:17:59.757955+00	Adam	אדם	5b92dc65-9487-4487-94a5-7ae21ace7aab	אדם
39	2019-12-18 00:29:50.996877+00	2019-12-18 00:30:45.738688+00	magnesia	מאגנטיה	5b92dc65-9487-4487-94a5-7ae21ace7aab	אגהטימנ
40	2019-12-18 00:31:13.044448+00	2019-12-18 00:31:13.044545+00	Magnetia	מגנטיה	5b92dc65-9487-4487-94a5-7ae21ace7aab	גהטימנ
41	2019-12-18 23:32:04.124546+00	2019-12-18 23:34:14.603163+00	khammaw	חמה	5b92dc65-9487-4487-94a5-7ae21ace7aab	החמ
42	2019-12-19 23:14:22.536311+00	2019-12-19 23:14:22.536473+00	Gimmel	גמל	5b92dc65-9487-4487-94a5-7ae21ace7aab	גלמ
43	2019-12-19 23:15:25.033056+00	2019-12-19 23:15:25.033143+00	Nephesh	נפש	5b92dc65-9487-4487-94a5-7ae21ace7aab	נפש
44	2019-12-20 19:00:20.668018+00	2019-12-20 19:00:20.668105+00	Tzaddi	צ	5b92dc65-9487-4487-94a5-7ae21ace7aab	צ
45	2019-12-21 22:38:28.045609+00	2019-12-21 22:38:28.04571+00	Ischschamaim	אש ומים	5b92dc65-9487-4487-94a5-7ae21ace7aab	אויםמש
46	2019-12-21 22:59:41.561067+00	2019-12-21 22:59:41.561154+00	dagan	דגן	5b92dc65-9487-4487-94a5-7ae21ace7aab	גדן
47	2019-12-21 23:01:25.353844+00	2019-12-21 23:01:25.354163+00	daleth	דלת	5b92dc65-9487-4487-94a5-7ae21ace7aab	דלת
48	2019-12-21 23:03:02.706535+00	2019-12-21 23:03:02.706621+00	tal ha-shamaim	טל השמים	5b92dc65-9487-4487-94a5-7ae21ace7aab	הטילםמש
50	2019-12-21 23:21:03.501216+00	2019-12-21 23:21:03.501304+00	eth-abika	את אביך	5b92dc65-9487-4487-94a5-7ae21ace7aab	אאביךת
51	2019-12-21 23:23:55.391664+00	2019-12-21 23:23:55.391752+00	shemeni ha-eretz	שמני הארץ	5b92dc65-9487-4487-94a5-7ae21ace7aab	אהימנץרש
52	2019-12-21 23:25:32.478262+00	2019-12-21 23:25:32.478348+00	shemeni ha-eretz	שמני הארץ	5b92dc65-9487-4487-94a5-7ae21ace7aab	אהימנץרש
53	2019-12-21 23:26:27.496135+00	2019-12-21 23:26:27.496225+00	tsoreth	צורת	5b92dc65-9487-4487-94a5-7ae21ace7aab	וצרת
54	2019-12-21 23:30:52.620791+00	2019-12-21 23:30:52.622415+00	tsoor	צור	5b92dc65-9487-4487-94a5-7ae21ace7aab	וצר
55	2019-12-21 23:32:58.935474+00	2019-12-21 23:33:13.924518+00	shemen	שמן	5b92dc65-9487-4487-94a5-7ae21ace7aab	מןש
56	2019-12-21 23:35:07.064354+00	2019-12-21 23:36:52.576823+00	zakar ve-nequbah	זכר ונקבה	5b92dc65-9487-4487-94a5-7ae21ace7aab	בהוזכנקר
57	2019-12-21 23:38:03.709213+00	2019-12-21 23:38:03.709297+00	sepharim	ספרים	5b92dc65-9487-4487-94a5-7ae21ace7aab	יםספר
58	2019-12-21 23:39:00.789732+00	2019-12-21 23:39:00.789839+00	shamaim	שמים	5b92dc65-9487-4487-94a5-7ae21ace7aab	יםמש
59	2020-01-13 21:07:57.850264+00	2020-01-13 21:07:57.850393+00	aur mopeleh	אור מופלא	5b92dc65-9487-4487-94a5-7ae21ace7aab	אאוולמפר
62	2020-01-13 21:18:21.063136+00	2020-01-13 21:20:05.993228+00	nequdah rashunah	נקודה ראשונה	5b92dc65-9487-4487-94a5-7ae21ace7aab	אדההווננקרש
63	2020-01-14 00:08:52.308931+00	2020-01-14 00:08:52.309041+00	gofreeth	גפרית	5b92dc65-9487-4487-94a5-7ae21ace7aab	גיפרת
64	2020-01-14 00:10:51.87611+00	2020-01-14 00:10:51.876248+00	melakh	מלח	5b92dc65-9487-4487-94a5-7ae21ace7aab	חלמ
65	2020-01-14 00:13:04.85819+00	2020-01-14 00:13:04.859683+00	Enoch	חנך	5b92dc65-9487-4487-94a5-7ae21ace7aab	חךנ
66	2020-01-14 00:13:54.668864+00	2020-01-14 00:13:54.669006+00	lechem	לחם	5b92dc65-9487-4487-94a5-7ae21ace7aab	חלם
67	2020-01-14 00:15:46.716285+00	2020-01-14 00:15:46.716419+00	Bethlechem	ביתלחם	5b92dc65-9487-4487-94a5-7ae21ace7aab	בחילםת
68	2020-01-14 00:17:09.52332+00	2020-01-14 00:17:37.289951+00	mezla	מזלא	5b92dc65-9487-4487-94a5-7ae21ace7aab	אזלמ
70	2020-01-14 00:19:42.122761+00	2020-01-14 00:19:42.122849+00	kad	כד	5b92dc65-9487-4487-94a5-7ae21ace7aab	דכ
69	2020-01-14 00:18:42.360233+00	2020-01-14 00:21:20.015893+00	zeez	זיז	5b92dc65-9487-4487-94a5-7ae21ace7aab	זזי
71	2020-01-14 00:22:17.386416+00	2020-01-14 00:22:17.386504+00	gevyah	גויה	5b92dc65-9487-4487-94a5-7ae21ace7aab	גהוי
72	2020-01-14 00:23:35.275565+00	2020-01-14 00:23:35.275669+00	gevi	גוי	5b92dc65-9487-4487-94a5-7ae21ace7aab	גוי
73	2020-01-14 00:24:49.089757+00	2020-01-14 00:24:49.089848+00	hadak	הדך	5b92dc65-9487-4487-94a5-7ae21ace7aab	דהך
74	2020-01-14 00:26:56.118369+00	2020-01-14 00:26:56.118545+00	kazab	כזב	5b92dc65-9487-4487-94a5-7ae21ace7aab	בזכ
75	2020-01-14 00:29:16.196332+00	2020-01-14 00:29:16.196844+00	magia	magia	abcfbf1f-d44a-49eb-aa22-aa1fa032e82d	aagim
76	2020-01-14 00:32:18.60791+00	2020-01-14 00:32:18.608924+00	athanor	אתהנור	5b92dc65-9487-4487-94a5-7ae21ace7aab	אהונרת
78	2020-01-14 00:36:01.776638+00	2020-01-14 00:36:01.776821+00	abel	הבל	5b92dc65-9487-4487-94a5-7ae21ace7aab	בהל
79	2020-01-14 00:37:40.702325+00	2020-01-14 00:37:40.702627+00	ow	או	5b92dc65-9487-4487-94a5-7ae21ace7aab	או
80	2020-01-14 00:38:56.400886+00	2020-01-14 00:38:56.400999+00	ka-ehben	כאבן	5b92dc65-9487-4487-94a5-7ae21ace7aab	אבכן
81	2020-01-15 18:58:57.947726+00	2020-01-15 18:58:57.947955+00	laib	לב	5b92dc65-9487-4487-94a5-7ae21ace7aab	בל
82	2020-01-15 19:03:41.374248+00	2020-01-15 19:03:41.374333+00	lebanah	לבנה	5b92dc65-9487-4487-94a5-7ae21ace7aab	בהלנ
83	2020-01-15 19:04:57.289792+00	2020-01-15 19:04:57.289882+00	nah	נה	5b92dc65-9487-4487-94a5-7ae21ace7aab	הנ
84	2020-01-15 19:05:41.480474+00	2020-01-15 19:05:41.480649+00	laban	לבנ	5b92dc65-9487-4487-94a5-7ae21ace7aab	בלנ
85	2020-01-15 19:06:51.938559+00	2020-01-15 19:06:51.939059+00	bawnaw	בנה	5b92dc65-9487-4487-94a5-7ae21ace7aab	בהנ
88	2020-01-15 19:09:56.427668+00	2020-01-15 19:09:56.427758+00	ben	בנ	5b92dc65-9487-4487-94a5-7ae21ace7aab	בנ
89	2020-01-17 14:22:06.213859+00	2020-01-17 14:22:06.213964+00	Ruach Elohim	רוח אלהים	5b92dc65-9487-4487-94a5-7ae21ace7aab	אהוחילםר
90	2020-01-17 14:24:06.480948+00	2020-01-17 14:24:06.481037+00	Shin	שין	5b92dc65-9487-4487-94a5-7ae21ace7aab	יןש
91	2020-01-17 14:25:54.411071+00	2020-01-17 14:25:54.411164+00	Chaiah	חיה	5b92dc65-9487-4487-94a5-7ae21ace7aab	החי
92	2020-01-17 14:29:59.68535+00	2020-01-17 14:29:59.685445+00	Ab	אב	5b92dc65-9487-4487-94a5-7ae21ace7aab	אב
93	2020-01-17 14:37:50.93451+00	2020-01-17 14:37:50.934748+00	taleh	טלה	5b92dc65-9487-4487-94a5-7ae21ace7aab	הטל
27	2019-12-17 00:16:12.341409+00	2020-01-17 14:41:01.445782+00	Khool	חול	5b92dc65-9487-4487-94a5-7ae21ace7aab	וחל
94	2020-01-17 14:39:40.136579+00	2020-01-17 14:41:49.822099+00	lahat	להט	5b92dc65-9487-4487-94a5-7ae21ace7aab	הטל
95	2020-01-17 14:44:20.003924+00	2020-01-17 14:44:20.00403+00	Hiram Abiff	חורם אביו	a45331a5-3beb-4562-8234-4f25199a4b76	אבווחיםר
96	2020-01-17 14:47:36.816439+00	2020-01-17 14:50:38.370145+00	ebhen masu ha-bonim	אבן מאסו הבונים	5b92dc65-9487-4487-94a5-7ae21ace7aab	אאבבהוויםמןנס
97	2020-01-17 14:55:13.224193+00	2020-01-17 14:55:13.224279+00	Esh	אש	5b92dc65-9487-4487-94a5-7ae21ace7aab	אש
98	2020-01-17 14:58:04.148865+00	2020-01-17 14:58:04.148953+00	ha-Moriah har	המוריה הר	5b92dc65-9487-4487-94a5-7ae21ace7aab	הההוימרר
99	2020-01-17 14:58:44.889461+00	2020-01-17 14:58:44.889564+00	Moriah	מוריה	5b92dc65-9487-4487-94a5-7ae21ace7aab	הוימר
100	2020-01-17 15:00:41.074458+00	2020-01-17 15:00:41.074563+00	Aleph-Shin	אלף שין	5b92dc65-9487-4487-94a5-7ae21ace7aab	אילןףש
\.


--
-- Data for Name: gematriacore_wordmeaning; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.gematriacore_wordmeaning (id, created, modified, meaning, is_active, word_id, source) FROM stdin;
1	2019-03-23 16:55:45.831391+00	2019-03-23 16:55:45.831434+00	The Crown	t	1	\N
2	2019-03-30 19:43:32.044316+00	2019-03-30 19:43:32.044358+00	Tetragrammaton	\N	2	\N
3	2019-12-06 23:20:45.031255+00	2019-12-06 23:20:45.031425+00	Water	t	6	
4	2019-12-06 23:22:21.703571+00	2019-12-06 23:22:21.703661+00	Life Breath	t	7	
5	2019-12-06 23:22:21.728669+00	2019-12-06 23:22:21.728748+00	Air	f	7	
6	2019-12-06 23:39:25.371023+00	2019-12-06 23:39:25.37111+00	Wisdom	t	8	
7	2019-12-06 23:40:36.557689+00	2019-12-06 23:40:36.557769+00	Power of What	f	9	
8	2019-12-06 23:40:36.6065+00	2019-12-06 23:40:36.606638+00	Hot	f	9	
9	2019-12-06 23:40:36.687028+00	2019-12-06 23:40:36.687107+00	Warm	f	9	
10	2019-12-07 01:36:23.252187+00	2019-12-07 01:36:23.252281+00	To lay bare	f	10	Greek Work Lesson 5 pg 1
11	2019-12-07 01:36:23.277546+00	2019-12-07 01:36:23.27763+00	to denude	f	10	Greek Work Lesson 5 pg 1
12	2019-12-07 01:36:23.302024+00	2019-12-07 01:36:23.302105+00	to strip of concealment	f	10	Greek Work Lesson 5 pg 1
13	2019-12-07 01:36:23.326375+00	2019-12-07 01:36:23.326454+00	Find Out	f	10	google translate
14	2019-12-07 01:42:44.367498+00	2019-12-07 01:42:44.367582+00	he revealeth his secret	f	12	
15	2019-12-11 19:55:10.965896+00	2019-12-11 19:55:10.965995+00	Glory	f	13	
16	2019-12-11 19:55:11.009221+00	2019-12-11 19:55:11.009308+00	splendor	f	13	
17	2019-12-11 23:05:14.144588+00	2019-12-11 23:05:14.144971+00	Egypt	f	14	
18	2019-12-14 16:38:10.265568+00	2019-12-14 16:38:10.26566+00	Fair weather cometh from the north	f	15	Job 37:22 - read in Tarot fundamentals Lesson 36 pg 7
19	2019-12-14 16:38:10.301986+00	2019-12-14 16:38:10.302073+00	Gold Conscience You	f	15	Google Translate
20	2019-12-14 16:40:18.175817+00	2019-12-14 16:40:18.175922+00	Fire of Heaven	f	16	Tarot Fundamentals lesson 36 pg 7
21	2019-12-14 16:40:18.213132+00	2019-12-14 16:40:18.213213+00	Le Feu de Ciel. The name of K16 in French	f	16	Tarot Fundamentals lesson 36 pg 7
22	2019-12-15 23:43:03.725607+00	2019-12-15 23:43:03.725693+00	Handful	f	17	Great Work Lesson 5 Pg 5
23	2019-12-15 23:44:37.108735+00	2019-12-15 23:44:37.108823+00	Pliers	f	17	Google Translate
24	2019-12-15 23:44:37.15104+00	2019-12-15 23:44:37.151133+00	Pincers	f	17	Google Translate
25	2019-12-15 23:44:37.187726+00	2019-12-15 23:44:37.18781+00	Tweezers	f	17	Google Translate
26	2019-12-15 23:44:37.217998+00	2019-12-15 23:44:37.218098+00	Tongs	f	17	Google Translate
27	2019-12-15 23:50:40.476049+00	2019-12-15 23:50:40.476149+00	Everlasting Rock	f	18	Isaiah 26:4 - Great Work PFC pg 5
28	2019-12-15 23:50:40.540857+00	2019-12-15 23:50:40.540984+00	Create worlds	f	18	G translate
29	2019-12-15 23:50:40.599328+00	2019-12-15 23:50:40.599409+00	Everlasting Strength	f	18	Isaiah 26:4 - Authorized version - Great Work PFC pg 5
30	2019-12-17 00:04:21.040316+00	2019-12-17 00:04:21.040459+00	One	f	19	Great Work BOTA L6 P2
31	2019-12-17 00:06:08.407105+00	2019-12-17 00:06:08.407191+00	Brother	f	20	Google translate
32	2019-12-17 00:06:08.436724+00	2019-12-17 00:06:08.436813+00	Friar	f	20	Google translate
33	2019-12-17 00:06:08.463522+00	2019-12-17 00:06:08.463604+00	Kinsman	f	20	Google translate
34	2019-12-17 00:06:08.495226+00	2019-12-17 00:06:08.495311+00	Fellow	f	20	Google translate
35	2019-12-17 00:06:08.520946+00	2019-12-17 00:06:08.521029+00	Hearth	f	20	Google translate
36	2019-12-17 00:06:08.553871+00	2019-12-17 00:06:08.553958+00	Fireplace	f	20	Google translate
37	2019-12-17 00:07:53.828619+00	2019-12-17 00:07:53.828702+00	Emptiness	f	21	GW BOTA L6 P2
38	2019-12-17 00:07:53.85206+00	2019-12-17 00:07:53.852149+00	Chaos	f	21	GW BOTA L6 P2
39	2019-12-17 00:07:53.880618+00	2019-12-17 00:07:53.880698+00	Void	f	21	GW BOTA L6 P2
40	2019-12-17 00:07:53.915837+00	2019-12-17 00:07:53.915918+00	Confusion	f	21	Goggle Translate
41	2019-12-17 00:13:04.859037+00	2019-12-17 00:13:04.859142+00	Sound	f	26	GW BOTA L6 P2
42	2019-12-17 00:13:04.964815+00	2019-12-17 00:13:04.964906+00	Muttering	f	26	GW BOTA L6 P2
43	2019-12-17 00:13:05.045441+00	2019-12-17 00:13:05.045519+00	Thought	f	26	GW BOTA L6 P2
44	2019-12-17 00:14:08.825782+00	2019-12-17 00:14:08.826387+00	Wheel	f	26	Google Translate
45	2019-12-17 00:14:08.882273+00	2019-12-17 00:14:08.882455+00	Rudder	f	26	Google Translate
46	2019-12-17 00:14:08.941574+00	2019-12-17 00:14:08.94172+00	Helm	f	26	Google Translate
47	2019-12-17 00:14:08.971934+00	2019-12-17 00:14:08.97203+00	Steering wheel	f	26	Google Translate
49	2019-12-17 00:16:13.394075+00	2019-12-17 00:16:13.394159+00	Related to the First Matter, alchemists often call this their Phoenix	f	27	GW BOTA L2 P6
51	2019-12-17 00:52:37.870694+00	2019-12-17 00:52:37.870778+00	Blood	f	28	
52	2019-12-17 01:16:35.309132+00	2019-12-17 01:16:35.309219+00	Copper	f	29	GW L6 P5
53	2019-12-17 01:16:35.33585+00	2019-12-17 01:16:35.335929+00	Serpent	f	29	GW L6 P5
54	2019-12-17 01:16:35.361972+00	2019-12-17 01:16:35.362059+00	Snake	f	29	GW L6 P5
55	2019-12-17 01:16:35.386383+00	2019-12-17 01:16:35.386465+00	Sorcery	f	29	GT
56	2019-12-17 01:16:35.4105+00	2019-12-17 01:16:35.410581+00	Magic	f	29	GT
57	2019-12-17 01:17:50.557413+00	2019-12-17 01:17:50.557501+00	The Anointed	f	30	GW BOTA L6 P5
58	2019-12-17 01:17:50.591535+00	2019-12-17 01:17:50.591625+00	Messiah	f	30	GW BOTA L6 P5
59	2019-12-17 01:19:09.459401+00	2019-12-17 01:19:09.459484+00	Silk	f	31	GT
60	2019-12-17 01:19:09.486535+00	2019-12-17 01:19:09.486635+00	Satin	f	31	GT
61	2019-12-17 23:43:15.816141+00	2019-12-17 23:43:15.816224+00	One sent	f	32	GW BOTA L7 P3
62	2019-12-17 23:43:15.850002+00	2019-12-17 23:43:15.850081+00	Angel	f	32	GT and the GW BOTA L7 P3 lesson the context is of Angels
63	2019-12-17 23:46:33.810213+00	2019-12-17 23:46:33.810297+00	Branch	f	33	GW BOTA L7 P3
64	2019-12-17 23:46:33.840101+00	2019-12-17 23:46:33.840186+00	Bough	f	33	GW BOTA L7 P3
65	2019-12-17 23:46:33.865391+00	2019-12-17 23:46:33.865469+00	Succah	f	33	GT, Also in the one video for Chet on youtube. Enclosure for a marriage
66	2019-12-17 23:49:40.878419+00	2019-12-17 23:49:40.878507+00	Jehovah, our God Jehovah	f	34	GW BOTA L7 P3
67	2019-12-17 23:52:04.878757+00	2019-12-17 23:52:04.878845+00	In Zion	f	35	GW BOTA L7 P3
68	2019-12-17 23:52:04.907949+00	2019-12-17 23:52:04.908068+00	CENTRE of human personality, the Point Within, where man makes direct contact with the One Reality	f	35	GW BOTA L7 P3
69	2019-12-17 23:55:00.447346+00	2019-12-17 23:55:00.447433+00	the fountain of living waters	f	36	GW BOTA L7 P3
70	2019-12-17 23:55:00.470441+00	2019-12-17 23:55:00.470522+00	Living Water	f	36	GT
71	2019-12-17 23:55:00.494202+00	2019-12-17 23:55:00.494284+00	spring water	f	36	GT
72	2019-12-18 00:04:19.112567+00	2019-12-18 00:04:19.112657+00	Israel	f	37	
73	2019-12-18 00:18:00.817545+00	2019-12-18 00:18:00.817825+00	spiritual blood. Adam is Aleph or Ruach with dam or blood	f	38	GW BOTA L7 P4
74	2019-12-18 00:18:00.845177+00	2019-12-18 00:18:00.845257+00	Man	f	38	
75	2019-12-18 00:29:52.642122+00	2019-12-18 00:29:52.642204+00	magnesia spelt phonetically. Magnet of Jah	f	39	GW BOTA L7 P5
76	2019-12-18 00:31:14.455731+00	2019-12-18 00:31:14.455823+00	magnet	f	40	GT
78	2019-12-18 23:32:06.088295+00	2019-12-18 23:32:06.088375+00	rage	f	41	GT
79	2019-12-18 23:32:06.111325+00	2019-12-18 23:32:06.111405+00	heat	f	41	GT
77	2019-12-18 23:32:06.060447+00	2019-12-18 23:34:16.277054+00	Sun. refers to the angle of Osiris and Horus in the pythagorean triangle, they are also solar deities	f	41	
80	2019-12-19 23:14:24.800907+00	2019-12-19 23:14:24.800991+00	Camel	f	42	
81	2019-12-19 23:15:27.270385+00	2019-12-19 23:15:27.270472+00	vital or animal soul	f	43	
82	2019-12-20 19:00:21.959893+00	2019-12-20 19:00:21.959991+00	Fish Hook	f	44	
83	2019-12-20 19:00:21.996672+00	2019-12-20 19:00:21.996769+00	to think	f	44	
84	2019-12-20 19:00:22.02536+00	2019-12-20 19:00:22.025479+00	to speculate	f	44	
85	2019-12-20 19:00:22.070186+00	2019-12-20 19:00:22.070274+00	to fancy	f	44	
86	2019-12-21 22:38:31.387192+00	2019-12-21 22:38:31.387294+00	Fire and Water	f	45	GW BOTA L10 P2
87	2019-12-21 22:38:31.420053+00	2019-12-21 22:38:31.420135+00	Sulphur and Mercury	f	45	GW BOTA L10 P2
88	2019-12-21 22:59:43.455575+00	2019-12-21 22:59:43.455662+00	grain	f	46	Genesis 27:28
89	2019-12-21 23:01:27.816713+00	2019-12-21 23:01:27.816801+00	door	f	47	GW BOTA L10 P3
90	2019-12-21 23:01:27.848471+00	2019-12-21 23:01:27.848554+00	Fourth letter of the Hebrew alphabet spelt in full	f	47	
91	2019-12-21 23:03:05.813572+00	2019-12-21 23:03:05.813661+00	dew of heaven	f	48	GW BOTA L10 P3
92	2019-12-21 23:21:06.488711+00	2019-12-21 23:21:06.488808+00	the essence of thy father	f	50	GW BOTA L10 P3
93	2019-12-21 23:23:58.657603+00	2019-12-21 23:23:58.65771+00	Oiliness of the Earth	f	51	GW BOTA L10 P3
94	2019-12-21 23:23:58.685275+00	2019-12-21 23:23:58.685384+00	Oils of the earth	f	51	GT
95	2019-12-21 23:25:35.838736+00	2019-12-21 23:25:35.838823+00	Oiliness of the Earth	f	52	GW BOTA L10 P3
96	2019-12-21 23:25:35.863185+00	2019-12-21 23:25:35.863265+00	Oils of the earth	f	52	GT
97	2019-12-21 23:25:35.887745+00	2019-12-21 23:25:35.887841+00	Same value as Genesis 1:5 "And God called the light Day."	f	52	
98	2019-12-21 23:26:29.84034+00	2019-12-21 23:26:29.840432+00	form	f	53	GW BOTA L10 P3
99	2019-12-21 23:26:29.864605+00	2019-12-21 23:26:29.86469+00	shape	f	53	GT
100	2019-12-21 23:30:54.592522+00	2019-12-21 23:30:54.592611+00	rock	f	54	GW BOTA L10 P4
101	2019-12-21 23:30:54.650705+00	2019-12-21 23:30:54.650792+00	fortress	f	54	GT
102	2019-12-21 23:30:54.679885+00	2019-12-21 23:30:54.679969+00	To press, to confine, to render compact.	f	54	GW BOTA L10 P4
103	2019-12-21 23:33:00.9902+00	2019-12-21 23:33:00.990292+00	oil	f	55	GW BOTA L10 P4
104	2019-12-21 23:33:01.014633+00	2019-12-21 23:33:01.014714+00	fat	f	55	GT
105	2019-12-21 23:35:10.522244+00	2019-12-21 23:35:10.522331+00	male and female	f	56	GW BOTA L10 P4
106	2019-12-21 23:38:06.454171+00	2019-12-21 23:38:06.454255+00	letters	f	57	GW BOTA L10 P4
107	2019-12-21 23:38:06.47896+00	2019-12-21 23:38:06.479084+00	Books	f	57	GT
108	2019-12-21 23:39:03.358587+00	2019-12-21 23:39:03.358688+00	heaven	f	58	GW BOTA L10 P4
109	2020-01-13 21:08:04.339479+00	2020-01-13 21:08:04.339575+00	Hidden Light	f	59	BOTA GW L13 P2
110	2020-01-13 21:08:04.410629+00	2020-01-13 21:08:04.410804+00	Wonderful light	f	59	GT
111	2020-01-13 21:10:07.940388+00	2020-01-13 21:10:07.940526+00	Simplest Light	f	60	BOTA GW L13 P2
112	2020-01-13 21:12:46.541661+00	2020-01-13 21:12:46.541753+00	Inner Light	f	61	BOTA GW L13 P2
114	2020-01-13 21:18:27.759022+00	2020-01-13 21:18:27.75911+00	First Point	f	62	GT
113	2020-01-13 21:18:27.725957+00	2020-01-13 21:19:57.148839+00	Primordial Point. Kethe also called the "Exsistance of Exsistences", "Concealed of the Concealed.	f	62	BOTA GW L13 P2
115	2020-01-14 00:08:56.66387+00	2020-01-14 00:08:56.663982+00	Sulpher	f	63	BOTA GW L14 P4
116	2020-01-14 00:10:54.392871+00	2020-01-14 00:10:54.393131+00	Salt	f	64	BOTA GW L15 PG 3
117	2020-01-14 00:13:07.983477+00	2020-01-14 00:13:07.983688+00	walked with God	f	65	BOTA GW L15 PG 3
118	2020-01-14 00:13:08.028379+00	2020-01-14 00:13:08.028463+00	Educator	f	65	GT
119	2020-01-14 00:13:57.491076+00	2020-01-14 00:13:57.491166+00	food, bread.	f	66	BOTA GW L15 PG 3
120	2020-01-14 00:15:50.797071+00	2020-01-14 00:15:50.79716+00	House of bread	f	67	GW BOTA 15 PG3
121	2020-01-14 00:17:09.815552+00	2020-01-14 00:17:09.815727+00	to drip, to flow down in drops.	f	68	BOTA GW L15 PG4
122	2020-01-14 00:17:09.861685+00	2020-01-14 00:17:09.861856+00	good luck	f	68	GT
124	2020-01-14 00:18:46.504202+00	2020-01-14 00:18:46.5043+00	ledge	f	69	GT
125	2020-01-14 00:19:45.284718+00	2020-01-14 00:19:45.284802+00	a pot	f	70	GW BOTA L16 PG1
126	2020-01-14 00:19:45.319174+00	2020-01-14 00:19:45.319256+00	jug	f	70	GT
127	2020-01-14 00:19:45.381003+00	2020-01-14 00:19:45.381094+00	pitcher	f	70	GT
123	2020-01-14 00:18:46.475469+00	2020-01-14 00:21:22.209928+00	abundance	f	69	BOTA GW L16 PG1
128	2020-01-14 00:22:22.343557+00	2020-01-14 00:22:22.34365+00	body or substance	f	71	BOTA GW L16 PG1
129	2020-01-14 00:22:22.393567+00	2020-01-14 00:22:22.393655+00	corpse, stiff, cadaver	f	71	GT
130	2020-01-14 00:23:39.650082+00	2020-01-14 00:23:39.650358+00	gentile	f	72	GT
131	2020-01-14 00:23:39.757625+00	2020-01-14 00:23:39.758075+00	nation	f	72	GT
132	2020-01-14 00:24:51.824409+00	2020-01-14 00:24:51.824493+00	to breakdown, to overturn	f	73	BOTA GW L16 P1
133	2020-01-14 00:24:51.8552+00	2020-01-14 00:24:51.855286+00	echo	f	73	GT
134	2020-01-14 00:26:58.81192+00	2020-01-14 00:26:58.812133+00	to spin, to bind together, to decieve	f	74	BOTA GW L16 P1
135	2020-01-14 00:26:58.85766+00	2020-01-14 00:26:58.857752+00	falsehood	f	74	GT
136	2020-01-14 00:29:16.435897+00	2020-01-14 00:29:16.435991+00	magic	f	75	BOTA GW L16 PG1
137	2020-01-14 00:32:22.88057+00	2020-01-14 00:32:22.880661+00	Essence of Fire	f	76	BOTA GW L16 P5
138	2020-01-14 00:34:25.533677+00	2020-01-14 00:34:25.533766+00	universal Self seated in Kether	f	77	BOTA GW L16 P5
139	2020-01-14 00:34:25.592093+00	2020-01-14 00:34:25.592175+00	unit	f	77	GT
140	2020-01-14 00:36:05.296369+00	2020-01-14 00:36:05.29654+00	to breathe, to evaporate	f	78	BOTA GW L16 P5
141	2020-01-14 00:36:05.346019+00	2020-01-14 00:36:05.34611+00	transitoriness, emptiness, vanity	f	78	BOTA GW L16 P5
142	2020-01-14 00:36:05.419772+00	2020-01-14 00:36:05.419853+00	steam	f	78	GT
143	2020-01-14 00:37:43.246532+00	2020-01-14 00:37:43.24664+00	desire, will, appetite	f	79	BOTA GW L16 P6
144	2020-01-14 00:37:43.288917+00	2020-01-14 00:37:43.289048+00	or	f	79	GT
145	2020-01-14 00:37:43.339488+00	2020-01-14 00:37:43.339584+00	either	f	79	GT
146	2020-01-14 00:39:00.159524+00	2020-01-14 00:39:00.159614+00	as (or like) a stone	f	80	BOTA GW L16 P6
147	2020-01-15 18:59:01.934304+00	2020-01-15 18:59:01.934387+00	the heart (in all senses, especially as the seat of knowledge, understanding and thinking ); also, midst, center	f	81	BOTA TF L40 PG4
148	2020-01-15 19:03:44.492721+00	2020-01-15 19:03:44.49281+00	Moon	f	82	BOTA TF L40 PG4
149	2020-01-15 19:03:44.558009+00	2020-01-15 19:03:44.558153+00	The Hebrew word for Moon is LBNH, lebanah. Its first two letters spell laib, "heart". The second two spell BN, "son". The last two spell NH, nah, "ornament, beautification." The first three letters sp	f	82	BOTA TF L40 PG4
150	2020-01-15 19:04:59.419553+00	2020-01-15 19:04:59.419637+00	ornament, beautification	f	83	BOTA TF L40 PG4
151	2020-01-15 19:05:44.563356+00	2020-01-15 19:05:44.563442+00	white	f	84	BOTA TF L40 PG4
152	2020-01-15 19:06:55.002961+00	2020-01-15 19:06:55.003044+00	to build, to make, to erect.	f	85	BOTA TF L40 PG4
155	2020-01-15 19:09:59.183376+00	2020-01-15 19:09:59.183468+00	son	f	88	BOTA TF L40 PG4
156	2020-01-17 14:22:11.326426+00	2020-01-17 14:22:11.326508+00	Life-breath of the Creative Powers	f	89	BOTA GW L19 PG1
157	2020-01-17 14:22:11.358424+00	2020-01-17 14:22:11.358821+00	The Spirit of God	f	89	GT
158	2020-01-17 14:24:10.449865+00	2020-01-17 14:24:10.449959+00	letter name for Shin. Note the Gematria here is the same as the degrees in a circle	f	90	BOTA GW L19 PG1
159	2020-01-17 14:25:57.475972+00	2020-01-17 14:25:57.476054+00	the life-force; synonomous with prana	f	91	BOTA GW L19 PG1
160	2020-01-17 14:25:57.537637+00	2020-01-17 14:25:57.537721+00	animal, beast	f	91	GT
161	2020-01-17 14:30:02.006849+00	2020-01-17 14:30:02.007209+00	Father. One of the names for Chokmah.	f	92	BOTA GW L19 PG2
162	2020-01-17 14:37:54.779989+00	2020-01-17 14:37:54.7802+00	lamb or young ram	f	93	BOTA GW L19 PG3
163	2020-01-17 14:39:43.247935+00	2020-01-17 14:39:43.248025+00	flame, magic	f	94	BOTA GW L19 PG3
164	2020-01-17 14:39:43.281438+00	2020-01-17 14:39:43.281527+00	glow	f	94	GT
48	2019-12-17 00:16:13.368705+00	2020-01-17 14:41:04.712923+00	Sand	f	27	GW BOTA L2 P6
50	2019-12-17 00:17:15.849868+00	2020-01-17 14:41:04.751749+00	As a verb - to turn round, to twist, to whirl	f	27	GW BOTA L2 P6
165	2020-01-17 14:41:52.161583+00	2020-01-17 14:41:52.16167+00	magical fire	f	94	BOTA GW L19 PG3
166	2020-01-17 14:44:20.094564+00	2020-01-17 14:44:20.094665+00	Hiram Abiff	f	95	BOTA GW L19 PG3
167	2020-01-17 14:47:43.672172+00	2020-01-17 14:47:43.672262+00	the stone which the builders refused (Psalm 118:22)	f	96	BOTA GW L19 PG3
168	2020-01-17 14:47:43.777316+00	2020-01-17 14:50:45.003083+00	Hiram the "rejected stone", was the son of a widow fo the Tribe Naphtali (Naphtali is Virgo)	f	96	BOTA GW L19 PG3
169	2020-01-17 14:55:16.593923+00	2020-01-17 14:55:16.594008+00	fire	f	97	BOTA GW L19 PG4
170	2020-01-17 14:56:38.603753+00	2020-01-17 14:56:38.603954+00	special name given to Chokmah, which is also the "Root of Fire"	f	3	BOTA GW L19 PG4
171	2020-01-17 14:58:08.852723+00	2020-01-17 14:58:08.85313+00	Mount Moriah	f	98	BOTA GW L19 PG4
172	2020-01-17 14:58:08.886399+00	2020-01-17 14:58:08.886486+00	the hill of the Divine Vision	f	98	BOTA GW L19 PG4
173	2020-01-17 14:58:48.39909+00	2020-01-17 14:58:48.399172+00	seen of Jah	f	99	BOTA GW L19 PG4
174	2020-01-17 15:00:45.195899+00	2020-01-17 15:00:45.195989+00	Esh Fire in plentitude	f	100	BOTA GW L19 PG4
\.


--
-- Data for Name: gematriacore_wordvalue; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.gematriacore_wordvalue (id, created, modified, value, gematria_method_id, word_id) FROM stdin;
1	2019-12-02 17:30:21.782+00	2019-12-02 17:30:21.782111+00	26	1	2
22	2019-12-02 18:07:20.508968+00	2019-12-02 18:09:39.643619+00	620	1	1
23	2019-12-02 18:07:21.504856+00	2019-12-02 18:09:39.971531+00	620	2	1
26	2019-12-06 23:49:53.010524+00	2019-12-06 23:49:53.010717+00	100	1	6
27	2019-12-06 23:50:01.61106+00	2019-12-06 23:50:01.611156+00	660	2	6
28	2019-12-06 23:51:45.025725+00	2019-12-06 23:51:45.025808+00	73	1	8
29	2019-12-06 23:51:56.190757+00	2019-12-06 23:51:56.190894+00	73	2	8
30	2019-12-06 23:51:58.77377+00	2019-12-06 23:51:58.773868+00	214	1	7
31	2019-12-06 23:52:01.537169+00	2019-12-06 23:52:01.537853+00	73	1	9
32	2019-12-06 23:52:06.505471+00	2019-12-06 23:52:06.505588+00	214	2	7
33	2019-12-06 23:52:08.300878+00	2019-12-06 23:52:08.300975+00	73	2	9
34	2019-12-07 01:36:22.370789+00	2019-12-07 01:36:22.370874+00	38	1	10
35	2019-12-07 01:36:23.029603+00	2019-12-07 01:36:23.029698+00	38	2	10
36	2019-12-07 01:42:43.459022+00	2019-12-07 01:42:43.459118+00	114	1	12
37	2019-12-07 01:42:44.281905+00	2019-12-07 01:42:44.281989+00	114	2	12
38	2019-12-11 19:55:10.347872+00	2019-12-11 19:55:10.348102+00	15	1	13
39	2019-12-11 19:55:10.825471+00	2019-12-11 19:55:10.82556+00	15	2	13
40	2019-12-11 23:05:12.821739+00	2019-12-11 23:05:12.821831+00	380	1	14
41	2019-12-11 23:05:13.936569+00	2019-12-11 23:05:13.936676+00	940	2	14
42	2019-12-14 16:38:08.813472+00	2019-12-14 16:38:08.813565+00	696	1	15
43	2019-12-14 16:38:10.147683+00	2019-12-14 16:38:10.147771+00	1346	2	15
44	2019-12-14 16:40:17.324533+00	2019-12-14 16:40:17.324622+00	696	1	16
45	2019-12-14 16:40:18.079222+00	2019-12-14 16:40:18.079318+00	1256	2	16
46	2019-12-15 23:43:02.725354+00	2019-12-15 23:44:36.610799+00	492	1	17
47	2019-12-15 23:43:03.45899+00	2019-12-15 23:44:37.037777+00	492	2	17
48	2019-12-15 23:50:38.253794+00	2019-12-15 23:50:38.253885+00	492	1	18
49	2019-12-15 23:50:40.249645+00	2019-12-15 23:50:40.249825+00	1052	2	18
50	2019-12-17 00:04:20.11114+00	2019-12-17 00:04:20.111983+00	13	1	19
51	2019-12-17 00:04:20.952196+00	2019-12-17 00:04:20.952285+00	13	2	19
52	2019-12-17 00:06:07.70751+00	2019-12-17 00:06:07.707725+00	9	1	20
53	2019-12-17 00:06:08.257181+00	2019-12-17 00:06:08.257369+00	9	2	20
54	2019-12-17 00:07:53.05964+00	2019-12-17 00:07:53.059727+00	13	1	21
55	2019-12-17 00:07:53.647048+00	2019-12-17 00:07:53.647155+00	13	2	21
95	2019-12-19 23:15:26.132618+00	2019-12-19 23:15:26.13271+00	430	2	43
96	2019-12-19 23:15:26.536377+00	2019-12-19 23:15:26.536469+00	557	3	43
56	2019-12-17 00:13:03.146712+00	2019-12-17 00:14:07.957515+00	13	1	26
57	2019-12-17 00:13:04.638141+00	2019-12-17 00:14:08.750213+00	13	2	26
24	2019-12-02 20:57:43.132853+00	2020-01-17 14:56:35.558152+00	15	1	3
25	2019-12-02 20:57:43.299055+00	2020-01-17 14:56:36.469217+00	15	2	3
60	2019-12-17 00:52:37.293238+00	2019-12-17 00:52:37.293383+00	44	1	28
61	2019-12-17 00:52:37.677686+00	2019-12-17 00:52:37.677771+00	604	2	28
62	2019-12-17 01:16:34.822686+00	2019-12-17 01:16:34.822773+00	358	1	29
63	2019-12-17 01:16:35.216168+00	2019-12-17 01:16:35.216345+00	358	2	29
64	2019-12-17 01:17:49.962233+00	2019-12-17 01:17:49.962328+00	358	1	30
65	2019-12-17 01:17:50.444046+00	2019-12-17 01:17:50.444141+00	358	2	30
66	2019-12-17 01:19:08.802058+00	2019-12-17 01:19:08.802143+00	350	1	31
67	2019-12-17 01:19:09.369759+00	2019-12-17 01:19:09.369847+00	350	2	31
68	2019-12-17 23:43:14.98144+00	2019-12-17 23:43:14.981531+00	91	1	32
69	2019-12-17 23:43:15.605612+00	2019-12-17 23:43:15.605711+00	571	2	32
70	2019-12-17 23:46:33.216418+00	2019-12-17 23:46:33.216508+00	91	1	33
71	2019-12-17 23:46:33.707515+00	2019-12-17 23:46:33.707605+00	91	2	33
72	2019-12-17 23:49:39.361513+00	2019-12-17 23:49:39.361599+00	154	1	34
73	2019-12-17 23:49:40.788285+00	2019-12-17 23:49:40.788371+00	154	2	34
74	2019-12-17 23:52:04.292442+00	2019-12-17 23:52:04.292539+00	158	1	35
75	2019-12-17 23:52:04.786526+00	2019-12-17 23:52:04.786613+00	808	2	35
76	2019-12-17 23:54:59.722058+00	2019-12-17 23:54:59.722142+00	158	1	36
77	2019-12-17 23:55:00.356574+00	2019-12-17 23:55:00.356661+00	1278	2	36
78	2019-12-18 00:04:18.391431+00	2019-12-18 00:04:18.391523+00	541	1	37
79	2019-12-18 00:04:18.972214+00	2019-12-18 00:04:18.972302+00	541	2	37
80	2019-12-18 00:18:00.275124+00	2019-12-18 00:18:00.275209+00	45	1	38
81	2019-12-18 00:18:00.703318+00	2019-12-18 00:18:00.703679+00	605	2	38
82	2019-12-18 00:29:51.749137+00	2019-12-18 00:30:46.576971+00	118	1	39
83	2019-12-18 00:29:52.549672+00	2019-12-18 00:30:47.228833+00	118	2	39
84	2019-12-18 00:31:13.671127+00	2019-12-18 00:31:13.671211+00	117	1	40
85	2019-12-18 00:31:14.35952+00	2019-12-18 00:31:14.359613+00	117	2	40
86	2019-12-18 23:32:04.537153+00	2019-12-18 23:34:15.079236+00	53	1	41
87	2019-12-18 23:32:05.108405+00	2019-12-18 23:34:15.554872+00	53	2	41
88	2019-12-18 23:32:05.610859+00	2019-12-18 23:34:15.879262+00	514	3	41
89	2019-12-18 23:32:05.973844+00	2019-12-18 23:34:16.209656+00	50	4	41
90	2019-12-19 23:14:23.160285+00	2019-12-19 23:14:23.160374+00	73	1	42
91	2019-12-19 23:14:23.579188+00	2019-12-19 23:14:23.579285+00	73	2	42
92	2019-12-19 23:14:24.011254+00	2019-12-19 23:14:24.011353+00	237	3	42
93	2019-12-19 23:14:24.666057+00	2019-12-19 23:14:24.666166+00	59	4	42
94	2019-12-19 23:15:25.629533+00	2019-12-19 23:15:25.629631+00	430	1	43
97	2019-12-19 23:15:27.098675+00	2019-12-19 23:15:27.098816+00	276	4	43
98	2019-12-20 19:00:20.93259+00	2019-12-20 19:00:20.932683+00	90	1	44
99	2019-12-20 19:00:21.210787+00	2019-12-20 19:00:21.210885+00	90	2	44
100	2019-12-20 19:00:21.56358+00	2019-12-20 19:00:21.563676+00	104	3	44
101	2019-12-20 19:00:21.855884+00	2019-12-20 19:00:21.856059+00	72	4	44
102	2019-12-21 22:38:28.976178+00	2019-12-21 22:38:28.976267+00	397	1	45
103	2019-12-21 22:38:29.718021+00	2019-12-21 22:38:29.718108+00	957	2	45
104	2019-12-21 22:38:30.586266+00	2019-12-21 22:38:30.586359+00	683	3	45
105	2019-12-21 22:38:31.28956+00	2019-12-21 22:38:31.289647+00	270	4	45
106	2019-12-21 22:59:41.967836+00	2019-12-21 22:59:41.968102+00	57	1	46
107	2019-12-21 22:59:42.367524+00	2019-12-21 22:59:42.367667+00	707	2	46
108	2019-12-21 22:59:42.886357+00	2019-12-21 22:59:42.886557+00	653	3	46
109	2019-12-21 22:59:43.337246+00	2019-12-21 22:59:43.337413+00	47	4	46
110	2019-12-21 23:01:25.859069+00	2019-12-21 23:01:25.859218+00	434	1	47
111	2019-12-21 23:01:26.298217+00	2019-12-21 23:01:26.298402+00	434	2	47
112	2019-12-21 23:01:26.830485+00	2019-12-21 23:01:26.830577+00	954	3	47
113	2019-12-21 23:01:27.700446+00	2019-12-21 23:01:27.700541+00	390	4	47
114	2019-12-21 23:03:03.329372+00	2019-12-21 23:03:03.329461+00	434	1	48
115	2019-12-21 23:03:04.194784+00	2019-12-21 23:03:04.194884+00	994	2	48
116	2019-12-21 23:03:04.852189+00	2019-12-21 23:03:04.852275+00	1059	3	48
117	2019-12-21 23:03:05.714724+00	2019-12-21 23:03:05.71627+00	305	4	48
118	2019-12-21 23:21:04.399869+00	2019-12-21 23:21:04.399954+00	434	1	50
119	2019-12-21 23:21:04.996465+00	2019-12-21 23:21:04.996554+00	914	2	50
120	2019-12-21 23:21:05.750995+00	2019-12-21 23:21:05.75108+00	1160	3	50
121	2019-12-21 23:21:06.395618+00	2019-12-21 23:21:06.395716+00	408	4	50
122	2019-12-21 23:23:56.206151+00	2019-12-21 23:23:56.206251+00	696	1	51
123	2019-12-21 23:23:57.085984+00	2019-12-21 23:23:57.086069+00	1506	2	51
124	2019-12-21 23:23:57.755323+00	2019-12-21 23:23:57.75541+00	1307	3	51
125	2019-12-21 23:23:58.556286+00	2019-12-21 23:23:58.556389+00	467	4	51
126	2019-12-21 23:25:33.216544+00	2019-12-21 23:25:33.216634+00	696	1	52
127	2019-12-21 23:25:34.271177+00	2019-12-21 23:25:34.271263+00	1506	2	52
128	2019-12-21 23:25:35.072228+00	2019-12-21 23:25:35.072344+00	1307	3	52
129	2019-12-21 23:25:35.752391+00	2019-12-21 23:25:35.75248+00	467	4	52
130	2019-12-21 23:26:28.040418+00	2019-12-21 23:26:28.040508+00	696	1	53
131	2019-12-21 23:26:28.551172+00	2019-12-21 23:26:28.55141+00	696	2	53
132	2019-12-21 23:26:29.138543+00	2019-12-21 23:26:29.138642+00	1032	3	53
133	2019-12-21 23:26:29.748916+00	2019-12-21 23:26:29.749024+00	561	4	53
134	2019-12-21 23:30:53.067113+00	2019-12-21 23:30:53.067204+00	296	1	54
135	2019-12-21 23:30:53.669897+00	2019-12-21 23:30:53.669983+00	296	2	54
136	2019-12-21 23:30:54.056986+00	2019-12-21 23:30:54.057118+00	626	3	54
137	2019-12-21 23:30:54.461361+00	2019-12-21 23:30:54.461446+00	201	4	54
58	2019-12-17 00:16:12.88735+00	2020-01-17 14:41:02.353582+00	44	1	27
138	2019-12-21 23:32:59.461684+00	2019-12-21 23:33:14.667175+00	390	1	55
139	2019-12-21 23:33:00.15645+00	2019-12-21 23:33:15.161701+00	1040	2	55
140	2019-12-21 23:33:00.531034+00	2019-12-21 23:33:15.593257+00	556	3	55
141	2019-12-21 23:33:00.900674+00	2019-12-21 23:33:16.243741+00	246	4	55
142	2019-12-21 23:35:08.010579+00	2019-12-21 23:36:53.435556+00	390	1	56
143	2019-12-21 23:35:08.784328+00	2019-12-21 23:36:54.208046+00	390	2	56
144	2019-12-21 23:35:09.661128+00	2019-12-21 23:36:54.847247+00	1399	3	56
145	2019-12-21 23:35:10.42839+00	2019-12-21 23:36:55.581874+00	297	4	56
146	2019-12-21 23:38:04.302418+00	2019-12-21 23:38:04.302509+00	390	1	57
147	2019-12-21 23:38:05.022804+00	2019-12-21 23:38:05.022991+00	950	2	57
148	2019-12-21 23:38:05.567673+00	2019-12-21 23:38:05.567772+00	831	3	57
149	2019-12-21 23:38:06.358421+00	2019-12-21 23:38:06.358517+00	268	4	57
150	2019-12-21 23:39:01.396833+00	2019-12-21 23:39:01.396925+00	390	1	58
151	2019-12-21 23:39:01.93228+00	2019-12-21 23:39:01.93243+00	950	2	58
152	2019-12-21 23:39:02.786792+00	2019-12-21 23:39:02.786879+00	560	3	58
153	2019-12-21 23:39:03.25111+00	2019-12-21 23:39:03.251196+00	258	4	58
154	2020-01-13 21:07:59.778301+00	2020-01-13 21:07:59.778409+00	364	1	59
155	2020-01-13 21:08:01.530625+00	2020-01-13 21:08:01.530712+00	364	2	59
156	2020-01-13 21:08:02.945055+00	2020-01-13 21:08:02.945145+00	1011	3	59
157	2020-01-13 21:08:04.20279+00	2020-01-13 21:08:04.202886+00	258	4	59
158	2020-01-13 21:10:04.621868+00	2020-01-13 21:10:04.622883+00	602	1	60
159	2020-01-13 21:10:05.802872+00	2020-01-13 21:10:05.802959+00	602	2	60
160	2020-01-13 21:10:06.776982+00	2020-01-13 21:10:06.777073+00	1515	3	60
161	2020-01-13 21:10:07.817933+00	2020-01-13 21:10:07.818341+00	396	4	60
162	2020-01-13 21:12:43.28044+00	2020-01-13 21:12:43.280534+00	397	1	61
163	2020-01-13 21:12:44.496268+00	2020-01-13 21:12:44.496474+00	397	2	61
164	2020-01-13 21:12:45.505766+00	2020-01-13 21:12:45.505866+00	960	3	61
165	2020-01-13 21:12:46.424747+00	2020-01-13 21:12:46.424842+00	294	4	61
228	2020-01-14 00:36:04.470296+00	2020-01-14 00:36:04.470431+00	492	3	78
229	2020-01-14 00:36:05.165682+00	2020-01-14 00:36:05.165772+00	36	4	78
230	2020-01-14 00:37:41.394806+00	2020-01-14 00:37:41.394903+00	7	1	79
231	2020-01-14 00:37:41.906601+00	2020-01-14 00:37:41.906691+00	7	2	79
166	2020-01-13 21:18:22.580995+00	2020-01-13 21:20:08.298994+00	727	1	62
167	2020-01-13 21:18:24.271826+00	2020-01-13 21:20:10.998805+00	727	2	62
168	2020-01-13 21:18:26.174777+00	2020-01-13 21:20:12.967508+00	1889	3	62
169	2020-01-13 21:18:27.59991+00	2020-01-13 21:20:14.641736+00	505	4	62
170	2020-01-14 00:08:53.396553+00	2020-01-14 00:08:53.39666+00	693	1	63
171	2020-01-14 00:08:54.214362+00	2020-01-14 00:08:54.214486+00	693	2	63
172	2020-01-14 00:08:55.357038+00	2020-01-14 00:08:55.357136+00	1100	3	63
173	2020-01-14 00:08:56.407723+00	2020-01-14 00:08:56.407809+00	563	4	63
174	2020-01-14 00:10:52.356907+00	2020-01-14 00:10:52.357003+00	78	1	64
175	2020-01-14 00:10:52.942808+00	2020-01-14 00:10:52.943001+00	78	2	64
176	2020-01-14 00:10:53.702216+00	2020-01-14 00:10:53.702304+00	582	3	64
177	2020-01-14 00:10:54.248668+00	2020-01-14 00:10:54.248803+00	66	4	64
178	2020-01-14 00:13:05.704101+00	2020-01-14 00:13:05.7042+00	78	1	65
179	2020-01-14 00:13:06.247506+00	2020-01-14 00:13:06.247592+00	558	2	65
180	2020-01-14 00:13:07.384031+00	2020-01-14 00:13:07.384133+00	624	3	65
181	2020-01-14 00:13:07.866438+00	2020-01-14 00:13:07.866525+00	68	4	65
182	2020-01-14 00:13:55.389783+00	2020-01-14 00:13:55.390382+00	78	1	66
183	2020-01-14 00:13:56.001176+00	2020-01-14 00:13:56.001289+00	638	2	66
184	2020-01-14 00:13:56.469265+00	2020-01-14 00:13:56.469352+00	582	3	66
185	2020-01-14 00:13:57.378762+00	2020-01-14 00:13:57.378849+00	66	4	66
186	2020-01-14 00:15:47.685736+00	2020-01-14 00:15:47.686109+00	490	1	67
187	2020-01-14 00:15:48.77229+00	2020-01-14 00:15:48.77294+00	1050	2	67
188	2020-01-14 00:15:49.632639+00	2020-01-14 00:15:49.63273+00	1420	3	67
189	2020-01-14 00:15:50.623852+00	2020-01-14 00:15:50.624819+00	448	4	67
190	2020-01-14 00:17:38.112175+00	2020-01-14 00:17:38.112512+00	78	1	68
191	2020-01-14 00:17:39.115295+00	2020-01-14 00:17:39.115544+00	78	2	68
192	2020-01-14 00:17:40.121596+00	2020-01-14 00:17:40.121682+00	342	3	68
193	2020-01-14 00:17:41.246756+00	2020-01-14 00:17:41.246847+00	67	4	68
198	2020-01-14 00:19:43.032416+00	2020-01-14 00:19:43.032524+00	24	1	70
199	2020-01-14 00:19:43.677651+00	2020-01-14 00:19:43.677764+00	24	2	70
200	2020-01-14 00:19:44.313197+00	2020-01-14 00:19:44.314365+00	574	3	70
201	2020-01-14 00:19:45.103712+00	2020-01-14 00:19:45.103807+00	26	4	70
194	2020-01-14 00:18:43.768933+00	2020-01-14 00:21:20.570482+00	24	1	69
195	2020-01-14 00:18:44.421796+00	2020-01-14 00:21:21.04543+00	24	2	69
196	2020-01-14 00:18:45.536698+00	2020-01-14 00:21:21.467808+00	154	3	69
197	2020-01-14 00:18:46.330203+00	2020-01-14 00:21:22.082868+00	38	4	69
202	2020-01-14 00:22:18.708056+00	2020-01-14 00:22:18.708153+00	24	1	71
203	2020-01-14 00:22:20.008492+00	2020-01-14 00:22:20.008583+00	24	2	71
204	2020-01-14 00:22:20.84008+00	2020-01-14 00:22:20.840177+00	111	3	71
205	2020-01-14 00:22:22.159325+00	2020-01-14 00:22:22.15956+00	40	4	71
206	2020-01-14 00:23:36.129589+00	2020-01-14 00:23:36.129683+00	19	1	72
207	2020-01-14 00:23:36.912137+00	2020-01-14 00:23:36.912223+00	19	2	72
208	2020-01-14 00:23:38.070877+00	2020-01-14 00:23:38.070982+00	105	3	72
209	2020-01-14 00:23:39.093732+00	2020-01-14 00:23:39.094+00	32	4	72
210	2020-01-14 00:24:49.799726+00	2020-01-14 00:24:49.799816+00	29	1	73
211	2020-01-14 00:24:50.318579+00	2020-01-14 00:24:50.318669+00	509	2	73
212	2020-01-14 00:24:51.164368+00	2020-01-14 00:24:51.164458+00	580	3	73
213	2020-01-14 00:24:51.673895+00	2020-01-14 00:24:51.674062+00	34	4	73
214	2020-01-14 00:26:56.954106+00	2020-01-14 00:26:56.954203+00	29	1	74
215	2020-01-14 00:26:57.460216+00	2020-01-14 00:26:57.460303+00	29	2	74
216	2020-01-14 00:26:57.918325+00	2020-01-14 00:26:57.918417+00	579	3	74
217	2020-01-14 00:26:58.665172+00	2020-01-14 00:26:58.665264+00	34	4	74
218	2020-01-14 00:32:19.886426+00	2020-01-14 00:32:19.886523+00	662	1	76
219	2020-01-14 00:32:20.618051+00	2020-01-14 00:32:20.618342+00	662	2	76
220	2020-01-14 00:32:21.760932+00	2020-01-14 00:32:21.761024+00	1151	3	76
221	2020-01-14 00:32:22.665066+00	2020-01-14 00:32:22.665558+00	536	4	76
222	2020-01-14 00:34:22.122219+00	2020-01-14 00:34:22.122314+00	37	1	77
223	2020-01-14 00:34:23.193804+00	2020-01-14 00:34:23.193963+00	37	2	77
224	2020-01-14 00:34:24.494696+00	2020-01-14 00:34:24.494791+00	938	3	77
225	2020-01-14 00:34:25.306009+00	2020-01-14 00:34:25.306121+00	62	4	77
226	2020-01-14 00:36:02.849517+00	2020-01-14 00:36:02.849604+00	37	1	78
227	2020-01-14 00:36:03.394055+00	2020-01-14 00:36:03.39415+00	37	2	78
232	2020-01-14 00:37:42.311663+00	2020-01-14 00:37:42.311752+00	123	3	79
233	2020-01-14 00:37:42.996279+00	2020-01-14 00:37:42.996371+00	12	4	79
234	2020-01-14 00:38:57.487563+00	2020-01-14 00:38:57.487657+00	73	1	80
235	2020-01-14 00:38:58.185292+00	2020-01-14 00:38:58.185383+00	723	2	80
236	2020-01-14 00:38:59.036288+00	2020-01-14 00:38:59.036375+00	729	3	80
237	2020-01-14 00:39:00.030073+00	2020-01-14 00:39:00.030161+00	63	4	80
238	2020-01-15 18:58:59.405854+00	2020-01-15 18:58:59.40595+00	32	1	81
239	2020-01-15 18:59:00.242373+00	2020-01-15 18:59:00.242554+00	32	2	81
240	2020-01-15 18:59:01.044438+00	2020-01-15 18:59:01.044583+00	486	3	81
241	2020-01-15 18:59:01.800932+00	2020-01-15 18:59:01.80102+00	28	4	81
242	2020-01-15 19:03:42.14894+00	2020-01-15 19:03:42.149125+00	87	1	82
243	2020-01-15 19:03:43.007559+00	2020-01-15 19:03:43.008622+00	87	2	82
244	2020-01-15 19:03:43.754222+00	2020-01-15 19:03:43.754307+00	598	3	82
245	2020-01-15 19:03:44.318119+00	2020-01-15 19:03:44.318204+00	72	4	82
246	2020-01-15 19:04:57.868176+00	2020-01-15 19:04:57.868264+00	55	1	83
247	2020-01-15 19:04:58.311895+00	2020-01-15 19:04:58.311991+00	55	2	83
248	2020-01-15 19:04:58.733585+00	2020-01-15 19:04:58.733697+00	112	3	83
249	2020-01-15 19:04:59.226224+00	2020-01-15 19:04:59.226316+00	44	4	83
250	2020-01-15 19:05:42.25896+00	2020-01-15 19:05:42.259045+00	82	1	84
251	2020-01-15 19:05:42.787115+00	2020-01-15 19:05:42.7872+00	82	2	84
252	2020-01-15 19:05:43.788735+00	2020-01-15 19:05:43.788889+00	592	3	84
253	2020-01-15 19:05:44.40952+00	2020-01-15 19:05:44.409726+00	64	4	84
254	2020-01-15 19:06:52.874174+00	2020-01-15 19:06:52.874275+00	57	1	85
255	2020-01-15 19:06:53.591061+00	2020-01-15 19:06:53.591152+00	57	2	85
256	2020-01-15 19:06:54.15711+00	2020-01-15 19:06:54.157199+00	524	3	85
257	2020-01-15 19:06:54.869394+00	2020-01-15 19:06:54.869483+00	48	4	85
266	2020-01-15 19:09:57.064142+00	2020-01-15 19:09:57.064228+00	52	1	88
267	2020-01-15 19:09:57.84466+00	2020-01-15 19:09:57.844858+00	52	2	88
268	2020-01-15 19:09:58.28442+00	2020-01-15 19:09:58.284619+00	518	3	88
269	2020-01-15 19:09:58.874798+00	2020-01-15 19:09:58.874883+00	40	4	88
270	2020-01-17 14:22:07.379977+00	2020-01-17 14:22:07.380084+00	300	1	89
271	2020-01-17 14:22:08.768914+00	2020-01-17 14:22:08.769002+00	860	2	89
272	2020-01-17 14:22:09.978537+00	2020-01-17 14:22:09.978622+00	1241	3	89
273	2020-01-17 14:22:11.214859+00	2020-01-17 14:22:11.214971+00	224	4	89
274	2020-01-17 14:24:07.655757+00	2020-01-17 14:24:07.655902+00	360	1	90
275	2020-01-17 14:24:08.624158+00	2020-01-17 14:24:08.624253+00	1010	2	90
276	2020-01-17 14:24:09.392616+00	2020-01-17 14:24:09.392827+00	486	3	90
277	2020-01-17 14:24:10.06314+00	2020-01-17 14:24:10.063252+00	234	4	90
278	2020-01-17 14:25:54.954607+00	2020-01-17 14:25:54.954711+00	23	1	91
279	2020-01-17 14:25:55.576476+00	2020-01-17 14:25:55.576578+00	23	2	91
280	2020-01-17 14:25:56.419114+00	2020-01-17 14:25:56.419208+00	444	3	91
281	2020-01-17 14:25:57.115543+00	2020-01-17 14:25:57.115642+00	38	4	91
282	2020-01-17 14:30:00.223218+00	2020-01-17 14:30:00.223305+00	3	1	92
283	2020-01-17 14:30:00.921593+00	2020-01-17 14:30:00.921678+00	3	2	92
284	2020-01-17 14:30:01.32404+00	2020-01-17 14:30:01.324128+00	523	3	92
285	2020-01-17 14:30:01.815382+00	2020-01-17 14:30:01.815481+00	7	4	92
286	2020-01-17 14:37:51.85998+00	2020-01-17 14:37:51.860063+00	44	1	93
287	2020-01-17 14:37:52.307864+00	2020-01-17 14:37:52.307952+00	44	2	93
288	2020-01-17 14:37:53.726583+00	2020-01-17 14:37:53.726812+00	499	3	93
289	2020-01-17 14:37:54.633471+00	2020-01-17 14:37:54.633567+00	47	4	93
59	2019-12-17 00:16:13.269667+00	2020-01-17 14:41:02.93535+00	44	2	27
294	2020-01-17 14:41:03.891359+00	2020-01-17 14:41:03.891447+00	504	3	27
295	2020-01-17 14:41:04.478628+00	2020-01-17 14:41:04.478908+00	45	4	27
290	2020-01-17 14:39:41.010666+00	2020-01-17 14:41:50.541703+00	44	1	94
291	2020-01-17 14:39:41.552424+00	2020-01-17 14:41:50.915373+00	44	2	94
292	2020-01-17 14:39:42.525665+00	2020-01-17 14:41:51.36893+00	499	3	94
293	2020-01-17 14:39:43.113478+00	2020-01-17 14:41:52.082318+00	47	4	94
296	2020-01-17 14:47:38.734864+00	2020-01-17 14:50:40.321364+00	273	1	96
297	2020-01-17 14:47:40.346371+00	2020-01-17 14:50:41.91158+00	1483	2	96
298	2020-01-17 14:47:41.908075+00	2020-01-17 14:50:43.406541+00	1608	3	96
299	2020-01-17 14:47:43.453136+00	2020-01-17 14:50:44.916781+00	230	4	96
300	2020-01-17 14:55:14.375487+00	2020-01-17 14:55:14.375579+00	301	1	97
301	2020-01-17 14:55:15.028179+00	2020-01-17 14:55:15.028543+00	301	2	97
302	2020-01-17 14:55:15.871898+00	2020-01-17 14:55:15.871991+00	471	3	97
303	2020-01-17 14:55:16.415598+00	2020-01-17 14:55:16.415694+00	183	4	97
304	2020-01-17 14:56:37.292068+00	2020-01-17 14:56:37.292198+00	26	3	3
305	2020-01-17 14:56:38.342303+00	2020-01-17 14:56:38.342468+00	26	4	3
306	2020-01-17 14:58:05.292052+00	2020-01-17 14:58:05.292143+00	471	1	98
307	2020-01-17 14:58:06.605362+00	2020-01-17 14:58:06.605488+00	471	2	98
308	2020-01-17 14:58:07.630626+00	2020-01-17 14:58:07.630716+00	1160	3	98
309	2020-01-17 14:58:08.74564+00	2020-01-17 14:58:08.745749+00	321	4	98
310	2020-01-17 14:58:45.834116+00	2020-01-17 14:58:45.834202+00	261	1	99
311	2020-01-17 14:58:46.56284+00	2020-01-17 14:58:46.562969+00	261	2	99
312	2020-01-17 14:58:47.456526+00	2020-01-17 14:58:47.456617+00	638	3	99
313	2020-01-17 14:58:48.162809+00	2020-01-17 14:58:48.162896+00	185	4	99
314	2020-01-17 15:00:42.110428+00	2020-01-17 15:00:42.110546+00	471	1	100
315	2020-01-17 15:00:43.182314+00	2020-01-17 15:00:43.182411+00	1841	2	100
316	2020-01-17 15:00:44.104121+00	2020-01-17 15:00:44.104217+00	762	3	100
317	2020-01-17 15:00:45.07064+00	2020-01-17 15:00:45.070753+00	321	4	100
\.


--
-- Data for Name: socialaccount_socialaccount; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.socialaccount_socialaccount (id, provider, uid, last_login, date_joined, extra_data, user_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.socialaccount_socialapp (id, provider, name, client_id, secret, key) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp_sites; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.socialaccount_socialapp_sites (id, socialapp_id, site_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialtoken; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.socialaccount_socialtoken (id, token, token_secret, expires_at, account_id, app_id) FROM stdin;
\.


--
-- Data for Name: users_user; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.users_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, name) FROM stdin;
1	argon2$argon2i$v=19$m=512,t=2,p=2$MjJlWDZjZnJvN3ZU$jHNMo/kG36aYvv9Hu3hVyQ	2020-01-17 14:18:16.907033+00	t	admin			ndewaard@protonmail.com	t	t	2019-03-21 16:01:17.563359+00	poopman
\.


--
-- Data for Name: users_user_groups; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.users_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: users_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.users_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.account_emailaddress_id_seq', 1, true);


--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.account_emailconfirmation_id_seq', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 72, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 320, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 24, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 51, true);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_site_id_seq', 1, false);


--
-- Name: gematriacore_alphabet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.gematriacore_alphabet_id_seq', 3, true);


--
-- Name: gematriacore_gematriamethod_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.gematriacore_gematriamethod_id_seq', 4, true);


--
-- Name: gematriacore_gematriamethodletterrule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.gematriacore_gematriamethodletterrule_id_seq', 109, true);


--
-- Name: gematriacore_letter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.gematriacore_letter_id_seq', 31, true);


--
-- Name: gematriacore_letter_meanings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.gematriacore_letter_meanings_id_seq', 16, true);


--
-- Name: gematriacore_lettermeaning_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.gematriacore_lettermeaning_id_seq', 28, true);


--
-- Name: gematriacore_letterpower_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.gematriacore_letterpower_id_seq', 50, true);


--
-- Name: gematriacore_word_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.gematriacore_word_id_seq', 100, true);


--
-- Name: gematriacore_wordmeaning_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.gematriacore_wordmeaning_id_seq', 174, true);


--
-- Name: gematriacore_wordvalue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.gematriacore_wordvalue_id_seq', 317, true);


--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.socialaccount_socialaccount_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_sites_id_seq', 1, false);


--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.socialaccount_socialtoken_id_seq', 1, false);


--
-- Name: users_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.users_user_groups_id_seq', 1, false);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.users_user_id_seq', 1, true);


--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.users_user_user_permissions_id_seq', 1, false);


--
-- Name: account_emailaddress account_emailaddress_email_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_email_key UNIQUE (email);


--
-- Name: account_emailaddress account_emailaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_pkey PRIMARY KEY (id);


--
-- Name: account_emailconfirmation account_emailconfirmation_key_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_key_key UNIQUE (key);


--
-- Name: account_emailconfirmation account_emailconfirmation_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: gematriacore_alphabet gematriacore_alphabet_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_alphabet
    ADD CONSTRAINT gematriacore_alphabet_pkey PRIMARY KEY (id);


--
-- Name: gematriacore_gematriamethod gematriacore_gematriamethod_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_gematriamethod
    ADD CONSTRAINT gematriacore_gematriamethod_pkey PRIMARY KEY (id);


--
-- Name: gematriacore_gematriamethodletterrule gematriacore_gematriamethodletterrule_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_gematriamethodletterrule
    ADD CONSTRAINT gematriacore_gematriamethodletterrule_pkey PRIMARY KEY (id);


--
-- Name: gematriacore_letter_meanings gematriacore_letter_mean_letter_id_lettermeaning__4feed48f_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_letter_meanings
    ADD CONSTRAINT gematriacore_letter_mean_letter_id_lettermeaning__4feed48f_uniq UNIQUE (letter_id, lettermeaning_id);


--
-- Name: gematriacore_letter_meanings gematriacore_letter_meanings_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_letter_meanings
    ADD CONSTRAINT gematriacore_letter_meanings_pkey PRIMARY KEY (id);


--
-- Name: gematriacore_letter gematriacore_letter_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_letter
    ADD CONSTRAINT gematriacore_letter_pkey PRIMARY KEY (id);


--
-- Name: gematriacore_lettermeaning gematriacore_lettermeaning_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_lettermeaning
    ADD CONSTRAINT gematriacore_lettermeaning_pkey PRIMARY KEY (id);


--
-- Name: gematriacore_letterpower gematriacore_letterpower_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_letterpower
    ADD CONSTRAINT gematriacore_letterpower_pkey PRIMARY KEY (id);


--
-- Name: gematriacore_word gematriacore_word_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_word
    ADD CONSTRAINT gematriacore_word_pkey PRIMARY KEY (id);


--
-- Name: gematriacore_wordmeaning gematriacore_wordmeaning_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_wordmeaning
    ADD CONSTRAINT gematriacore_wordmeaning_pkey PRIMARY KEY (id);


--
-- Name: gematriacore_wordvalue gematriacore_wordvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_wordvalue
    ADD CONSTRAINT gematriacore_wordvalue_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_provider_uid_fc810c6e_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_provider_uid_fc810c6e_uniq UNIQUE (provider, uid);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq UNIQUE (socialapp_id, site_id);


--
-- Name: socialaccount_socialapp socialaccount_socialapp_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp
    ADD CONSTRAINT socialaccount_socialapp_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp_sites_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq UNIQUE (app_id, account_id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_user_id_group_id_b88eab82_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_group_id_b88eab82_uniq UNIQUE (user_id, group_id);


--
-- Name: users_user users_user_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_permission_id_43338c45_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_permission_id_43338c45_uniq UNIQUE (user_id, permission_id);


--
-- Name: users_user users_user_username_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_username_key UNIQUE (username);


--
-- Name: account_emailaddress_email_03be32b2_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX account_emailaddress_email_03be32b2_like ON public.account_emailaddress USING btree (email varchar_pattern_ops);


--
-- Name: account_emailaddress_user_id_2c513194; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX account_emailaddress_user_id_2c513194 ON public.account_emailaddress USING btree (user_id);


--
-- Name: account_emailconfirmation_email_address_id_5b7f8c58; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX account_emailconfirmation_email_address_id_5b7f8c58 ON public.account_emailconfirmation USING btree (email_address_id);


--
-- Name: account_emailconfirmation_key_f43612bd_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX account_emailconfirmation_key_f43612bd_like ON public.account_emailconfirmation USING btree (key varchar_pattern_ops);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_site_domain_a2e37b91_like ON public.django_site USING btree (domain varchar_pattern_ops);


--
-- Name: gematriacore_alphabet_language_id_de0b0f88; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_alphabet_language_id_de0b0f88 ON public.gematriacore_alphabet USING btree (language_id);


--
-- Name: gematriacore_gematriametho_gematria_method_id_f14ce4da; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_gematriametho_gematria_method_id_f14ce4da ON public.gematriacore_gematriamethodletterrule USING btree (gematria_method_id);


--
-- Name: gematriacore_gematriamethod_alphabet_id_21f3304b; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_gematriamethod_alphabet_id_21f3304b ON public.gematriacore_gematriamethod USING btree (alphabet_id);


--
-- Name: gematriacore_gematriamethod_language_id_7f8b8b7a; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_gematriamethod_language_id_7f8b8b7a ON public.gematriacore_gematriamethod USING btree (language_id);


--
-- Name: gematriacore_gematriamethodletterrule_letter_id_a01dae03; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_gematriamethodletterrule_letter_id_a01dae03 ON public.gematriacore_gematriamethodletterrule USING btree (letter_id);


--
-- Name: gematriacore_letter_alphabet_id_63f756c8; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_letter_alphabet_id_63f756c8 ON public.gematriacore_letter USING btree (alphabet_id);


--
-- Name: gematriacore_letter_meanings_letter_id_fdcc5b0c; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_letter_meanings_letter_id_fdcc5b0c ON public.gematriacore_letter_meanings USING btree (letter_id);


--
-- Name: gematriacore_letter_meanings_lettermeaning_id_2a43406d; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_letter_meanings_lettermeaning_id_2a43406d ON public.gematriacore_letter_meanings USING btree (lettermeaning_id);


--
-- Name: gematriacore_letterpower_letter_id_3ddae067; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_letterpower_letter_id_3ddae067 ON public.gematriacore_letterpower USING btree (letter_id);


--
-- Name: gematriacore_word_language_id_e311a704; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_word_language_id_e311a704 ON public.gematriacore_word USING btree (language_id);


--
-- Name: gematriacore_wordmeaning_word_id_bec07de9; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_wordmeaning_word_id_bec07de9 ON public.gematriacore_wordmeaning USING btree (word_id);


--
-- Name: gematriacore_wordvalue_gematria_method_id_dab8249f; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_wordvalue_gematria_method_id_dab8249f ON public.gematriacore_wordvalue USING btree (gematria_method_id);


--
-- Name: gematriacore_wordvalue_word_id_8ae7f96d; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_wordvalue_word_id_8ae7f96d ON public.gematriacore_wordvalue USING btree (word_id);


--
-- Name: socialaccount_socialaccount_user_id_8146e70c; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX socialaccount_socialaccount_user_id_8146e70c ON public.socialaccount_socialaccount USING btree (user_id);


--
-- Name: socialaccount_socialapp_sites_site_id_2579dee5; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX socialaccount_socialapp_sites_site_id_2579dee5 ON public.socialaccount_socialapp_sites USING btree (site_id);


--
-- Name: socialaccount_socialapp_sites_socialapp_id_97fb6e7d; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX socialaccount_socialapp_sites_socialapp_id_97fb6e7d ON public.socialaccount_socialapp_sites USING btree (socialapp_id);


--
-- Name: socialaccount_socialtoken_account_id_951f210e; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX socialaccount_socialtoken_account_id_951f210e ON public.socialaccount_socialtoken USING btree (account_id);


--
-- Name: socialaccount_socialtoken_app_id_636a42d7; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX socialaccount_socialtoken_app_id_636a42d7 ON public.socialaccount_socialtoken USING btree (app_id);


--
-- Name: users_user_groups_group_id_9afc8d0e; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_user_groups_group_id_9afc8d0e ON public.users_user_groups USING btree (group_id);


--
-- Name: users_user_groups_user_id_5f6f5a90; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_user_groups_user_id_5f6f5a90 ON public.users_user_groups USING btree (user_id);


--
-- Name: users_user_user_permissions_permission_id_0b93982e; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_user_user_permissions_permission_id_0b93982e ON public.users_user_user_permissions USING btree (permission_id);


--
-- Name: users_user_user_permissions_user_id_20aca447; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_user_user_permissions_user_id_20aca447 ON public.users_user_user_permissions USING btree (user_id);


--
-- Name: users_user_username_06e46fe6_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_user_username_06e46fe6_like ON public.users_user USING btree (username varchar_pattern_ops);


--
-- Name: account_emailaddress account_emailaddress_user_id_2c513194_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_user_id_2c513194_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_emailconfirmation account_emailconfirm_email_address_id_5b7f8c58_fk_account_e; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirm_email_address_id_5b7f8c58_fk_account_e FOREIGN KEY (email_address_id) REFERENCES public.account_emailaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gematriacore_gematriamethod gematriacore_gematri_alphabet_id_21f3304b_fk_gematriac; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_gematriamethod
    ADD CONSTRAINT gematriacore_gematri_alphabet_id_21f3304b_fk_gematriac FOREIGN KEY (alphabet_id) REFERENCES public.gematriacore_alphabet(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gematriacore_gematriamethodletterrule gematriacore_gematri_gematria_method_id_f14ce4da_fk_gematriac; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_gematriamethodletterrule
    ADD CONSTRAINT gematriacore_gematri_gematria_method_id_f14ce4da_fk_gematriac FOREIGN KEY (gematria_method_id) REFERENCES public.gematriacore_gematriamethod(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gematriacore_gematriamethodletterrule gematriacore_gematri_letter_id_a01dae03_fk_gematriac; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_gematriamethodletterrule
    ADD CONSTRAINT gematriacore_gematri_letter_id_a01dae03_fk_gematriac FOREIGN KEY (letter_id) REFERENCES public.gematriacore_letter(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gematriacore_letter_meanings gematriacore_letter__letter_id_fdcc5b0c_fk_gematriac; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_letter_meanings
    ADD CONSTRAINT gematriacore_letter__letter_id_fdcc5b0c_fk_gematriac FOREIGN KEY (letter_id) REFERENCES public.gematriacore_letter(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gematriacore_letter_meanings gematriacore_letter__lettermeaning_id_2a43406d_fk_gematriac; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_letter_meanings
    ADD CONSTRAINT gematriacore_letter__lettermeaning_id_2a43406d_fk_gematriac FOREIGN KEY (lettermeaning_id) REFERENCES public.gematriacore_lettermeaning(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gematriacore_letter gematriacore_letter_alphabet_id_63f756c8_fk_gematriac; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_letter
    ADD CONSTRAINT gematriacore_letter_alphabet_id_63f756c8_fk_gematriac FOREIGN KEY (alphabet_id) REFERENCES public.gematriacore_alphabet(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gematriacore_letterpower gematriacore_letterp_letter_id_3ddae067_fk_gematriac; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_letterpower
    ADD CONSTRAINT gematriacore_letterp_letter_id_3ddae067_fk_gematriac FOREIGN KEY (letter_id) REFERENCES public.gematriacore_letter(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gematriacore_wordmeaning gematriacore_wordmea_word_id_bec07de9_fk_gematriac; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_wordmeaning
    ADD CONSTRAINT gematriacore_wordmea_word_id_bec07de9_fk_gematriac FOREIGN KEY (word_id) REFERENCES public.gematriacore_word(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gematriacore_wordvalue gematriacore_wordval_gematria_method_id_dab8249f_fk_gematriac; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_wordvalue
    ADD CONSTRAINT gematriacore_wordval_gematria_method_id_dab8249f_fk_gematriac FOREIGN KEY (gematria_method_id) REFERENCES public.gematriacore_gematriamethod(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gematriacore_wordvalue gematriacore_wordvalue_word_id_8ae7f96d_fk_gematriacore_word_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_wordvalue
    ADD CONSTRAINT gematriacore_wordvalue_word_id_8ae7f96d_fk_gematriacore_word_id FOREIGN KEY (word_id) REFERENCES public.gematriacore_word(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_account_id_951f210e_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_account_id_951f210e_fk_socialacc FOREIGN KEY (account_id) REFERENCES public.socialaccount_socialaccount(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_app_id_636a42d7_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_app_id_636a42d7_fk_socialacc FOREIGN KEY (app_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_site_id_2579dee5_fk_django_si; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_site_id_2579dee5_fk_django_si FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc FOREIGN KEY (socialapp_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_user_id_8146e70c_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_user_id_8146e70c_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_group_id_9afc8d0e_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_group_id_9afc8d0e_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_user_id_5f6f5a90_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_5f6f5a90_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_perm_permission_id_0b93982e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_perm_permission_id_0b93982e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_20aca447_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_20aca447_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

