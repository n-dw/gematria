--
-- PostgreSQL database dump
--

-- Dumped from database version 10.5 (Debian 10.5-2.pgdg90+1)
-- Dumped by pg_dump version 10.5 (Debian 10.5-2.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: account_emailaddress; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.account_emailaddress (
    id integer NOT NULL,
    email character varying(254) NOT NULL,
    verified boolean NOT NULL,
    "primary" boolean NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.account_emailaddress OWNER TO debug;

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.account_emailaddress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailaddress_id_seq OWNER TO debug;

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.account_emailaddress_id_seq OWNED BY public.account_emailaddress.id;


--
-- Name: account_emailconfirmation; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.account_emailconfirmation (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    sent timestamp with time zone,
    key character varying(64) NOT NULL,
    email_address_id integer NOT NULL
);


ALTER TABLE public.account_emailconfirmation OWNER TO debug;

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.account_emailconfirmation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailconfirmation_id_seq OWNER TO debug;

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.account_emailconfirmation_id_seq OWNED BY public.account_emailconfirmation.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO debug;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO debug;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO debug;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO debug;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO debug;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO debug;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO debug;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO debug;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO debug;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO debug;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO debug;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO debug;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO debug;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO debug;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.django_site_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO debug;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.django_site_id_seq OWNED BY public.django_site.id;


--
-- Name: gematriacore_alphabet; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.gematriacore_alphabet (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    title character varying(200) NOT NULL,
    language_id integer
);


ALTER TABLE public.gematriacore_alphabet OWNER TO debug;

--
-- Name: gematriacore_alphabet_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.gematriacore_alphabet_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gematriacore_alphabet_id_seq OWNER TO debug;

--
-- Name: gematriacore_alphabet_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.gematriacore_alphabet_id_seq OWNED BY public.gematriacore_alphabet.id;


--
-- Name: gematriacore_gematriamethod; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.gematriacore_gematriamethod (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    title character varying(200) NOT NULL,
    alphabet_id integer,
    language_id integer
);


ALTER TABLE public.gematriacore_gematriamethod OWNER TO debug;

--
-- Name: gematriacore_gematriamethod_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.gematriacore_gematriamethod_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gematriacore_gematriamethod_id_seq OWNER TO debug;

--
-- Name: gematriacore_gematriamethod_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.gematriacore_gematriamethod_id_seq OWNED BY public.gematriacore_gematriamethod.id;


--
-- Name: gematriacore_gematriamethodletterrule; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.gematriacore_gematriamethodletterrule (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    numerical_value double precision NOT NULL,
    letter_id integer,
    gematria_method_id integer
);


ALTER TABLE public.gematriacore_gematriamethodletterrule OWNER TO debug;

--
-- Name: gematriacore_gematriamethodletterrule_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.gematriacore_gematriamethodletterrule_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gematriacore_gematriamethodletterrule_id_seq OWNER TO debug;

--
-- Name: gematriacore_gematriamethodletterrule_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.gematriacore_gematriamethodletterrule_id_seq OWNED BY public.gematriacore_gematriamethodletterrule.id;


--
-- Name: gematriacore_language; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.gematriacore_language (
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    title character varying(200) NOT NULL,
    uuid uuid NOT NULL
);


ALTER TABLE public.gematriacore_language OWNER TO debug;

--
-- Name: gematriacore_letter; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.gematriacore_letter (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    title character varying(200) NOT NULL,
    "character" character varying(1) NOT NULL,
    alphabet_id integer,
    letter_order integer
);


ALTER TABLE public.gematriacore_letter OWNER TO debug;

--
-- Name: gematriacore_letter_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.gematriacore_letter_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gematriacore_letter_id_seq OWNER TO debug;

--
-- Name: gematriacore_letter_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.gematriacore_letter_id_seq OWNED BY public.gematriacore_letter.id;


--
-- Name: gematriacore_letter_meanings; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.gematriacore_letter_meanings (
    id integer NOT NULL,
    letter_id integer NOT NULL,
    lettermeaning_id integer NOT NULL
);


ALTER TABLE public.gematriacore_letter_meanings OWNER TO debug;

--
-- Name: gematriacore_letter_meanings_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.gematriacore_letter_meanings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gematriacore_letter_meanings_id_seq OWNER TO debug;

--
-- Name: gematriacore_letter_meanings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.gematriacore_letter_meanings_id_seq OWNED BY public.gematriacore_letter_meanings.id;


--
-- Name: gematriacore_lettermeaning; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.gematriacore_lettermeaning (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    meaning character varying(200) NOT NULL,
    is_active boolean
);


ALTER TABLE public.gematriacore_lettermeaning OWNER TO debug;

--
-- Name: gematriacore_lettermeaning_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.gematriacore_lettermeaning_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gematriacore_lettermeaning_id_seq OWNER TO debug;

--
-- Name: gematriacore_lettermeaning_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.gematriacore_lettermeaning_id_seq OWNED BY public.gematriacore_lettermeaning.id;


--
-- Name: gematriacore_letterpower; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.gematriacore_letterpower (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    power character varying(20) NOT NULL,
    is_active boolean,
    letter_id integer
);


ALTER TABLE public.gematriacore_letterpower OWNER TO debug;

--
-- Name: gematriacore_letterpower_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.gematriacore_letterpower_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gematriacore_letterpower_id_seq OWNER TO debug;

--
-- Name: gematriacore_letterpower_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.gematriacore_letterpower_id_seq OWNED BY public.gematriacore_letterpower.id;


--
-- Name: gematriacore_word; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.gematriacore_word (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    name_english character varying(200) NOT NULL,
    name_original_language character varying(200) NOT NULL,
    language_id integer
);


ALTER TABLE public.gematriacore_word OWNER TO debug;

--
-- Name: gematriacore_word_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.gematriacore_word_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gematriacore_word_id_seq OWNER TO debug;

--
-- Name: gematriacore_word_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.gematriacore_word_id_seq OWNED BY public.gematriacore_word.id;


--
-- Name: gematriacore_wordmeaning; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.gematriacore_wordmeaning (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    meaning character varying(200) NOT NULL,
    is_active boolean,
    word_id integer
);


ALTER TABLE public.gematriacore_wordmeaning OWNER TO debug;

--
-- Name: gematriacore_wordmeaning_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.gematriacore_wordmeaning_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gematriacore_wordmeaning_id_seq OWNER TO debug;

--
-- Name: gematriacore_wordmeaning_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.gematriacore_wordmeaning_id_seq OWNED BY public.gematriacore_wordmeaning.id;


--
-- Name: gematriacore_wordspelling; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.gematriacore_wordspelling (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    "position" smallint NOT NULL,
    letter_id integer,
    word_id integer,
    CONSTRAINT gematriacore_wordspelling_position_check CHECK (("position" >= 0))
);


ALTER TABLE public.gematriacore_wordspelling OWNER TO debug;

--
-- Name: gematriacore_wordspelling_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.gematriacore_wordspelling_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gematriacore_wordspelling_id_seq OWNER TO debug;

--
-- Name: gematriacore_wordspelling_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.gematriacore_wordspelling_id_seq OWNED BY public.gematriacore_wordspelling.id;


--
-- Name: gematriacore_wordvalue; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.gematriacore_wordvalue (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    modified timestamp with time zone NOT NULL,
    value double precision,
    gematria_method_id integer,
    word_id integer
);


ALTER TABLE public.gematriacore_wordvalue OWNER TO debug;

--
-- Name: gematriacore_wordvalue_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.gematriacore_wordvalue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gematriacore_wordvalue_id_seq OWNER TO debug;

--
-- Name: gematriacore_wordvalue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.gematriacore_wordvalue_id_seq OWNED BY public.gematriacore_wordvalue.id;


--
-- Name: socialaccount_socialaccount; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.socialaccount_socialaccount (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    uid character varying(191) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    extra_data text NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialaccount OWNER TO debug;

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.socialaccount_socialaccount_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialaccount_id_seq OWNER TO debug;

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.socialaccount_socialaccount_id_seq OWNED BY public.socialaccount_socialaccount.id;


--
-- Name: socialaccount_socialapp; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.socialaccount_socialapp (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    name character varying(40) NOT NULL,
    client_id character varying(191) NOT NULL,
    secret character varying(191) NOT NULL,
    key character varying(191) NOT NULL
);


ALTER TABLE public.socialaccount_socialapp OWNER TO debug;

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.socialaccount_socialapp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialapp_id_seq OWNER TO debug;

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.socialaccount_socialapp_id_seq OWNED BY public.socialaccount_socialapp.id;


--
-- Name: socialaccount_socialapp_sites; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.socialaccount_socialapp_sites (
    id integer NOT NULL,
    socialapp_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialapp_sites OWNER TO debug;

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.socialaccount_socialapp_sites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialapp_sites_id_seq OWNER TO debug;

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.socialaccount_socialapp_sites_id_seq OWNED BY public.socialaccount_socialapp_sites.id;


--
-- Name: socialaccount_socialtoken; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.socialaccount_socialtoken (
    id integer NOT NULL,
    token text NOT NULL,
    token_secret text NOT NULL,
    expires_at timestamp with time zone,
    account_id integer NOT NULL,
    app_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialtoken OWNER TO debug;

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.socialaccount_socialtoken_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialtoken_id_seq OWNER TO debug;

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.socialaccount_socialtoken_id_seq OWNED BY public.socialaccount_socialtoken.id;


--
-- Name: users_user; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.users_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.users_user OWNER TO debug;

--
-- Name: users_user_groups; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.users_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.users_user_groups OWNER TO debug;

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.users_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_groups_id_seq OWNER TO debug;

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.users_user_groups_id_seq OWNED BY public.users_user_groups.id;


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_id_seq OWNER TO debug;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users_user.id;


--
-- Name: users_user_user_permissions; Type: TABLE; Schema: public; Owner: debug
--

CREATE TABLE public.users_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.users_user_user_permissions OWNER TO debug;

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: debug
--

CREATE SEQUENCE public.users_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_user_user_permissions_id_seq OWNER TO debug;

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: debug
--

ALTER SEQUENCE public.users_user_user_permissions_id_seq OWNED BY public.users_user_user_permissions.id;


--
-- Name: account_emailaddress id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailaddress ALTER COLUMN id SET DEFAULT nextval('public.account_emailaddress_id_seq'::regclass);


--
-- Name: account_emailconfirmation id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailconfirmation ALTER COLUMN id SET DEFAULT nextval('public.account_emailconfirmation_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: django_site id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_site ALTER COLUMN id SET DEFAULT nextval('public.django_site_id_seq'::regclass);


--
-- Name: gematriacore_alphabet id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_alphabet ALTER COLUMN id SET DEFAULT nextval('public.gematriacore_alphabet_id_seq'::regclass);


--
-- Name: gematriacore_gematriamethod id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_gematriamethod ALTER COLUMN id SET DEFAULT nextval('public.gematriacore_gematriamethod_id_seq'::regclass);


--
-- Name: gematriacore_gematriamethodletterrule id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_gematriamethodletterrule ALTER COLUMN id SET DEFAULT nextval('public.gematriacore_gematriamethodletterrule_id_seq'::regclass);


--
-- Name: gematriacore_letter id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_letter ALTER COLUMN id SET DEFAULT nextval('public.gematriacore_letter_id_seq'::regclass);


--
-- Name: gematriacore_letter_meanings id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_letter_meanings ALTER COLUMN id SET DEFAULT nextval('public.gematriacore_letter_meanings_id_seq'::regclass);


--
-- Name: gematriacore_lettermeaning id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_lettermeaning ALTER COLUMN id SET DEFAULT nextval('public.gematriacore_lettermeaning_id_seq'::regclass);


--
-- Name: gematriacore_letterpower id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_letterpower ALTER COLUMN id SET DEFAULT nextval('public.gematriacore_letterpower_id_seq'::regclass);


--
-- Name: gematriacore_word id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_word ALTER COLUMN id SET DEFAULT nextval('public.gematriacore_word_id_seq'::regclass);


--
-- Name: gematriacore_wordmeaning id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_wordmeaning ALTER COLUMN id SET DEFAULT nextval('public.gematriacore_wordmeaning_id_seq'::regclass);


--
-- Name: gematriacore_wordspelling id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_wordspelling ALTER COLUMN id SET DEFAULT nextval('public.gematriacore_wordspelling_id_seq'::regclass);


--
-- Name: gematriacore_wordvalue id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_wordvalue ALTER COLUMN id SET DEFAULT nextval('public.gematriacore_wordvalue_id_seq'::regclass);


--
-- Name: socialaccount_socialaccount id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialaccount ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialaccount_id_seq'::regclass);


--
-- Name: socialaccount_socialapp id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialapp_id_seq'::regclass);


--
-- Name: socialaccount_socialapp_sites id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialapp_sites_id_seq'::regclass);


--
-- Name: socialaccount_socialtoken id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialtoken ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialtoken_id_seq'::regclass);


--
-- Name: users_user id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user ALTER COLUMN id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Name: users_user_groups id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_groups ALTER COLUMN id SET DEFAULT nextval('public.users_user_groups_id_seq'::regclass);


--
-- Name: users_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.users_user_user_permissions_id_seq'::regclass);


--
-- Data for Name: account_emailaddress; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.account_emailaddress (id, email, verified, "primary", user_id) FROM stdin;
1	ndewaard@protonmail.com	f	f	1
\.


--
-- Data for Name: account_emailconfirmation; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.account_emailconfirmation (id, created, sent, key, email_address_id) FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add permission	1	add_permission
2	Can change permission	1	change_permission
3	Can delete permission	1	delete_permission
4	Can add group	2	add_group
5	Can change group	2	change_group
6	Can delete group	2	delete_group
7	Can add content type	3	add_contenttype
8	Can change content type	3	change_contenttype
9	Can delete content type	3	delete_contenttype
10	Can add session	4	add_session
11	Can change session	4	change_session
12	Can delete session	4	delete_session
13	Can add site	5	add_site
14	Can change site	5	change_site
15	Can delete site	5	delete_site
16	Can add log entry	6	add_logentry
17	Can change log entry	6	change_logentry
18	Can delete log entry	6	delete_logentry
19	Can add email address	7	add_emailaddress
20	Can change email address	7	change_emailaddress
21	Can delete email address	7	delete_emailaddress
22	Can add email confirmation	8	add_emailconfirmation
23	Can change email confirmation	8	change_emailconfirmation
24	Can delete email confirmation	8	delete_emailconfirmation
25	Can add social account	9	add_socialaccount
26	Can change social account	9	change_socialaccount
27	Can delete social account	9	delete_socialaccount
28	Can add social application	10	add_socialapp
29	Can change social application	10	change_socialapp
30	Can delete social application	10	delete_socialapp
31	Can add social application token	11	add_socialtoken
32	Can change social application token	11	change_socialtoken
33	Can delete social application token	11	delete_socialtoken
34	Can add user	12	add_user
35	Can change user	12	change_user
36	Can delete user	12	delete_user
37	Can add letter power	13	add_letterpower
38	Can change letter power	13	change_letterpower
39	Can delete letter power	13	delete_letterpower
40	Can add letter	14	add_letter
41	Can change letter	14	change_letter
42	Can delete letter	14	delete_letter
43	Can add alphabet	15	add_alphabet
44	Can change alphabet	15	change_alphabet
45	Can delete alphabet	15	delete_alphabet
46	Can add language	16	add_language
47	Can change language	16	change_language
48	Can delete language	16	delete_language
49	Can add dictionary	17	add_dictionary
50	Can change dictionary	17	change_dictionary
51	Can delete dictionary	17	delete_dictionary
52	Can add word	18	add_word
53	Can change word	18	change_word
54	Can delete word	18	delete_word
55	Can add gematria method letter rule	19	add_gematriamethodletterrule
56	Can change gematria method letter rule	19	change_gematriamethodletterrule
57	Can delete gematria method letter rule	19	delete_gematriamethodletterrule
58	Can add word meaning	20	add_wordmeaning
59	Can change word meaning	20	change_wordmeaning
60	Can delete word meaning	20	delete_wordmeaning
61	Can add gematria method	21	add_gematriamethod
62	Can change gematria method	21	change_gematriamethod
63	Can delete gematria method	21	delete_gematriamethod
64	Can add letter meaning	22	add_lettermeaning
65	Can change letter meaning	22	change_lettermeaning
66	Can delete letter meaning	22	delete_lettermeaning
67	Can add word spelling	23	add_wordspelling
68	Can change word spelling	23	change_wordspelling
69	Can delete word spelling	23	delete_wordspelling
70	Can add word value	24	add_wordvalue
71	Can change word value	24	change_wordvalue
72	Can delete word value	24	delete_wordvalue
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2019-03-21 17:51:50.833081+00	1	Language object (1)	1	[{"added": {}}]	16	1
2	2019-03-21 17:52:11.27218+00	1	Alphabet object (1)	1	[{"added": {}}]	15	1
3	2019-03-21 18:05:59.559828+00	1	LetterPower object (1)	1	[{"added": {}}]	13	1
4	2019-03-21 18:06:12.096743+00	1	LetterMeaning object (1)	1	[{"added": {}}]	22	1
5	2019-03-21 18:12:13.145404+00	5	Aleph - Lang: gematriacore.Alphabet.None	1	[{"added": {}}]	14	1
6	2019-03-21 18:12:32.116893+00	5	Aleph - Lang: gematriacore.Alphabet.None	2	[]	14	1
7	2019-03-21 18:24:49.074799+00	5	Aleph: א -- Lang: gematriacore.Alphabet.None	2	[]	14	1
8	2019-03-21 18:26:48.898693+00	5	Aleph: א -- Lang: Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["alphabet"]}}]	14	1
9	2019-03-21 18:30:06.566821+00	6	Beth: ב Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
10	2019-03-21 18:30:47.304239+00	2	G - Active: True	1	[{"added": {}}]	13	1
11	2019-03-21 18:30:55.732495+00	3	Gh - Active: False	1	[{"added": {}}]	13	1
12	2019-03-21 18:31:10.359584+00	2	Camel - Active: True	1	[{"added": {}}]	22	1
13	2019-03-21 18:31:31.935649+00	7	Gimel: ג Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
14	2019-03-21 18:31:43.25549+00	4	B - Active: True	1	[{"added": {}}]	13	1
15	2019-03-21 18:31:49.469379+00	5	V - Active: False	1	[{"added": {}}]	13	1
16	2019-03-21 18:31:56.514613+00	3	House - Active: True	1	[{"added": {}}]	22	1
17	2019-03-21 18:31:58.8682+00	6	Beth: ב Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["powers", "meanings"]}}]	14	1
18	2019-03-21 18:34:20.485227+00	6	D - Active: True	1	[{"added": {}}]	13	1
19	2019-03-21 18:34:28.007566+00	7	Dh - Active: False	1	[{"added": {}}]	13	1
20	2019-03-21 18:34:39.625446+00	4	Door - Active: True	1	[{"added": {}}]	22	1
21	2019-03-21 18:34:47.799536+00	8	Daleth: ד Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
22	2019-03-21 18:35:15.390872+00	8	H - Active: True	1	[{"added": {}}]	13	1
23	2019-03-21 18:35:26.943095+00	5	Window - Active: True	1	[{"added": {}}]	22	1
24	2019-03-21 18:35:34.517853+00	9	He: ה Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
25	2019-03-21 18:40:33.153887+00	1	GematriaMethod object (1)	1	[{"added": {}}]	21	1
26	2019-03-21 18:54:23.895588+00	9	O - Active: True	1	[{"added": {}}]	13	1
27	2019-03-21 18:54:29.364969+00	10	U - Active: False	1	[{"added": {}}]	13	1
28	2019-03-21 18:54:35.161454+00	11	V - Active: False	1	[{"added": {}}]	13	1
29	2019-03-21 18:54:40.355318+00	12	W - Active: False	1	[{"added": {}}]	13	1
30	2019-03-21 18:54:50.552895+00	6	Pin - Active: True	1	[{"added": {}}]	22	1
31	2019-03-21 18:55:14.414762+00	7	Nail - Active: False	1	[{"added": {}}]	22	1
32	2019-03-21 18:55:22.627749+00	10	Vau: <span class="u-language--hebrew">ו</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
33	2019-03-21 18:56:32.906299+00	13	Z - Active: True	1	[{"added": {}}]	13	1
34	2019-03-21 18:56:43.76061+00	8	Sword - Active: True	1	[{"added": {}}]	22	1
35	2019-03-21 18:56:53.046942+00	9	Armour - Active: False	1	[{"added": {}}]	22	1
36	2019-03-21 18:56:59.742558+00	11	Zayin: <span class="u-language--hebrew">ז</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
37	2019-03-21 19:00:02.276085+00	14	Ch - Active: True	1	[{"added": {}}]	13	1
38	2019-03-21 19:00:14.969201+00	10	Fence - Active: True	1	[{"added": {}}]	22	1
39	2019-03-21 19:00:25.406555+00	11	Enclosure - Active: False	1	[{"added": {}}]	22	1
40	2019-03-21 19:00:30.121431+00	12	Chet: <span class="u-language--hebrew">ח</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
41	2019-03-21 19:00:58.548649+00	15	T - Active: True	1	[{"added": {}}]	13	1
42	2019-03-21 19:01:10.029453+00	12	Snake - Active: True	1	[{"added": {}}]	22	1
43	2019-03-21 19:01:14.043345+00	13	Teth: <span class="u-language--hebrew">ט</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
44	2019-03-21 19:01:27.24978+00	16	I - Active: True	1	[{"added": {}}]	13	1
45	2019-03-21 19:01:53.324182+00	17	Y - Active: False	1	[{"added": {}}]	13	1
46	2019-03-21 19:02:02.629109+00	13	Hand - Active: True	1	[{"added": {}}]	22	1
47	2019-03-21 19:02:10.656206+00	14	Palm - Active: True	1	[{"added": {}}]	22	1
48	2019-03-21 19:02:31.362797+00	14	Yod: <span class="u-language--hebrew">י</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
49	2019-03-21 19:03:13.771771+00	18	K - Active: True	1	[{"added": {}}]	13	1
50	2019-03-21 19:03:20.629334+00	19	Kh - Active: False	1	[{"added": {}}]	13	1
51	2019-03-21 19:03:28.730377+00	15	Fist - Active: True	1	[{"added": {}}]	22	1
52	2019-03-21 19:03:40.254509+00	15	Kaph: <span class="u-language--hebrew">כ</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
53	2019-03-21 19:04:12.433964+00	16	Kaph - Final: <span class="u-language--hebrew">ך</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
54	2019-03-21 19:04:34.273794+00	20	L - Active: True	1	[{"added": {}}]	13	1
55	2019-03-21 19:04:59.659055+00	16	Ox Goad - Active: True	1	[{"added": {}}]	22	1
56	2019-03-21 19:05:03.545548+00	17	Lamed: <span class="u-language--hebrew">ל</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
57	2019-03-21 19:05:30.361028+00	21	M - Active: True	1	[{"added": {}}]	13	1
58	2019-03-21 19:05:42.136228+00	17	Water - Active: True	1	[{"added": {}}]	22	1
59	2019-03-21 19:05:46.385174+00	18	Mem: <span class="u-language--hebrew">מ</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
60	2019-03-21 19:06:19.783779+00	19	Mem - Final: <span class="u-language--hebrew">ם</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
61	2019-03-21 19:06:44.032942+00	22	N - Active: True	1	[{"added": {}}]	13	1
62	2019-03-21 19:07:06.613012+00	18	Fish - Active: False	1	[{"added": {}}]	22	1
63	2019-03-21 19:07:09.933235+00	20	Nun: <span class="u-language--hebrew">נ</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
64	2019-03-21 19:07:40.670638+00	21	Nun - Final: <span class="u-language--hebrew">ן</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
65	2019-03-21 19:08:09.896446+00	23	S - Active: True	1	[{"added": {}}]	13	1
66	2019-03-21 19:08:24.380269+00	19	Prop - Active: True	1	[{"added": {}}]	22	1
67	2019-03-21 19:08:35.231007+00	22	Samekh: <span class="u-language--hebrew">ס</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
68	2019-03-21 19:09:04.36724+00	24	Aa - Active: False	1	[{"added": {}}]	13	1
69	2019-03-21 19:09:13.421352+00	20	Eye - Active: True	1	[{"added": {}}]	22	1
70	2019-03-21 19:09:16.626504+00	23	Ayin: <span class="u-language--hebrew">ע</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
71	2019-03-21 19:09:38.95587+00	25	P - Active: True	1	[{"added": {}}]	13	1
72	2019-03-21 19:09:43.940298+00	26	Ph - Active: True	1	[{"added": {}}]	13	1
73	2019-03-21 19:10:08.662123+00	21	Mouth - Active: True	1	[{"added": {}}]	22	1
74	2019-03-21 19:10:13.654434+00	24	Peh: <span class="u-language--hebrew">פ</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
75	2019-03-21 19:10:45.584848+00	25	Peh - Final: <span class="u-language--hebrew">ף</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
76	2019-03-21 19:11:11.591289+00	27	Tz - Active: True	1	[{"added": {}}]	13	1
77	2019-03-21 19:11:26.116474+00	22	Fishhook - Active: True	1	[{"added": {}}]	22	1
78	2019-03-21 19:11:33.729344+00	26	Tzaddi: <span class="u-language--hebrew">צ</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
79	2019-03-21 19:12:09.573596+00	27	Tzaddi - Final: <span class="u-language--hebrew">ץ</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
80	2019-03-21 19:12:31.527523+00	28	Q - Active: True	1	[{"added": {}}]	13	1
81	2019-03-21 19:12:41.844439+00	23	Ear - Active: True	1	[{"added": {}}]	22	1
82	2019-03-21 19:12:49.115823+00	24	Back of Head - Active: False	1	[{"added": {}}]	22	1
83	2019-03-21 19:12:53.140732+00	28	Qoph: <span class="u-language--hebrew">ק</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
84	2019-03-21 19:13:09.333704+00	29	R - Active: True	1	[{"added": {}}]	13	1
85	2019-03-21 19:13:16.01832+00	25	Head - Active: True	1	[{"added": {}}]	22	1
86	2019-03-21 19:13:22.574283+00	26	Face - Active: True	1	[{"added": {}}]	22	1
87	2019-03-21 19:13:46.809062+00	29	Resh: <span class="u-language--hebrew">ר</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
88	2019-03-21 19:14:06.794523+00	30	Sh - Active: False	1	[{"added": {}}]	13	1
89	2019-03-21 19:14:21.697218+00	27	Tooth - Active: True	1	[{"added": {}}]	22	1
90	2019-03-21 19:14:27.297228+00	30	Shin: <span class="u-language--hebrew">ש</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
91	2019-03-21 19:14:52.612806+00	31	Th - Active: False	1	[{"added": {}}]	13	1
92	2019-03-21 19:15:02.574036+00	28	Cross - Active: True	1	[{"added": {}}]	22	1
93	2019-03-21 19:15:07.175745+00	31	Tau: <span class="u-language--hebrew">ת</span> Hebrew - Lang: Hebrew	1	[{"added": {}}]	14	1
94	2019-03-21 20:27:40.007339+00	1	Dictionary object (1)	1	[{"added": {}}]	17	1
95	2019-03-23 15:52:17.348869+00	28	Cross - Active: True	2	[{"changed": {"fields": ["letter"]}}]	22	1
96	2019-03-23 15:53:07.151835+00	27	Tooth - Active: True	2	[{"changed": {"fields": ["letter"]}}]	22	1
97	2019-03-23 16:16:23.05009+00	31	Th - Active: False	2	[{"changed": {"fields": ["letter"]}}]	13	1
98	2019-03-23 16:17:07.587326+00	31	Th - Active: False	3		13	1
99	2019-03-23 16:17:07.599385+00	30	Sh - Active: False	3		13	1
100	2019-03-23 16:17:07.621554+00	29	R - Active: True	3		13	1
101	2019-03-23 16:17:07.633099+00	28	Q - Active: True	3		13	1
102	2019-03-23 16:17:07.660916+00	27	Tz - Active: True	3		13	1
103	2019-03-23 16:17:07.685463+00	26	Ph - Active: True	3		13	1
104	2019-03-23 16:17:07.707616+00	25	P - Active: True	3		13	1
105	2019-03-23 16:17:07.729556+00	24	Aa - Active: False	3		13	1
106	2019-03-23 16:17:07.75065+00	23	S - Active: True	3		13	1
107	2019-03-23 16:17:07.771316+00	22	N - Active: True	3		13	1
108	2019-03-23 16:17:07.79304+00	21	M - Active: True	3		13	1
109	2019-03-23 16:17:07.810612+00	20	L - Active: True	3		13	1
110	2019-03-23 16:17:07.826534+00	19	Kh - Active: False	3		13	1
111	2019-03-23 16:17:07.844618+00	18	K - Active: True	3		13	1
112	2019-03-23 16:17:07.865055+00	17	Y - Active: False	3		13	1
113	2019-03-23 16:17:07.883972+00	16	I - Active: True	3		13	1
114	2019-03-23 16:17:07.902843+00	15	T - Active: True	3		13	1
115	2019-03-23 16:17:07.927457+00	14	Ch - Active: True	3		13	1
116	2019-03-23 16:17:07.94576+00	13	Z - Active: True	3		13	1
117	2019-03-23 16:17:07.962599+00	12	W - Active: False	3		13	1
118	2019-03-23 16:17:07.977333+00	11	V - Active: False	3		13	1
119	2019-03-23 16:17:07.994871+00	10	U - Active: False	3		13	1
120	2019-03-23 16:17:08.009873+00	9	O - Active: True	3		13	1
121	2019-03-23 16:17:08.025756+00	8	H - Active: True	3		13	1
122	2019-03-23 16:17:08.040516+00	7	Dh - Active: False	3		13	1
123	2019-03-23 16:17:08.055558+00	6	D - Active: True	3		13	1
124	2019-03-23 16:17:08.067647+00	5	V - Active: False	3		13	1
125	2019-03-23 16:17:08.082951+00	4	B - Active: True	3		13	1
126	2019-03-23 16:17:08.098497+00	3	Gh - Active: False	3		13	1
127	2019-03-23 16:17:08.114686+00	2	G - Active: True	3		13	1
128	2019-03-23 16:17:08.129043+00	1	A - Active: True	3		13	1
129	2019-03-23 16:17:46.654627+00	31	Tau: ת Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "T - Active: True"}}, {"added": {"name": "letter power", "object": "Th - Active: False"}}]	14	1
130	2019-03-23 16:19:56.549149+00	30	Shin: ש Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "S - Shin: \\u05e9 Hebrew - Lang: Hebrew Active: True"}}, {"added": {"name": "letter power", "object": "Sh - Shin: \\u05e9 Hebrew - Lang: Hebrew Active: False"}}]	14	1
131	2019-03-23 16:20:30.901355+00	29	Resh: ר Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "R - Resh: \\u05e8 Hebrew - Lang: Hebrew Active: True"}}]	14	1
132	2019-03-23 16:22:28.494457+00	28	Qoph: ק Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "Q - Qoph: \\u05e7 Hebrew - Lang: Hebrew Active: True"}}]	14	1
133	2019-03-23 16:23:07.498045+00	27	Tzaddi - Final: ץ Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "Tz - Tzaddi - Final: \\u05e5 Hebrew - Lang: Hebrew Active: True"}}]	14	1
134	2019-03-23 16:23:29.06357+00	26	Tzaddi: צ Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "Tz - Tzaddi: \\u05e6 Hebrew - Lang: Hebrew Active: True"}}]	14	1
135	2019-03-23 16:24:07.809032+00	25	Peh - Final: ף Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "P - Peh - Final: \\u05e3 Hebrew - Lang: Hebrew Active: True"}}, {"added": {"name": "letter power", "object": "Ph - Peh - Final: \\u05e3 Hebrew - Lang: Hebrew Active: False"}}]	14	1
136	2019-03-23 16:24:29.408444+00	24	Peh: פ Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "P - Peh: \\u05e4 Hebrew - Lang: Hebrew Active: True"}}, {"added": {"name": "letter power", "object": "Ph - Peh: \\u05e4 Hebrew - Lang: Hebrew Active: False"}}]	14	1
137	2019-03-23 16:24:48.814089+00	23	Ayin: ע Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "Aa - Ayin: \\u05e2 Hebrew - Lang: Hebrew Active: True"}}, {"added": {"name": "letter power", "object": "O - Ayin: \\u05e2 Hebrew - Lang: Hebrew Active: False"}}]	14	1
138	2019-03-23 16:25:10.896024+00	22	Samekh: ס Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "S - Samekh: \\u05e1 Hebrew - Lang: Hebrew Active: True"}}]	14	1
139	2019-03-23 16:25:29.742684+00	21	Nun - Final: ן Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "N - Nun - Final: \\u05df Hebrew - Lang: Hebrew Active: True"}}]	14	1
140	2019-03-23 16:25:45.401112+00	20	Nun: נ Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "N - Nun: \\u05e0 Hebrew - Lang: Hebrew Active: True"}}]	14	1
141	2019-03-23 16:26:43.414177+00	1	GematriaMethodLetterRule object (1)	1	[{"added": {}}]	19	1
142	2019-03-23 16:31:36.604409+00	1	Simple	2	[{"added": {"name": "gematria method letter rule", "object": "Aleph: \\u05d0 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Beth: \\u05d1 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Gimel: \\u05d2 Hebrew - Lang: Hebrew - Method: Simple"}}]	21	1
143	2019-03-23 16:33:18.531599+00	1	Simple	2	[]	21	1
144	2019-03-23 16:37:31.725314+00	1	Simple	2	[{"added": {"name": "gematria method letter rule", "object": "Daleth: \\u05d3 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "He: \\u05d4 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Vau: \\u05d5 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Zayin: \\u05d6 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Chet: \\u05d7 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Teth: \\u05d8 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Yod: \\u05d9 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Kaph: \\u05db Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Kaph - Final: \\u05da Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Lamed: \\u05dc Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Mem: \\u05de Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Mem - Final: \\u05dd Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Nun: \\u05e0 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Nun - Final: \\u05df Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Samekh: \\u05e1 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Ayin: \\u05e2 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Peh: \\u05e4 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Peh - Final: \\u05e3 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Tzaddi: \\u05e6 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Tzaddi - Final: \\u05e5 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Qoph: \\u05e7 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Resh: \\u05e8 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Shin: \\u05e9 Hebrew - Lang: Hebrew - Method: Simple"}}, {"added": {"name": "gematria method letter rule", "object": "Tau: \\u05ea Hebrew - Lang: Hebrew - Method: Simple"}}]	21	1
145	2019-03-23 16:39:56.737529+00	5	Aleph: א Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["letter_order"]}}]	14	1
146	2019-03-23 16:40:10.276211+00	6	Beth: ב Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["letter_order"]}}]	14	1
147	2019-03-23 16:40:45.066491+00	6	Beth: ב Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}, {"added": {"name": "letter power", "object": "B - Beth: \\u05d1 Hebrew - Lang: Hebrew Active: True"}}, {"added": {"name": "letter power", "object": "V - Beth: \\u05d1 Hebrew - Lang: Hebrew Active: False"}}]	14	1
148	2019-03-23 16:42:56.794762+00	2	Regular	1	[{"added": {}}]	21	1
149	2019-03-23 16:49:54.438797+00	2	Regular	2	[{"added": {"name": "gematria method letter rule", "object": "Aleph: \\u05d0 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Beth: \\u05d1 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Gimel: \\u05d2 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Daleth: \\u05d3 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "He: \\u05d4 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Vau: \\u05d5 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Zayin: \\u05d6 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Chet: \\u05d7 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Teth: \\u05d8 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Yod: \\u05d9 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Kaph: \\u05db Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Kaph - Final: \\u05da Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Lamed: \\u05dc Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Mem: \\u05de Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Mem - Final: \\u05dd Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Nun: \\u05e0 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Nun - Final: \\u05df Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Samekh: \\u05e1 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Ayin: \\u05e2 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Peh: \\u05e4 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Peh - Final: \\u05e3 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Tzaddi: \\u05e6 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Tzaddi - Final: \\u05e5 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Qoph: \\u05e7 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Resh: \\u05e8 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Shin: \\u05e9 Hebrew - Lang: Hebrew - Method: Regular"}}, {"added": {"name": "gematria method letter rule", "object": "Tau: \\u05ea Hebrew - Lang: Hebrew - Method: Regular"}}]	21	1
150	2019-03-23 16:55:45.85891+00	1	Word object (1)	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "WordMeaning object (1)"}}]	18	1
151	2019-03-30 19:43:32.057107+00	2	Jehovah - יהוה	1	[{"added": {}}, {"added": {"name": "word meaning", "object": "WordMeaning object (2)"}}]	18	1
152	2019-03-30 20:07:54.407092+00	2	Jehovah - יהוה	2	[{"added": {"name": "word spelling", "object": "WordSpelling object (1)"}}, {"added": {"name": "word spelling", "object": "WordSpelling object (2)"}}, {"added": {"name": "word spelling", "object": "WordSpelling object (3)"}}, {"added": {"name": "word spelling", "object": "WordSpelling object (4)"}}]	18	1
153	2019-03-30 22:00:39.77382+00	2	Jehovah - יהוה	2	[]	18	1
154	2019-12-02 16:01:45.051548+00	2	English	1	[{"added": {}}]	16	1
155	2019-12-02 16:02:02.212206+00	1	Hebrew - Lang: Hebrew	2	[]	15	1
156	2019-12-02 16:02:34.195395+00	2	English - Lang: English	1	[{"added": {}}]	15	1
157	2019-12-02 16:51:28.319641+00	2	English - Lang: English	2	[{"changed": {"fields": ["characters"]}}]	15	1
158	2019-12-02 17:08:52.872584+00	5	Aleph: א Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["meanings"]}}]	14	1
159	2019-12-02 17:30:21.812764+00	1	Jehovah - יהוה - 26.0 : Simple	1	[{"added": {}}]	24	1
160	2019-12-02 17:31:11.209238+00	1	Kether - כתר	2	[{"changed": {"fields": ["language"]}}]	18	1
161	2019-12-02 17:31:17.836619+00	2	Jehovah - יהוה	2	[{"changed": {"fields": ["language"]}}]	18	1
162	2019-12-02 17:35:07.07687+00	1	Kether - כתר : Hebrew	2	[]	18	1
163	2019-12-02 17:49:54.122767+00	1	Kether - כתר : Hebrew	2	[]	18	1
164	2019-12-02 17:54:32.937899+00	1	Kether - כתר : Hebrew	2	[]	18	1
165	2019-12-02 17:55:33.057764+00	1	Kether - כתרכ : Hebrew	2	[{"changed": {"fields": ["name_original_language"]}}]	18	1
166	2019-12-02 17:58:12.178956+00	5	Kether - כתרכ : Hebrew - 640.0 : Regular	3		24	1
167	2019-12-02 17:58:12.208929+00	4	Kether - כתרכ : Hebrew - 640.0 : Simple	3		24	1
168	2019-12-02 17:58:12.265563+00	3	Kether - כתרכ : Hebrew - 620.0 : Regular	3		24	1
169	2019-12-02 17:58:12.334944+00	2	Kether - כתרכ : Hebrew - 620.0 : Simple	3		24	1
170	2019-12-02 18:05:57.831564+00	1	Kether - כתר : Hebrew	2	[{"changed": {"fields": ["name_original_language"]}}]	18	1
171	2019-12-02 18:06:27.096611+00	15	Kether - כתר : Hebrew - 620.0 : Regular	3		24	1
172	2019-12-02 18:06:27.130798+00	14	Kether - כתר : Hebrew - 420.0 : Regular	3		24	1
173	2019-12-02 18:06:27.158082+00	13	Kether - כתר : Hebrew - 20.0 : Regular	3		24	1
174	2019-12-02 18:06:27.197255+00	12	Kether - כתר : Hebrew - 620.0 : Simple	3		24	1
175	2019-12-02 18:06:27.224918+00	11	Kether - כתר : Hebrew - 420.0 : Simple	3		24	1
176	2019-12-02 18:06:27.306112+00	10	Kether - כתר : Hebrew - 20.0 : Simple	3		24	1
177	2019-12-02 18:06:35.865413+00	1	Kether - כתר : Hebrew	2	[]	18	1
178	2019-12-02 18:07:13.410475+00	21	Kether - כתר : Hebrew - 620.0 : Regular	3		24	1
179	2019-12-02 18:07:13.441333+00	20	Kether - כתר : Hebrew - 420.0 : Regular	3		24	1
180	2019-12-02 18:07:13.467648+00	19	Kether - כתר : Hebrew - 20.0 : Regular	3		24	1
181	2019-12-02 18:07:13.493108+00	18	Kether - כתר : Hebrew - 620.0 : Simple	3		24	1
182	2019-12-02 18:07:13.537845+00	17	Kether - כתר : Hebrew - 420.0 : Simple	3		24	1
183	2019-12-02 18:07:13.612392+00	16	Kether - כתר : Hebrew - 20.0 : Simple	3		24	1
184	2019-12-02 18:07:21.832884+00	1	Kether - כתר : Hebrew	2	[]	18	1
185	2019-12-02 18:09:40.052467+00	1	Kether - כתר : Hebrew	2	[]	18	1
186	2019-12-02 18:13:55.546758+00	3	Greek	1	[{"added": {}}]	16	1
187	2019-12-02 18:14:02.725637+00	4	English	1	[{"added": {}}]	16	1
188	2019-12-05 22:02:17.011985+00	0ac22e10-dbf8-44ec-acce-ab9b20225cf6	Hebrew	1	[{"added": {}}]	16	1
189	2019-12-05 22:08:36.836078+00	3	Jah - יה : Hebrew	2	[{"changed": {"fields": ["language"]}}]	18	1
190	2019-12-05 22:08:51.035037+00	2	Jehovah - יהוה : Hebrew	2	[{"changed": {"fields": ["language"]}}]	18	1
191	2019-12-05 22:09:02.346788+00	1	Kether - כתר : Hebrew	2	[{"changed": {"fields": ["language"]}}]	18	1
192	2019-12-05 22:09:20.300478+00	1	Hebrew - Lang: Hebrew	2	[{"changed": {"fields": ["language"]}}]	15	1
193	2019-12-05 22:09:28.32459+00	2	English - Lang: Hebrew	2	[{"changed": {"fields": ["language"]}}]	15	1
194	2019-12-05 22:09:46.025884+00	5	Hebrew	3		16	1
195	2019-12-05 22:10:04.844378+00	4	English	3		16	1
196	2019-12-05 22:10:04.867255+00	3	Greek	3		16	1
197	2019-12-05 22:10:04.888671+00	2	English	3		16	1
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	auth	permission
2	auth	group
3	contenttypes	contenttype
4	sessions	session
5	sites	site
6	admin	logentry
7	account	emailaddress
8	account	emailconfirmation
9	socialaccount	socialaccount
10	socialaccount	socialapp
11	socialaccount	socialtoken
12	users	user
13	gematriacore	letterpower
14	gematriacore	letter
15	gematriacore	alphabet
16	gematriacore	language
17	gematriacore	dictionary
18	gematriacore	word
19	gematriacore	gematriamethodletterrule
20	gematriacore	wordmeaning
21	gematriacore	gematriamethod
22	gematriacore	lettermeaning
23	gematriacore	wordspelling
24	gematriacore	wordvalue
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2019-03-20 23:39:18.651439+00
2	contenttypes	0002_remove_content_type_name	2019-03-20 23:39:18.667756+00
3	auth	0001_initial	2019-03-20 23:39:18.719332+00
4	auth	0002_alter_permission_name_max_length	2019-03-20 23:39:18.729309+00
5	auth	0003_alter_user_email_max_length	2019-03-20 23:39:18.739378+00
6	auth	0004_alter_user_username_opts	2019-03-20 23:39:18.748962+00
7	auth	0005_alter_user_last_login_null	2019-03-20 23:39:18.761525+00
8	auth	0006_require_contenttypes_0002	2019-03-20 23:39:18.764844+00
9	auth	0007_alter_validators_add_error_messages	2019-03-20 23:39:18.773677+00
10	auth	0008_alter_user_username_max_length	2019-03-20 23:39:18.782597+00
11	users	0001_initial	2019-03-20 23:39:18.831614+00
12	account	0001_initial	2019-03-20 23:39:18.889948+00
13	account	0002_email_max_length	2019-03-20 23:39:18.904848+00
14	admin	0001_initial	2019-03-20 23:39:18.936453+00
15	admin	0002_logentry_remove_auto_add	2019-03-20 23:39:18.950298+00
16	auth	0009_alter_user_last_name_max_length	2019-03-20 23:39:18.966287+00
17	sessions	0001_initial	2019-03-20 23:39:18.986449+00
18	sites	0001_initial	2019-03-20 23:39:18.998625+00
19	sites	0002_alter_domain_unique	2019-03-20 23:39:19.019818+00
20	sites	0003_set_site_domain_and_name	2019-03-20 23:39:19.046829+00
21	socialaccount	0001_initial	2019-03-20 23:39:19.179389+00
22	socialaccount	0002_token_max_lengths	2019-03-20 23:39:19.218682+00
23	socialaccount	0003_extra_data_default_dict	2019-03-20 23:39:19.232314+00
34	gematriacore	0011_auto_20190330_1645	2019-03-30 16:45:29.072854+00
39	gematriacore	0001_initial	2019-12-02 16:47:42.495949+00
40	gematriacore	0002_alphabet_characters	2019-12-02 16:51:00.845499+00
41	gematriacore	0003_remove_alphabet_characters	2019-12-02 16:57:42.474222+00
42	gematriacore	0004_auto_20191202_1727	2019-12-02 17:29:44.00069+00
43	gematriacore	0005_auto_20191202_1802	2019-12-02 18:02:34.177359+00
44	gematriacore	0006_language_uuid	2019-12-05 21:38:58.228196+00
45	gematriacore	0006_auto_20191205_2159	2019-12-05 22:14:28.139038+00
46	gematriacore	0007_auto_20191205_2212	2019-12-05 22:14:28.357247+00
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
gdpl8lan3803vwnd8l2e5alhv9gjyr3b	NjlkNGFhYzc4NjU3ODIxNzcwYmUxZjFmN2I0MjBlOTc2NGJkY2U4Njp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkNmNkOTcxZmY2MjhmMzg0ZDQwM2Q0ODU0ZGFkMWIwNWNkZWMxODk4In0=	2019-04-04 16:06:06.489595+00
dzqbh0levr02el1t6t3pxeh1tw7clfam	NjlkNGFhYzc4NjU3ODIxNzcwYmUxZjFmN2I0MjBlOTc2NGJkY2U4Njp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkNmNkOTcxZmY2MjhmMzg0ZDQwM2Q0ODU0ZGFkMWIwNWNkZWMxODk4In0=	2019-07-17 15:07:10.656567+00
dks6b2b54in13a4bm4m77zyyp5arb7z8	NjlkNGFhYzc4NjU3ODIxNzcwYmUxZjFmN2I0MjBlOTc2NGJkY2U4Njp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJkNmNkOTcxZmY2MjhmMzg0ZDQwM2Q0ODU0ZGFkMWIwNWNkZWMxODk4In0=	2019-12-16 15:59:01.938623+00
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.django_site (id, domain, name) FROM stdin;
1	hsgd.gematria.com	gematria
\.


--
-- Data for Name: gematriacore_alphabet; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.gematriacore_alphabet (id, created, modified, title, language_id) FROM stdin;
1	2019-03-21 17:52:11.262087+00	2019-12-05 22:09:20.25169+00	Hebrew	\N
2	2019-12-02 16:02:34.172075+00	2019-12-05 22:09:28.299793+00	English	\N
\.


--
-- Data for Name: gematriacore_gematriamethod; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.gematriacore_gematriamethod (id, created, modified, title, alphabet_id, language_id) FROM stdin;
1	2019-03-21 18:40:33.125467+00	2019-03-23 16:37:30.565212+00	Simple	1	1
2	2019-03-23 16:42:56.722941+00	2019-03-23 16:49:52.205366+00	Regular	1	1
\.


--
-- Data for Name: gematriacore_gematriamethodletterrule; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.gematriacore_gematriamethodletterrule (id, created, modified, numerical_value, letter_id, gematria_method_id) FROM stdin;
1	2019-03-23 16:26:43.400589+00	2019-03-23 16:26:43.400625+00	1	5	\N
2	2019-03-23 16:31:36.481342+00	2019-03-23 16:31:36.481383+00	1	5	1
3	2019-03-23 16:31:36.49519+00	2019-03-23 16:31:36.495229+00	2	6	1
4	2019-03-23 16:31:36.506757+00	2019-03-23 16:31:36.506803+00	3	7	1
5	2019-03-23 16:37:30.581413+00	2019-03-23 16:37:30.581457+00	4	8	1
6	2019-03-23 16:37:30.593666+00	2019-03-23 16:37:30.593707+00	5	9	1
7	2019-03-23 16:37:30.607657+00	2019-03-23 16:37:30.607708+00	6	10	1
8	2019-03-23 16:37:30.623468+00	2019-03-23 16:37:30.623507+00	7	11	1
9	2019-03-23 16:37:30.637911+00	2019-03-23 16:37:30.637942+00	8	12	1
10	2019-03-23 16:37:30.653757+00	2019-03-23 16:37:30.653798+00	9	13	1
11	2019-03-23 16:37:30.67321+00	2019-03-23 16:37:30.67327+00	10	14	1
12	2019-03-23 16:37:30.692467+00	2019-03-23 16:37:30.69252+00	20	15	1
13	2019-03-23 16:37:30.71162+00	2019-03-23 16:37:30.7117+00	20	16	1
14	2019-03-23 16:37:30.730984+00	2019-03-23 16:37:30.731035+00	30	17	1
15	2019-03-23 16:37:30.742683+00	2019-03-23 16:37:30.74273+00	40	18	1
16	2019-03-23 16:37:30.757868+00	2019-03-23 16:37:30.757912+00	40	19	1
17	2019-03-23 16:37:30.77159+00	2019-03-23 16:37:30.771622+00	50	20	1
18	2019-03-23 16:37:30.786342+00	2019-03-23 16:37:30.786374+00	50	21	1
19	2019-03-23 16:37:30.798552+00	2019-03-23 16:37:30.798587+00	60	22	1
20	2019-03-23 16:37:30.81059+00	2019-03-23 16:37:30.810619+00	70	23	1
21	2019-03-23 16:37:30.825665+00	2019-03-23 16:37:30.825696+00	80	24	1
22	2019-03-23 16:37:30.839194+00	2019-03-23 16:37:30.839227+00	80	25	1
23	2019-03-23 16:37:30.853925+00	2019-03-23 16:37:30.853955+00	90	26	1
24	2019-03-23 16:37:30.867734+00	2019-03-23 16:37:30.867765+00	90	27	1
25	2019-03-23 16:37:30.880228+00	2019-03-23 16:37:30.880268+00	100	28	1
26	2019-03-23 16:37:30.902154+00	2019-03-23 16:37:30.902182+00	200	29	1
27	2019-03-23 16:37:30.915107+00	2019-03-23 16:37:30.915149+00	300	30	1
28	2019-03-23 16:37:30.927867+00	2019-03-23 16:37:30.927913+00	400	31	1
29	2019-03-23 16:49:52.223643+00	2019-03-23 16:49:52.223694+00	1	5	2
30	2019-03-23 16:49:52.243236+00	2019-03-23 16:49:52.243289+00	2	6	2
31	2019-03-23 16:49:52.260887+00	2019-03-23 16:49:52.260983+00	3	7	2
32	2019-03-23 16:49:52.273517+00	2019-03-23 16:49:52.273552+00	4	8	2
33	2019-03-23 16:49:52.289091+00	2019-03-23 16:49:52.289125+00	5	9	2
34	2019-03-23 16:49:52.306921+00	2019-03-23 16:49:52.307068+00	6	10	2
35	2019-03-23 16:49:52.327674+00	2019-03-23 16:49:52.327718+00	7	11	2
36	2019-03-23 16:49:52.34058+00	2019-03-23 16:49:52.340633+00	8	12	2
37	2019-03-23 16:49:52.364351+00	2019-03-23 16:49:52.364403+00	9	13	2
38	2019-03-23 16:49:52.393475+00	2019-03-23 16:49:52.393532+00	10	14	2
39	2019-03-23 16:49:52.424639+00	2019-03-23 16:49:52.424761+00	20	15	2
40	2019-03-23 16:49:52.467322+00	2019-03-23 16:49:52.467363+00	500	16	2
41	2019-03-23 16:49:52.510248+00	2019-03-23 16:49:52.510281+00	30	17	2
42	2019-03-23 16:49:52.545915+00	2019-03-23 16:49:52.545969+00	40	18	2
43	2019-03-23 16:49:52.587331+00	2019-03-23 16:49:52.587364+00	600	19	2
44	2019-03-23 16:49:52.611588+00	2019-03-23 16:49:52.611643+00	50	20	2
45	2019-03-23 16:49:52.637376+00	2019-03-23 16:49:52.63741+00	700	21	2
46	2019-03-23 16:49:52.649996+00	2019-03-23 16:49:52.650032+00	60	22	2
47	2019-03-23 16:49:52.6711+00	2019-03-23 16:49:52.671252+00	70	23	2
48	2019-03-23 16:49:52.689129+00	2019-03-23 16:49:52.689166+00	80	24	2
49	2019-03-23 16:49:52.706232+00	2019-03-23 16:49:52.706272+00	800	25	2
50	2019-03-23 16:49:52.726125+00	2019-03-23 16:49:52.726216+00	90	26	2
51	2019-03-23 16:49:52.749468+00	2019-03-23 16:49:52.74969+00	900	27	2
52	2019-03-23 16:49:52.779298+00	2019-03-23 16:49:52.779351+00	100	28	2
53	2019-03-23 16:49:52.808599+00	2019-03-23 16:49:52.808645+00	200	29	2
54	2019-03-23 16:49:52.831211+00	2019-03-23 16:49:52.831373+00	300	30	2
55	2019-03-23 16:49:52.860305+00	2019-03-23 16:49:52.860439+00	400	31	2
\.


--
-- Data for Name: gematriacore_language; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.gematriacore_language (created, modified, title, uuid) FROM stdin;
2019-03-21 17:51:50.821524+00	2019-03-21 17:51:50.821553+00	Hebrew	5b92dc65-9487-4487-94a5-7ae21ace7aab
\.


--
-- Data for Name: gematriacore_letter; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.gematriacore_letter (id, created, modified, title, "character", alphabet_id, letter_order) FROM stdin;
7	2019-03-21 18:31:31.79398+00	2019-03-21 18:31:31.794014+00	Gimel	ג	1	\N
8	2019-03-21 18:34:47.689882+00	2019-03-21 18:34:47.689929+00	Daleth	ד	1	\N
9	2019-03-21 18:35:34.414594+00	2019-03-21 18:35:34.414628+00	He	ה	1	\N
10	2019-03-21 18:55:22.510014+00	2019-03-21 18:55:22.510047+00	Vau	ו	1	\N
11	2019-03-21 18:56:59.648074+00	2019-03-21 18:56:59.648111+00	Zayin	ז	1	\N
12	2019-03-21 19:00:30.029979+00	2019-03-21 19:00:30.030011+00	Chet	ח	1	\N
13	2019-03-21 19:01:13.943862+00	2019-03-21 19:01:13.943899+00	Teth	ט	1	\N
14	2019-03-21 19:02:31.269593+00	2019-03-21 19:02:31.269636+00	Yod	י	1	\N
15	2019-03-21 19:03:40.16291+00	2019-03-21 19:03:40.162942+00	Kaph	כ	1	\N
16	2019-03-21 19:04:12.3309+00	2019-03-21 19:04:12.330935+00	Kaph - Final	ך	1	\N
17	2019-03-21 19:05:03.451001+00	2019-03-21 19:05:03.451065+00	Lamed	ל	1	\N
18	2019-03-21 19:05:46.274578+00	2019-03-21 19:05:46.274615+00	Mem	מ	1	\N
19	2019-03-21 19:06:19.667242+00	2019-03-21 19:06:19.667285+00	Mem - Final	ם	1	\N
31	2019-03-21 19:15:07.085408+00	2019-03-23 16:17:46.535555+00	Tau	ת	1	\N
30	2019-03-21 19:14:27.207543+00	2019-03-23 16:19:56.398384+00	Shin	ש	1	\N
29	2019-03-21 19:13:46.682933+00	2019-03-23 16:20:30.80447+00	Resh	ר	1	\N
28	2019-03-21 19:12:53.045885+00	2019-03-23 16:22:28.350586+00	Qoph	ק	1	\N
27	2019-03-21 19:12:09.482912+00	2019-03-23 16:23:07.378958+00	Tzaddi - Final	ץ	1	\N
26	2019-03-21 19:11:33.64249+00	2019-03-23 16:23:28.964154+00	Tzaddi	צ	1	\N
25	2019-03-21 19:10:45.48104+00	2019-03-23 16:24:07.712068+00	Peh - Final	ף	1	\N
24	2019-03-21 19:10:13.564421+00	2019-03-23 16:24:29.304137+00	Peh	פ	1	\N
23	2019-03-21 19:09:16.533989+00	2019-03-23 16:24:48.703295+00	Ayin	ע	1	\N
22	2019-03-21 19:08:35.136482+00	2019-03-23 16:25:10.814067+00	Samekh	ס	1	\N
21	2019-03-21 19:07:40.564035+00	2019-03-23 16:25:29.622521+00	Nun - Final	ן	1	\N
20	2019-03-21 19:07:09.805844+00	2019-03-23 16:25:45.316878+00	Nun	נ	1	\N
6	2019-03-21 18:30:06.475055+00	2019-03-23 16:40:44.924043+00	Beth	ב	1	2
5	2019-03-21 18:12:13.012575+00	2019-12-02 17:08:52.544901+00	Aleph	א	1	1
\.


--
-- Data for Name: gematriacore_letter_meanings; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.gematriacore_letter_meanings (id, letter_id, lettermeaning_id) FROM stdin;
1	31	28
2	30	27
3	29	25
4	29	26
5	28	24
6	28	23
7	27	22
8	26	22
9	25	21
10	24	21
11	23	20
12	22	19
13	21	18
14	20	18
15	6	3
16	5	1
\.


--
-- Data for Name: gematriacore_lettermeaning; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.gematriacore_lettermeaning (id, created, modified, meaning, is_active) FROM stdin;
1	2019-03-21 18:06:12.086995+00	2019-03-21 18:06:12.087027+00	Ox	t
2	2019-03-21 18:31:10.342935+00	2019-03-21 18:31:10.342979+00	Camel	t
3	2019-03-21 18:31:56.50444+00	2019-03-21 18:31:56.504472+00	House	t
4	2019-03-21 18:34:39.61591+00	2019-03-21 18:34:39.615941+00	Door	t
5	2019-03-21 18:35:26.933877+00	2019-03-21 18:35:26.933904+00	Window	t
6	2019-03-21 18:54:50.541947+00	2019-03-21 18:54:50.541977+00	Pin	t
7	2019-03-21 18:55:14.403969+00	2019-03-21 18:55:14.404001+00	Nail	f
8	2019-03-21 18:56:43.749951+00	2019-03-21 18:56:43.749981+00	Sword	t
9	2019-03-21 18:56:53.036277+00	2019-03-21 18:56:53.036311+00	Armour	f
10	2019-03-21 19:00:14.95828+00	2019-03-21 19:00:14.958313+00	Fence	t
11	2019-03-21 19:00:25.396247+00	2019-03-21 19:00:25.396275+00	Enclosure	f
12	2019-03-21 19:01:10.019384+00	2019-03-21 19:01:10.019413+00	Snake	t
13	2019-03-21 19:02:02.614405+00	2019-03-21 19:02:02.614437+00	Hand	t
14	2019-03-21 19:02:10.645723+00	2019-03-21 19:02:10.645754+00	Palm	t
15	2019-03-21 19:03:28.717966+00	2019-03-21 19:03:28.717994+00	Fist	t
16	2019-03-21 19:04:59.648484+00	2019-03-21 19:04:59.648514+00	Ox Goad	t
17	2019-03-21 19:05:42.126366+00	2019-03-21 19:05:42.126395+00	Water	t
18	2019-03-21 19:07:06.602701+00	2019-03-21 19:07:06.602732+00	Fish	f
19	2019-03-21 19:08:24.368863+00	2019-03-21 19:08:24.368891+00	Prop	t
20	2019-03-21 19:09:13.410634+00	2019-03-21 19:09:13.410665+00	Eye	t
21	2019-03-21 19:10:08.65225+00	2019-03-21 19:10:08.652278+00	Mouth	t
22	2019-03-21 19:11:26.105819+00	2019-03-21 19:11:26.10585+00	Fishhook	t
23	2019-03-21 19:12:41.834096+00	2019-03-21 19:12:41.83413+00	Ear	t
24	2019-03-21 19:12:49.103168+00	2019-03-21 19:12:49.1032+00	Back of Head	f
25	2019-03-21 19:13:16.00132+00	2019-03-21 19:13:16.001368+00	Head	t
26	2019-03-21 19:13:22.5638+00	2019-03-21 19:13:22.563829+00	Face	t
28	2019-03-21 19:15:02.564213+00	2019-03-23 15:52:17.334875+00	Cross	t
27	2019-03-21 19:14:21.685431+00	2019-03-23 15:53:07.137907+00	Tooth	t
\.


--
-- Data for Name: gematriacore_letterpower; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.gematriacore_letterpower (id, created, modified, power, is_active, letter_id) FROM stdin;
32	2019-03-23 16:17:46.608561+00	2019-03-23 16:17:46.608597+00	T	t	31
33	2019-03-23 16:17:46.623027+00	2019-03-23 16:17:46.623066+00	Th	f	31
34	2019-03-23 16:19:56.479833+00	2019-03-23 16:19:56.479876+00	S	t	30
35	2019-03-23 16:19:56.500293+00	2019-03-23 16:19:56.500411+00	Sh	f	30
36	2019-03-23 16:20:30.867815+00	2019-03-23 16:20:30.86785+00	R	t	29
37	2019-03-23 16:22:28.457098+00	2019-03-23 16:22:28.457201+00	Q	t	28
38	2019-03-23 16:23:07.456422+00	2019-03-23 16:23:07.456475+00	Tz	t	27
39	2019-03-23 16:23:29.030979+00	2019-03-23 16:23:29.031012+00	Tz	t	26
40	2019-03-23 16:24:07.764335+00	2019-03-23 16:24:07.764366+00	P	t	25
41	2019-03-23 16:24:07.77724+00	2019-03-23 16:24:07.77727+00	Ph	f	25
42	2019-03-23 16:24:29.361743+00	2019-03-23 16:24:29.361775+00	P	t	24
43	2019-03-23 16:24:29.378936+00	2019-03-23 16:24:29.379002+00	Ph	f	24
44	2019-03-23 16:24:48.76937+00	2019-03-23 16:24:48.769402+00	Aa	t	23
45	2019-03-23 16:24:48.784677+00	2019-03-23 16:24:48.784707+00	O	f	23
46	2019-03-23 16:25:10.866887+00	2019-03-23 16:25:10.86692+00	S	t	22
47	2019-03-23 16:25:29.713316+00	2019-03-23 16:25:29.713356+00	N	t	21
48	2019-03-23 16:25:45.371682+00	2019-03-23 16:25:45.371731+00	N	t	20
49	2019-03-23 16:40:45.016416+00	2019-03-23 16:40:45.016461+00	B	t	6
50	2019-03-23 16:40:45.036218+00	2019-03-23 16:40:45.036271+00	V	f	6
\.


--
-- Data for Name: gematriacore_word; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.gematriacore_word (id, created, modified, name_english, name_original_language, language_id) FROM stdin;
3	2019-12-02 20:57:42.961688+00	2019-12-05 22:08:36.705532+00	Jah	יה	\N
2	2019-03-30 19:43:31.971015+00	2019-12-05 22:08:50.966961+00	Jehovah	יהוה	\N
1	2019-03-23 16:55:45.775185+00	2019-12-05 22:09:02.279879+00	Kether	כתר	\N
\.


--
-- Data for Name: gematriacore_wordmeaning; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.gematriacore_wordmeaning (id, created, modified, meaning, is_active, word_id) FROM stdin;
1	2019-03-23 16:55:45.831391+00	2019-03-23 16:55:45.831434+00	The Crown	t	1
2	2019-03-30 19:43:32.044316+00	2019-03-30 19:43:32.044358+00	Tetragrammaton	\N	2
\.


--
-- Data for Name: gematriacore_wordspelling; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.gematriacore_wordspelling (id, created, modified, "position", letter_id, word_id) FROM stdin;
1	2019-03-30 20:07:54.353906+00	2019-03-30 20:07:54.353962+00	1	14	2
2	2019-03-30 20:07:54.370751+00	2019-03-30 20:07:54.370786+00	2	9	2
3	2019-03-30 20:07:54.384083+00	2019-03-30 20:07:54.384113+00	3	10	2
4	2019-03-30 20:07:54.395359+00	2019-03-30 20:07:54.39539+00	4	9	2
5	2019-03-30 21:59:15.054788+00	2019-03-30 21:59:15.054889+00	4	14	2
6	2019-03-30 22:00:20.764123+00	2019-03-30 22:00:20.764304+00	3	9	2
7	2019-03-30 22:00:34.819967+00	2019-03-30 22:00:34.820184+00	2	10	2
8	2019-03-30 22:00:38.648061+00	2019-03-30 22:00:38.648127+00	1	9	2
\.


--
-- Data for Name: gematriacore_wordvalue; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.gematriacore_wordvalue (id, created, modified, value, gematria_method_id, word_id) FROM stdin;
1	2019-12-02 17:30:21.782+00	2019-12-02 17:30:21.782111+00	26	1	2
22	2019-12-02 18:07:20.508968+00	2019-12-02 18:09:39.643619+00	620	1	1
23	2019-12-02 18:07:21.504856+00	2019-12-02 18:09:39.971531+00	620	2	1
24	2019-12-02 20:57:43.132853+00	2019-12-02 20:57:43.132898+00	15	1	3
25	2019-12-02 20:57:43.299055+00	2019-12-02 20:57:43.299099+00	15	2	3
\.


--
-- Data for Name: socialaccount_socialaccount; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.socialaccount_socialaccount (id, provider, uid, last_login, date_joined, extra_data, user_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.socialaccount_socialapp (id, provider, name, client_id, secret, key) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp_sites; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.socialaccount_socialapp_sites (id, socialapp_id, site_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialtoken; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.socialaccount_socialtoken (id, token, token_secret, expires_at, account_id, app_id) FROM stdin;
\.


--
-- Data for Name: users_user; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.users_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, name) FROM stdin;
1	argon2$argon2i$v=19$m=512,t=2,p=2$MjJlWDZjZnJvN3ZU$jHNMo/kG36aYvv9Hu3hVyQ	2019-12-02 15:59:01.890672+00	t	admin			ndewaard@protonmail.com	t	t	2019-03-21 16:01:17.563359+00	poopman
\.


--
-- Data for Name: users_user_groups; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.users_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: users_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: debug
--

COPY public.users_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.account_emailaddress_id_seq', 1, true);


--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.account_emailconfirmation_id_seq', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 72, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 197, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 24, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 46, true);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.django_site_id_seq', 1, false);


--
-- Name: gematriacore_alphabet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.gematriacore_alphabet_id_seq', 2, true);


--
-- Name: gematriacore_gematriamethod_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.gematriacore_gematriamethod_id_seq', 2, true);


--
-- Name: gematriacore_gematriamethodletterrule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.gematriacore_gematriamethodletterrule_id_seq', 55, true);


--
-- Name: gematriacore_letter_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.gematriacore_letter_id_seq', 31, true);


--
-- Name: gematriacore_letter_meanings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.gematriacore_letter_meanings_id_seq', 16, true);


--
-- Name: gematriacore_lettermeaning_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.gematriacore_lettermeaning_id_seq', 28, true);


--
-- Name: gematriacore_letterpower_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.gematriacore_letterpower_id_seq', 50, true);


--
-- Name: gematriacore_word_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.gematriacore_word_id_seq', 3, true);


--
-- Name: gematriacore_wordmeaning_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.gematriacore_wordmeaning_id_seq', 2, true);


--
-- Name: gematriacore_wordspelling_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.gematriacore_wordspelling_id_seq', 8, true);


--
-- Name: gematriacore_wordvalue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.gematriacore_wordvalue_id_seq', 25, true);


--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.socialaccount_socialaccount_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_sites_id_seq', 1, false);


--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.socialaccount_socialtoken_id_seq', 1, false);


--
-- Name: users_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.users_user_groups_id_seq', 1, false);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.users_user_id_seq', 1, true);


--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: debug
--

SELECT pg_catalog.setval('public.users_user_user_permissions_id_seq', 1, false);


--
-- Name: account_emailaddress account_emailaddress_email_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_email_key UNIQUE (email);


--
-- Name: account_emailaddress account_emailaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_pkey PRIMARY KEY (id);


--
-- Name: account_emailconfirmation account_emailconfirmation_key_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_key_key UNIQUE (key);


--
-- Name: account_emailconfirmation account_emailconfirmation_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: gematriacore_alphabet gematriacore_alphabet_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_alphabet
    ADD CONSTRAINT gematriacore_alphabet_pkey PRIMARY KEY (id);


--
-- Name: gematriacore_gematriamethod gematriacore_gematriamethod_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_gematriamethod
    ADD CONSTRAINT gematriacore_gematriamethod_pkey PRIMARY KEY (id);


--
-- Name: gematriacore_gematriamethodletterrule gematriacore_gematriamethodletterrule_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_gematriamethodletterrule
    ADD CONSTRAINT gematriacore_gematriamethodletterrule_pkey PRIMARY KEY (id);


--
-- Name: gematriacore_letter_meanings gematriacore_letter_mean_letter_id_lettermeaning__4feed48f_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_letter_meanings
    ADD CONSTRAINT gematriacore_letter_mean_letter_id_lettermeaning__4feed48f_uniq UNIQUE (letter_id, lettermeaning_id);


--
-- Name: gematriacore_letter_meanings gematriacore_letter_meanings_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_letter_meanings
    ADD CONSTRAINT gematriacore_letter_meanings_pkey PRIMARY KEY (id);


--
-- Name: gematriacore_letter gematriacore_letter_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_letter
    ADD CONSTRAINT gematriacore_letter_pkey PRIMARY KEY (id);


--
-- Name: gematriacore_lettermeaning gematriacore_lettermeaning_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_lettermeaning
    ADD CONSTRAINT gematriacore_lettermeaning_pkey PRIMARY KEY (id);


--
-- Name: gematriacore_letterpower gematriacore_letterpower_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_letterpower
    ADD CONSTRAINT gematriacore_letterpower_pkey PRIMARY KEY (id);


--
-- Name: gematriacore_word gematriacore_word_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_word
    ADD CONSTRAINT gematriacore_word_pkey PRIMARY KEY (id);


--
-- Name: gematriacore_wordmeaning gematriacore_wordmeaning_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_wordmeaning
    ADD CONSTRAINT gematriacore_wordmeaning_pkey PRIMARY KEY (id);


--
-- Name: gematriacore_wordspelling gematriacore_wordspelling_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_wordspelling
    ADD CONSTRAINT gematriacore_wordspelling_pkey PRIMARY KEY (id);


--
-- Name: gematriacore_wordvalue gematriacore_wordvalue_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_wordvalue
    ADD CONSTRAINT gematriacore_wordvalue_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_provider_uid_fc810c6e_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_provider_uid_fc810c6e_uniq UNIQUE (provider, uid);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq UNIQUE (socialapp_id, site_id);


--
-- Name: socialaccount_socialapp socialaccount_socialapp_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp
    ADD CONSTRAINT socialaccount_socialapp_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp_sites_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq UNIQUE (app_id, account_id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_user_id_group_id_b88eab82_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_group_id_b88eab82_uniq UNIQUE (user_id, group_id);


--
-- Name: users_user users_user_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_permission_id_43338c45_uniq; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_permission_id_43338c45_uniq UNIQUE (user_id, permission_id);


--
-- Name: users_user users_user_username_key; Type: CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_username_key UNIQUE (username);


--
-- Name: account_emailaddress_email_03be32b2_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX account_emailaddress_email_03be32b2_like ON public.account_emailaddress USING btree (email varchar_pattern_ops);


--
-- Name: account_emailaddress_user_id_2c513194; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX account_emailaddress_user_id_2c513194 ON public.account_emailaddress USING btree (user_id);


--
-- Name: account_emailconfirmation_email_address_id_5b7f8c58; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX account_emailconfirmation_email_address_id_5b7f8c58 ON public.account_emailconfirmation USING btree (email_address_id);


--
-- Name: account_emailconfirmation_key_f43612bd_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX account_emailconfirmation_key_f43612bd_like ON public.account_emailconfirmation USING btree (key varchar_pattern_ops);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX django_site_domain_a2e37b91_like ON public.django_site USING btree (domain varchar_pattern_ops);


--
-- Name: gematriacore_alphabet_language_id_de0b0f88; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_alphabet_language_id_de0b0f88 ON public.gematriacore_alphabet USING btree (language_id);


--
-- Name: gematriacore_gematriametho_gematria_method_id_f14ce4da; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_gematriametho_gematria_method_id_f14ce4da ON public.gematriacore_gematriamethodletterrule USING btree (gematria_method_id);


--
-- Name: gematriacore_gematriamethod_alphabet_id_21f3304b; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_gematriamethod_alphabet_id_21f3304b ON public.gematriacore_gematriamethod USING btree (alphabet_id);


--
-- Name: gematriacore_gematriamethod_language_id_7f8b8b7a; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_gematriamethod_language_id_7f8b8b7a ON public.gematriacore_gematriamethod USING btree (language_id);


--
-- Name: gematriacore_gematriamethodletterrule_letter_id_a01dae03; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_gematriamethodletterrule_letter_id_a01dae03 ON public.gematriacore_gematriamethodletterrule USING btree (letter_id);


--
-- Name: gematriacore_letter_alphabet_id_63f756c8; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_letter_alphabet_id_63f756c8 ON public.gematriacore_letter USING btree (alphabet_id);


--
-- Name: gematriacore_letter_meanings_letter_id_fdcc5b0c; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_letter_meanings_letter_id_fdcc5b0c ON public.gematriacore_letter_meanings USING btree (letter_id);


--
-- Name: gematriacore_letter_meanings_lettermeaning_id_2a43406d; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_letter_meanings_lettermeaning_id_2a43406d ON public.gematriacore_letter_meanings USING btree (lettermeaning_id);


--
-- Name: gematriacore_letterpower_letter_id_3ddae067; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_letterpower_letter_id_3ddae067 ON public.gematriacore_letterpower USING btree (letter_id);


--
-- Name: gematriacore_word_language_id_e311a704; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_word_language_id_e311a704 ON public.gematriacore_word USING btree (language_id);


--
-- Name: gematriacore_wordmeaning_word_id_bec07de9; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_wordmeaning_word_id_bec07de9 ON public.gematriacore_wordmeaning USING btree (word_id);


--
-- Name: gematriacore_wordspelling_letter_id_82949fce; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_wordspelling_letter_id_82949fce ON public.gematriacore_wordspelling USING btree (letter_id);


--
-- Name: gematriacore_wordspelling_word_id_3570b5ae; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_wordspelling_word_id_3570b5ae ON public.gematriacore_wordspelling USING btree (word_id);


--
-- Name: gematriacore_wordvalue_gematria_method_id_dab8249f; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_wordvalue_gematria_method_id_dab8249f ON public.gematriacore_wordvalue USING btree (gematria_method_id);


--
-- Name: gematriacore_wordvalue_word_id_8ae7f96d; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX gematriacore_wordvalue_word_id_8ae7f96d ON public.gematriacore_wordvalue USING btree (word_id);


--
-- Name: socialaccount_socialaccount_user_id_8146e70c; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX socialaccount_socialaccount_user_id_8146e70c ON public.socialaccount_socialaccount USING btree (user_id);


--
-- Name: socialaccount_socialapp_sites_site_id_2579dee5; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX socialaccount_socialapp_sites_site_id_2579dee5 ON public.socialaccount_socialapp_sites USING btree (site_id);


--
-- Name: socialaccount_socialapp_sites_socialapp_id_97fb6e7d; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX socialaccount_socialapp_sites_socialapp_id_97fb6e7d ON public.socialaccount_socialapp_sites USING btree (socialapp_id);


--
-- Name: socialaccount_socialtoken_account_id_951f210e; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX socialaccount_socialtoken_account_id_951f210e ON public.socialaccount_socialtoken USING btree (account_id);


--
-- Name: socialaccount_socialtoken_app_id_636a42d7; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX socialaccount_socialtoken_app_id_636a42d7 ON public.socialaccount_socialtoken USING btree (app_id);


--
-- Name: users_user_groups_group_id_9afc8d0e; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_user_groups_group_id_9afc8d0e ON public.users_user_groups USING btree (group_id);


--
-- Name: users_user_groups_user_id_5f6f5a90; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_user_groups_user_id_5f6f5a90 ON public.users_user_groups USING btree (user_id);


--
-- Name: users_user_user_permissions_permission_id_0b93982e; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_user_user_permissions_permission_id_0b93982e ON public.users_user_user_permissions USING btree (permission_id);


--
-- Name: users_user_user_permissions_user_id_20aca447; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_user_user_permissions_user_id_20aca447 ON public.users_user_user_permissions USING btree (user_id);


--
-- Name: users_user_username_06e46fe6_like; Type: INDEX; Schema: public; Owner: debug
--

CREATE INDEX users_user_username_06e46fe6_like ON public.users_user USING btree (username varchar_pattern_ops);


--
-- Name: account_emailaddress account_emailaddress_user_id_2c513194_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_user_id_2c513194_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_emailconfirmation account_emailconfirm_email_address_id_5b7f8c58_fk_account_e; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirm_email_address_id_5b7f8c58_fk_account_e FOREIGN KEY (email_address_id) REFERENCES public.account_emailaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gematriacore_gematriamethod gematriacore_gematri_alphabet_id_21f3304b_fk_gematriac; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_gematriamethod
    ADD CONSTRAINT gematriacore_gematri_alphabet_id_21f3304b_fk_gematriac FOREIGN KEY (alphabet_id) REFERENCES public.gematriacore_alphabet(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gematriacore_gematriamethodletterrule gematriacore_gematri_gematria_method_id_f14ce4da_fk_gematriac; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_gematriamethodletterrule
    ADD CONSTRAINT gematriacore_gematri_gematria_method_id_f14ce4da_fk_gematriac FOREIGN KEY (gematria_method_id) REFERENCES public.gematriacore_gematriamethod(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gematriacore_gematriamethodletterrule gematriacore_gematri_letter_id_a01dae03_fk_gematriac; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_gematriamethodletterrule
    ADD CONSTRAINT gematriacore_gematri_letter_id_a01dae03_fk_gematriac FOREIGN KEY (letter_id) REFERENCES public.gematriacore_letter(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gematriacore_letter_meanings gematriacore_letter__letter_id_fdcc5b0c_fk_gematriac; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_letter_meanings
    ADD CONSTRAINT gematriacore_letter__letter_id_fdcc5b0c_fk_gematriac FOREIGN KEY (letter_id) REFERENCES public.gematriacore_letter(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gematriacore_letter_meanings gematriacore_letter__lettermeaning_id_2a43406d_fk_gematriac; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_letter_meanings
    ADD CONSTRAINT gematriacore_letter__lettermeaning_id_2a43406d_fk_gematriac FOREIGN KEY (lettermeaning_id) REFERENCES public.gematriacore_lettermeaning(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gematriacore_letter gematriacore_letter_alphabet_id_63f756c8_fk_gematriac; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_letter
    ADD CONSTRAINT gematriacore_letter_alphabet_id_63f756c8_fk_gematriac FOREIGN KEY (alphabet_id) REFERENCES public.gematriacore_alphabet(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gematriacore_letterpower gematriacore_letterp_letter_id_3ddae067_fk_gematriac; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_letterpower
    ADD CONSTRAINT gematriacore_letterp_letter_id_3ddae067_fk_gematriac FOREIGN KEY (letter_id) REFERENCES public.gematriacore_letter(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gematriacore_wordmeaning gematriacore_wordmea_word_id_bec07de9_fk_gematriac; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_wordmeaning
    ADD CONSTRAINT gematriacore_wordmea_word_id_bec07de9_fk_gematriac FOREIGN KEY (word_id) REFERENCES public.gematriacore_word(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gematriacore_wordspelling gematriacore_wordspe_letter_id_82949fce_fk_gematriac; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_wordspelling
    ADD CONSTRAINT gematriacore_wordspe_letter_id_82949fce_fk_gematriac FOREIGN KEY (letter_id) REFERENCES public.gematriacore_letter(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gematriacore_wordspelling gematriacore_wordspe_word_id_3570b5ae_fk_gematriac; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_wordspelling
    ADD CONSTRAINT gematriacore_wordspe_word_id_3570b5ae_fk_gematriac FOREIGN KEY (word_id) REFERENCES public.gematriacore_word(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gematriacore_wordvalue gematriacore_wordval_gematria_method_id_dab8249f_fk_gematriac; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_wordvalue
    ADD CONSTRAINT gematriacore_wordval_gematria_method_id_dab8249f_fk_gematriac FOREIGN KEY (gematria_method_id) REFERENCES public.gematriacore_gematriamethod(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: gematriacore_wordvalue gematriacore_wordvalue_word_id_8ae7f96d_fk_gematriacore_word_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.gematriacore_wordvalue
    ADD CONSTRAINT gematriacore_wordvalue_word_id_8ae7f96d_fk_gematriacore_word_id FOREIGN KEY (word_id) REFERENCES public.gematriacore_word(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_account_id_951f210e_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_account_id_951f210e_fk_socialacc FOREIGN KEY (account_id) REFERENCES public.socialaccount_socialaccount(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_app_id_636a42d7_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_app_id_636a42d7_fk_socialacc FOREIGN KEY (app_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_site_id_2579dee5_fk_django_si; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_site_id_2579dee5_fk_django_si FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc FOREIGN KEY (socialapp_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_user_id_8146e70c_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_user_id_8146e70c_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_group_id_9afc8d0e_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_group_id_9afc8d0e_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_user_id_5f6f5a90_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_5f6f5a90_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_perm_permission_id_0b93982e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_perm_permission_id_0b93982e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_20aca447_fk_users_user_id; Type: FK CONSTRAINT; Schema: public; Owner: debug
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_20aca447_fk_users_user_id FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

